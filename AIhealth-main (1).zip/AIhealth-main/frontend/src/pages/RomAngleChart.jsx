// RomAngleChart.jsx
import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

export default function RomAngleChart({
  history,
  fingers,
  jointsPerFinger,
  fingerColors,
  lineDashByJoint,
  title = '',
  height = 260,
  showLegend = true,
  yRange = { min: 0, max: 140 },
  maintainAspectRatio = false,
  animations = false,
  labelFor, // (finger, joint) => string
}) {
  const labels = history.map((_, i) => `#${i + 1}`);
  const datasets = fingers.flatMap(finger =>
    (jointsPerFinger[finger] || []).map(jn => ({
      label: labelFor ? labelFor(finger, jn) : `${finger} - ${jn}`,
      data: history.map(h => {
        const idx = (jointsPerFinger[finger] || []).indexOf(jn);
        return h.angles?.[finger]?.[idx] ?? null;
      }),
      borderColor: fingerColors[finger],
      backgroundColor: fingerColors[finger],
      borderDash: lineDashByJoint[jn] || [],
      tension: 0.2,
      pointRadius: 1.5,
      borderWidth: 2,
      spanGaps: true,
    }))
  );

  const options = {
    responsive: true,
    plugins: { legend: { display: showLegend }, title: { display: !!title, text: title } },
    maintainAspectRatio,
    animation: animations,
    scales: { y: { suggestedMin: yRange.min, suggestedMax: yRange.max } },
  };

  return (
    <div style={{ height }}>
      <Line data={{ labels, datasets }} options={options} />
    </div>
  );
}
