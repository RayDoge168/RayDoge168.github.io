// HandRomCsvDownload.jsx — CSV download with live username prefix, CJK-safe filename, Excel-friendly BOM
import React, { useEffect, useState } from 'react';

// —— 檔名前綴清洗（CJK 友善，移除非法字元、零寬字元，空白→底線）——
function sanitizePrefix(s, fallback = 'HandROM_Test') {
  const raw = (s ?? '').toString().trim();
  const base = raw || fallback;
  const underscored = base.replace(/\s+/g, '_');
  const withoutBad = underscored
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, '') // Windows 禁用 + 控制字元
    .replace(/[\u200B-\u200D\uFEFF]/g, '');    // 零寬
  // 允許：英數、底線、減號、括號、點、CJK 與常見全形標點
  const safe = withoutBad.replace(/[^\w\-().\u4E00-\u9FFF\u3000-\u303F\uFF01-\uFF60]/g, '');
  return (safe || fallback).slice(0, 64);
}

// —— CSV 內容產生 ——
// history: [{ timestamp:number, angles: { [finger]: number[] } }, ...]
// visibleKeys: ['thumb_0','thumb_1', ...]；以 jointsIndexByFinger 映射取角度
function buildCsv({
  history,
  testStartAtMs,
  visibleKeys = [],
  jointsIndexByFinger = {},
  effectivePrefix,
}) {
  if (!history?.length) return null;

  const startTs =
    typeof testStartAtMs === 'number' && testStartAtMs
      ? testStartAtMs
      : history[0].timestamp;

  const startISO = new Date(startTs).toISOString();

  const cols = ['t_offset_s', 'timestamp_iso', ...visibleKeys];
  // 先輸出兩行 meta，再輸出 header 與資料
  const metaLines = [
    `TestStartISO,${startISO}`,
    `FilePrefix,${effectivePrefix}`,
  ];

  const rows = [cols];

  for (const rec of history) {
    const offsetSec = ((rec.timestamp - startTs) / 1000).toFixed(2);
    const iso = new Date(rec.timestamp).toISOString();

    const angleRow = visibleKeys.map((key) => {
      const [finger, joint] = key.split('_');
      const idx = jointsIndexByFinger?.[finger]?.[joint];
      const v = idx != null ? rec.angles?.[finger]?.[idx] : undefined;
      return typeof v === 'number' ? Math.round(v).toString() : '';
    });

    rows.push([offsetSec, iso, ...angleRow]);
  }

  const body = rows.map((r) => r.join(',')).join('\n');
  return `${metaLines.join('\n')}\n${body}`;
}

export default function HandRomCsvDownload({
  history,
  testStartAtMs,
  visibleKeys,
  jointsIndexByFinger,
  filenamePrefix, // 若有傳入，優先使用；否則採用使用者名稱（含即時事件同步）
  label = 'CSV',
  className = 'btn btn-outline-primary btn-sm',
  rebuildSignal = 0,
}) {
  const [url, setUrl] = useState(null);
  const [name, setName] = useState(null);

  // —— 追蹤使用者名稱（初始化＋同分頁即時更新）——
  const [userPrefix, setUserPrefix] = useState(() => {
    try {
      return (window.localStorage.getItem('userName') || '').trim();
    } catch {
      return '';
    }
  });

  useEffect(() => {
    const onCustom = (e) => {
      const n = (e?.detail?.name || '').trim();
      setUserPrefix(n);
    };
    window.addEventListener('user-name-updated', onCustom);
    return () => window.removeEventListener('user-name-updated', onCustom);
  }, []);

  // 最終前綴：prop > userName > fallback
  const effectivePrefix = sanitizePrefix(filenamePrefix ?? userPrefix, 'HandROM_Test');

  useEffect(() => {
    // 先回收舊 URL
    if (url) URL.revokeObjectURL(url);

    if (!history?.length) {
      setUrl(null);
      setName(null);
      return;
    }

    const csv = buildCsv({
      history,
      testStartAtMs,
      visibleKeys,
      jointsIndexByFinger,
      effectivePrefix,
    });

    if (!csv) {
      setUrl(null);
      setName(null);
      return;
    }

    // Excel 友善：加上 UTF-8 BOM
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
    const newUrl = URL.createObjectURL(blob);

    const startISO = new Date(
      typeof testStartAtMs === 'number' && testStartAtMs
        ? testStartAtMs
        : history[0].timestamp
    )
      .toISOString()
      .replace(/[:.]/g, '-');

    // 檔名：<prefix>_HandROM_<ISO>.csv
    setUrl(newUrl);
    setName(`${effectivePrefix}_HandROM_${startISO}.csv`);

    return () => URL.revokeObjectURL(newUrl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    history,
    testStartAtMs,
    rebuildSignal,
    effectivePrefix,               // ← 名字/前綴變更會觸發重建
    visibleKeys?.join('|') || '',  // 監控欄位集合變化
  ]);

  useEffect(() => () => { if (url) URL.revokeObjectURL(url); }, [url]);

  if (!url) return <button className={className} disabled>{label}</button>;
  return <a className={className} href={url} download={name}>{label}</a>;
}
