// BodyRomAngleChart.jsx (update)
import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const partColor = {
  Shoulder: '#8b5cf6',
  Elbow:    '#36a2eb',
  Wrist:    '#4bc0c0',
  Hip:      '#f59e0b',
  Knee:     '#22c55e',
  Ankle:    '#ef4444',
};

function colorForKey(key) {
  const part = key.split('-')[1] || key;
  return partColor[part] || '#999';
}

/**
 * props:
 * - history: [{timestamp, angles: {'R-Shoulder':deg, ...}}]
 * - seriesKeys: ['R-Shoulder', ...]
 * - labelForKey?: (key) => string   // 👈 新增：自訂圖例標籤（做 i18n）
 * - title, height, yRange, showLegend, maintainAspectRatio, animations
 */
export default function BodyRomAngleChart({
  history,
  seriesKeys,
  labelForKey,
  title = '',
  height = 260,
  yRange = { min: 0, max: 180 },
  showLegend = true,
  maintainAspectRatio = false,
  animations = false,
}) {
  const labels = history.map((_, i) => `#${i + 1}`);
  const datasets = seriesKeys.map((k) => ({
    label: labelForKey ? labelForKey(k) : k,
    data: history.map(h => (typeof h.angles?.[k] === 'number' ? h.angles[k] : null)),
    borderColor: colorForKey(k),
    backgroundColor: colorForKey(k),
    tension: 0.2,
    pointRadius: 1.5,
    borderWidth: 2,
    spanGaps: true,
  }));

  const options = {
    responsive: true,
    plugins: { legend: { display: showLegend }, title: { display: !!title, text: title } },
    maintainAspectRatio,
    animation: animations,
    scales: { y: { suggestedMin: yRange.min, suggestedMax: yRange.max } },
  };

  return (
    <div style={{ height }}>
      <Line data={{ labels, datasets }} options={options} />
    </div>
  );
}
