// HeadPoseDock.jsx — bottom dock with Live/Test charts + CSV export (with user prefix, live-updating)
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement,
  Tooltip, Legend, TimeScale
} from 'chart.js';

// 一次性註冊（避免重複）
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, TimeScale);

// ---- helpers ----
function readCssVar(name, fallback) {
  if (typeof window === 'undefined') return fallback;
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function toCsv(series) {
  // series: [{timestamp, yaw, pitch, roll}]
  const header = 'timestamp_ms,timestamp_iso,yaw,pitch,roll';
  const lines = series.map(p => {
    const iso = new Date(p.timestamp).toISOString();
    return `${p.timestamp},${iso},${p.yaw ?? ''},${p.pitch ?? ''},${p.roll ?? ''}`;
  });
  return [header, ...lines].join('\n');
}

function downloadBlob(text, filename, type = 'text/csv;charset=utf-8;') {
  // Excel 友善：加上 UTF-8 BOM
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// 將名稱清洗成安全的檔名前綴：
// - 允許中英數、底線、連字號、括號、點與常見中文字元
// - 移除 Windows 不允許字元 <>:"/\|?* 以及控制字元
// - 空白轉底線、連續底線壓縮、限制長度
function sanitizePrefix(s, fallback = 'GUEST') {
  const raw = (s ?? '').toString().trim();
  const base = raw || fallback;
  const underscored = base.replace(/\s+/g, '_');
  const withoutBad = underscored
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, '') // Windows 禁用 + 控制字元
    .replace(/[\u200B-\u200D\uFEFF]/g, '');    // 零寬字元
  // 允許中日韓：\u4E00-\u9FFF、全形標點常見範圍
  const safe = withoutBad.replace(/[^\w\-().\u4E00-\u9FFF\u3000-\u303F\uFF01-\uFF60]/g, '');
  return safe.replace(/_+/g, '_').slice(0, 64) || fallback;
}

/**
 * Props:
 * - liveSeries: {timestamp:number, yaw:number, pitch:number, roll:number}[]
 * - testSeries: same as above
 * - fps: number
 * - isTesting: boolean
 * - countdown: number | null
 * - testSeconds: number
 * - testStartAt: number | null
 * - onStartTest: () => void
 * - onStopTest: () => void
 * - filenamePrefix?: string  // 若不提供，會自動讀 localStorage.userName，並監聽 'user-name-updated'
 */
export default function HeadPoseDock({
  liveSeries = [],
  testSeries = [],
  fps = 0,
  isTesting = false,
  countdown = null,
  testSeconds = 8,
  testStartAt = null,
  onStartTest,
  onStopTest,
  filenamePrefix,
}) {
  // UI 狀態
  const [tab, setTab] = useState('live'); // 'live' | 'test'
  const [visible, setVisible] = useState({ yaw: true, pitch: true, roll: true });
  const [collapsed, setCollapsed] = useState(false);
  const [yMin, setYMin] = useState(-60);
  const [yMax, setYMax] = useState(60);

  // 讀 CSS 變數配色（與 HeadPoseRecorder 一致）
  const uiCyan = useMemo(() => String(readCssVar('--ui-cyan', '#22d3ee')), []);
  const uiMagenta = useMemo(() => String(readCssVar('--ui-magenta', '#e879f9')), []);
  const uiViolet = useMemo(() => String(readCssVar('--ui-violet', '#a78bfa')), []);

  // 取用當前分頁的 series
  const currentSeries = tab === 'live' ? liveSeries : testSeries;

  // 生成 X 軸標籤：顯示相對秒數（相對於第一筆或 testStartAt）
  const labels = useMemo(() => {
    if (!currentSeries.length) return [];
    const base = tab === 'test' && testStartAt ? testStartAt : currentSeries[0].timestamp;
    return currentSeries.map(p => ((p.timestamp - base) / 1000).toFixed(1)); // 秒
  }, [currentSeries, tab, testStartAt]);

  // Chart datasets
  const data = useMemo(() => {
    const yawArr = currentSeries.map(p => p.yaw ?? null);
    const pitchArr = currentSeries.map(p => p.pitch ?? null);
    const rollArr = currentSeries.map(p => p.roll ?? null);
    return {
      labels,
      datasets: [
        visible.yaw && {
          label: 'Yaw (°)',
          data: yawArr,
          borderColor: uiViolet,
          pointRadius: 0,
          borderWidth: 2,
          tension: 0.25,
        },
        visible.pitch && {
          label: 'Pitch (°)',
          data: pitchArr,
          borderColor: uiMagenta,
          pointRadius: 0,
          borderWidth: 2,
          tension: 0.25,
        },
        visible.roll && {
          label: 'Roll (°)',
          data: rollArr,
          borderColor: uiCyan,
          pointRadius: 0,
          borderWidth: 2,
          tension: 0.25,
        },
      ].filter(Boolean),
    };
  }, [currentSeries, labels, visible, uiCyan, uiMagenta, uiViolet]);

  const options = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    animation: false,
    plugins: {
      legend: { position: 'top' },
      tooltip: { intersect: false, mode: 'index' },
    },
    scales: {
      x: {
        title: { display: true, text: 't (s)' },
        grid: { display: false },
        ticks: { maxTicksLimit: 8 },
      },
      y: {
        title: { display: true, text: 'degrees' },
        suggestedMin: yMin,
        suggestedMax: yMax,
        grid: { color: 'rgba(255,255,255,0.08)' },
      },
    },
  }), [yMin, yMax]);

  // ---- 決定檔名前綴（支援即時同步）----
  const [csvPrefix, setCsvPrefix] = useState(() => {
    if (filenamePrefix) return filenamePrefix;
    if (typeof window !== 'undefined' && window.localStorage) {
      const n = window.localStorage.getItem('userName') || '';
      return n || 'GUEST';
    }
    return 'GUEST';
  });

  // prop 更新時覆寫
  useEffect(() => {
    if (filenamePrefix) setCsvPrefix(filenamePrefix);
  }, [filenamePrefix]);

  // 監聽全站「使用者名稱更新」事件（由 GuestPage.saveName() 發送）
  useEffect(() => {
    const onName = (e) => {
      const name = (e?.detail?.name || '').trim();
      if (name) setCsvPrefix(name);
    };
    window.addEventListener('user-name-updated', onName);
    return () => window.removeEventListener('user-name-updated', onName);
  }, []);

  const effectivePrefix = sanitizePrefix(csvPrefix, 'GUEST');

  // CSV 下載（含自訂前綴）
  const handleDownloadCsv = () => {
    const csv = toCsv(currentSeries);

    // 時間戳：優先用 testStartAt（test 分頁），否則用當前分頁第一筆或現在
    const baseTs =
      (tab === 'test' && typeof testStartAt === 'number' && testStartAt) ||
      (currentSeries[0]?.timestamp) ||
      Date.now();

    const iso = new Date(baseTs).toISOString().replace(/[:.]/g, '-');
    const filename = `${effectivePrefix}_HeadPose_${tab}_${iso}.csv`;

    downloadBlob(csv, filename, 'text/csv;charset=utf-8;');
  };

  // 切換可見曲線
  const toggleKey = (k) => setVisible(v => ({ ...v, [k]: !v[k] }));

  // Dock 樣式（固定在底部，暗色卡片）
  const dockStyle = {
    position: 'fixed',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 9999,
    background: 'rgba(20,20,24,0.92)',
    backdropFilter: 'blur(6px)',
    color: '#f5f5f5',
    boxShadow: '0 -8px 24px rgba(0,0,0,0.35)',
    borderTop: '1px solid rgba(255,255,255,0.1)',
  };

  return (
    <div style={dockStyle}>
      <div className="container py-2">
        {/* Dock Header */}
        <div className="d-flex align-items-center justify-content-between gap-2">
          <div className="d-flex align-items-center gap-2 flex-wrap">
            <strong>Head Pose Dock</strong>
            <span className="badge text-bg-secondary">FPS: {fps}</span>
            {isTesting && (
              <span className="badge text-bg-danger">
                施測中{typeof countdown === 'number' ? ` • 倒數 ${countdown}s` : ''}
              </span>
            )}
            {!isTesting && tab === 'test' && testSeries.length > 0 && (
              <span className="badge text-bg-success">已完成 {testSeries.length} 筆</span>
            )}
          </div>

          <div className="d-flex align-items-center gap-2">
            <button
              className={`btn btn-sm ${tab === 'live' ? 'btn-light' : 'btn-outline-light'}`}
              onClick={() => setTab('live')}
            >
              Live
            </button>
            <button
              className={`btn btn-sm ${tab === 'test' ? 'btn-light' : 'btn-outline-light'}`}
              onClick={() => setTab('test')}
            >
              Test
            </button>

            <button
              className="btn btn-sm btn-outline-info"
              onClick={() => toggleKey('yaw')}
              title="顯示/隱藏 Yaw"
              style={{ borderColor: uiViolet, color: uiViolet }}
            >
              Yaw
            </button>
            <button
              className="btn btn-sm btn-outline-info"
              onClick={() => toggleKey('pitch')}
              title="顯示/隱藏 Pitch"
              style={{ borderColor: uiMagenta, color: uiMagenta }}
            >
              Pitch
            </button>
            <button
              className="btn btn-sm btn-outline-info"
              onClick={() => toggleKey('roll')}
              title="顯示/隱藏 Roll"
              style={{ borderColor: uiCyan, color: uiCyan }}
            >
              Roll
            </button>

            <button
              className="btn btn-sm btn-success"
              onClick={handleDownloadCsv}
              disabled={!currentSeries.length}
              title="下載目前分頁資料（Live 或 Test）"
            >
              下載 CSV
            </button>

            <button
              className="btn btn-sm btn-outline-secondary"
              onClick={() => setCollapsed(c => !c)}
              title={collapsed ? '展開' : '收合'}
            >
              {collapsed ? '展開' : '收合'}
            </button>
          </div>
        </div>

        {/* 控制列（y-range 與 施測控制） */}
        {!collapsed && (
          <div className="d-flex align-items-center justify-content-between flex-wrap gap-3 mt-2">
            <div className="d-flex align-items-center gap-3">
              <label className="small d-flex align-items-center gap-2">
                Y最小：
                <input
                  type="number"
                  value={yMin}
                  onChange={e => setYMin(Number(e.target.value))}
                  style={{ width: 80 }}
                />
              </label>
              <label className="small d-flex align-items-center gap-2">
                Y最大：
                <input
                  type="number"
                  value={yMax}
                  onChange={e => setYMax(Number(e.target.value))}
                  style={{ width: 80 }}
                />
              </label>
            </div>

            <div className="d-flex align-items-center gap-2">
              {!isTesting ? (
                <button className="btn btn-primary btn-sm" onClick={onStartTest}>
                  開始施測（{testSeconds}s）
                </button>
              ) : (
                <button className="btn btn-warning btn-sm" onClick={onStopTest}>
                  停止施測
                </button>
              )}
            </div>
          </div>
        )}

        {/* Chart 區塊 */}
        {!collapsed && (
          <div className="mt-2" style={{ height: 220 }}>
            {currentSeries.length ? (
              <Line data={data} options={options} />
            ) : (
              <div className="text-center text-muted py-5" aria-live="polite">
                {tab === 'live' ? '尚無即時資料…' : (isTesting ? '施測進行中…' : '尚無施測紀錄，請按「開始施測」')}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
