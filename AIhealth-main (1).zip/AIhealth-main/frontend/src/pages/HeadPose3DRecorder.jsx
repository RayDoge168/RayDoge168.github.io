// HeadPose3DRecorder.jsx — FaceMesh + OpenCV.js solvePnP → 3D Head Pose (Yaw/Pitch/Roll)
// - Mat 暫存重用（cameraMatrix/distCoeffs/objectPoints/imagePoints/rvec/tvec/Rm/modelAxis/projected）
// - 可配置方向判定：thresholds、dirOrder、dwellMs；支援「自動校準」與「還原預設」
// - 嘴角索引切換：61/291（標準）與 78/308（替代）一鍵切換
// - FOV 估算相機內參、鏡像符號修正、中立位校正、指數平滑與 UI 節流
// - 視覺化：3D XYZ 軸、關鍵點、數值標籤、方向標籤
// - 錄影/下載、FPS 顯示；ESLint OK（無空 catch、無 process）

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FaceMesh } from '@mediapipe/face_mesh';
import * as cam from '@mediapipe/camera_utils';
import { useTranslation } from 'react-i18next';

const VIDEO_WIDTH = 640;
const VIDEO_HEIGHT = 480;
const SCREEN_MIRRORED = true;

// ==== FaceMesh 其它索引 ====
// 眼角固定（常見穩定點）
const FM_NOSE_TIP = 1;
const FM_CHIN = 152;
const FM_LEFT_EYE = 33;
const FM_RIGHT_EYE = 263;
// 嘴角兩組可切換：標準(61/291) vs 替代(78/308)

// ==== 3D 模型點（mm；通用近似，正式使用請自行校正 / 換模型） ====
const MODEL_3D_POINTS = [
  // Nose tip
  0.0,   0.0,    0.0,
  // Chin
  0.0,  -63.6, -12.5,
  // Left eye corner
  -43.3, 32.7, -26.0,
  // Right eye corner
  43.3,  32.7, -26.0,
  // Left mouth corner
  -28.9, -28.9, -24.1,
  // Right mouth corner
  28.9, -28.9, -24.1,
];

// 小工具
const deg = (r) => (r * 180) / Math.PI;

function drawPoint(ctx, P, r = 4, c = '#ff2cab') {
  ctx.beginPath();
  ctx.arc(P.x, P.y, r, 0, Math.PI * 2);
  ctx.fillStyle = c;
  ctx.fill();
}
function drawSegment(ctx, A, B, c = '#00d1ff', w = 3) {
  ctx.beginPath();
  ctx.moveTo(A.x, A.y);
  ctx.lineTo(B.x, B.y);
  ctx.lineWidth = w;
  ctx.lineCap = 'round';
  ctx.strokeStyle = c;
  ctx.stroke();
}
function drawLabel(ctx, text, x, y, color = '#00D1FF') {
  const pad = 3;
  ctx.font = '12px Arial';
  const w = ctx.measureText(text).width + pad * 2;
  const h = 14 + pad * 2;
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.fillRect(x, y - h + 2, w, h);
  ctx.fillStyle = color;
  ctx.fillText(text, x + pad, y - pad);
}

// 旋轉矩陣 → Euler XYZ（Pitch / Yaw / Roll）
function rmatToEulerXYZ(R) {
  // R: array[9] (row-major)
  const r00 = R[0], r01 = R[1], r02 = R[2];
  const r10 = R[3], r11 = R[4], r12 = R[5];
  const r20 = R[6], r21 = R[7], r22 = R[8];

  const sy = Math.sqrt(r00 * r00 + r10 * r10);
  let x, y, z;
  if (sy > 1e-6) {
    x = Math.atan2(r21, r22);     // pitch (X)
    y = Math.atan2(-r20, sy);     // yaw   (Y)
    z = Math.atan2(r10, r00);     // roll  (Z)
  } else {
    // 奇異位姿
    x = Math.atan2(-r12, r11);
    y = Math.atan2(-r20, sy);
    z = 0;
  }
  return { pitch: deg(x), yaw: deg(y), roll: deg(z) };
}

// ===== OpenCV.js 載入器 =====
const OPENCV_VERSION = '4.10.0';

function loadOpenCV() {
  return new Promise((resolve, reject) => {
    if (window.cv && window.cv.Mat) return resolve(window.cv);

    const base = `https://docs.opencv.org/${OPENCV_VERSION}`;
    window.Module = {
      locateFile: (file) => `${base}/${file}`,
      onRuntimeInitialized: () => {
        if (window.cv) resolve(window.cv);
      },
    };

    const script = document.createElement('script');
    script.src = `${base}/opencv.js`;
    script.async = true;
    script.crossOrigin = 'anonymous'; 

    let settled = false;
    const finish = (ok, val) => {
      if (settled) return;
      settled = true;
      if (ok) resolve(val);
      else reject(val);
    };

    script.onload = () => {
      if (window.cv?.ready?.then) {
        window.cv.ready.then(() => finish(true, window.cv)).catch((e) => {
          console.warn('[OpenCV] cv.ready rejected:', e);
          setTimeout(() => {
            if (window.cv?.Mat) finish(true, window.cv);
            else finish(false, new Error('cv.ready resolved but cv.Mat missing'));
          }, 50);
        });
      } else {
        setTimeout(() => {
          if (window.cv?.Mat) finish(true, window.cv);
        }, 50);
      }
    };
    script.onerror = () => finish(false, new Error('OpenCV.js script load error'));
    document.head.appendChild(script);
    setTimeout(() => finish(false, new Error('OpenCV.js load timeout')), 20000);
  });
}

// 以 FOV 估算 cameraMatrix
function makeCameraMatrix(cv, w, h, fovDeg = 60) {
  const f = (w / 2) / Math.tan((fovDeg * Math.PI / 180) / 2);
  return cv.matFromArray(3, 3, cv.CV_64F, [
    f, 0, w / 2,
    0, f, h / 2,
    0, 0, 1,
  ]);
}

// 通用方向分類（支援多鍵條件；正值用 >=、負值用 <=）
function classifyDirectionByConfig(a, thresholds, dirOrder) {
  for (const label of dirOrder) {
    const conf = thresholds[label];
    if (!conf) continue;
    let ok = true;
    for (const key of Object.keys(conf)) {
      const val = conf[key];
      const cur = a[key];
      if (val >= 0) {
        if (!(cur >= val)) { ok = false; break; }
      } else {
        if (!(cur <= val)) { ok = false; break; }
      }
    }
    if (ok) return label;
  }
  return 'NEUTRAL';
}

export default function HeadPose3DRecorder({
  // ===== 可配置參數 =====
  fovDeg = 60,                 // 估算相機水平 FOV（度）
  axisLen = 60,                // 3D 軸長度（mm）
  smoothingMs = 120,           // 指數平滑時間常數（ms）
  uiHz = 10,                   // UI 更新頻率（Hz）
  dwellMs = 300,               // 方向需連續維持的毫秒數
  dirOrder = ['LEFT','RIGHT','UP','DOWN','TILT_LEFT','TILT_RIGHT','NEUTRAL'], // 優先順序
  thresholds: thresholdsProp = { // 預設方向門檻（可被自動校準覆寫）
    LEFT:       { yaw: -20 },
    RIGHT:      { yaw:  20 },
    UP:         { pitch: -15 },
    DOWN:       { pitch:  15 },
    TILT_LEFT:  { roll: -20 },
    TILT_RIGHT: { roll:  20 },
    NEUTRAL:    {},
  },
  autoCalibMs = 5000,          // 自動校準收集時間
  autoCalibPercent = 0.6,      // 用極值的比例作為門檻（0.4~0.8 建議）
  onDirection,                 // (dir) => void
  onPose,                      // ({yaw,pitch,roll})（平滑後）
} = {}) {
  const { t } = useTranslation();

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const cameraRef = useRef(null);
  const faceRef = useRef(null);
  const rafRef = useRef(0);

  const [cvReady, setCvReady] = useState(false);
  const [angles, setAngles] = useState({ yaw: 0, pitch: 0, roll: 0 });
  const [fps, setFps] = useState(0);
  const lastTsRef = useRef(0);
  const emaDtRef = useRef(120);

  // 錄影
  const [isRecording, setIsRecording] = useState(false);
  const [timer, setTimer] = useState('');
  const [downloadUrl, setDownloadUrl] = useState(null);
  const recRef = useRef(null);
  const chunksRef = useRef([]);

  // 嘴角索引切換
  const [mouthVariant, setMouthVariant] = useState('standard'); // 'standard' | 'inner'
  const mouthIdxRef = useRef({ L: 61, R: 291 }); // 會隨切換更新
  useEffect(() => {
    mouthIdxRef.current = mouthVariant === 'inner' ? { L: 78, R: 308 } : { L: 61, R: 291 };
  }, [mouthVariant]);

  // 顏色
  const colors = useMemo(
    () => ({
      red: '#ef4444',
      green: '#22c55e',
      blue: '#3b82f6',
      cyan: '#00D1FF',
      magenta: '#FF2CAB',
      white: '#ffffff',
      yellow: '#fde047',
    }),
    []
  );

  // Mat 暫存
  const matsRef = useRef(null);

  // 角度平滑 & 校正
  const filteredRef = useRef({ yaw: 0, pitch: 0, roll: 0 });
  const neutralRef  = useRef({ yaw: 0, pitch: 0, roll: 0 });
  const lastUiUpdateRef = useRef(0);

  // 方向偵測
  const [direction, setDirection] = useState('NEUTRAL');
  const lastDirRef = useRef('NEUTRAL');
  const lastDirStartRef = useRef(0);

  // 門檻（可被自動校準覆寫）
  const [dynThresholds, setDynThresholds] = useState(thresholdsProp);
  const cfgRef = useRef({ thresholds: thresholdsProp, dirOrder, dwellMs, smoothingMs, uiHz });
  useEffect(() => { cfgRef.current.thresholds = dynThresholds; }, [dynThresholds]);
  useEffect(() => { cfgRef.current.dirOrder = dirOrder;   }, [dirOrder]);
  useEffect(() => { cfgRef.current.dwellMs = dwellMs;     }, [dwellMs]);
  useEffect(() => { cfgRef.current.smoothingMs = smoothingMs; }, [smoothingMs]);
  useEffect(() => { cfgRef.current.uiHz = uiHz;           }, [uiHz]);

  // 自動校準狀態
  const [autoCalStatus, setAutoCalStatus] = useState('idle'); // idle | running | done | canceled
  const [autoCalInfo, setAutoCalInfo] = useState(null);       // 顯示校準結果
  const autoCalRef = useRef({
    active: false,
    start: 0,
    windowMs: autoCalibMs,
    minYaw: 0, maxYaw: 0,
    minPitch: 0, maxPitch: 0,
    minRoll: 0, maxRoll: 0,
  });
  useEffect(() => { autoCalRef.current.windowMs = autoCalibMs; }, [autoCalibMs]);

  // 清理 URL
  useEffect(() => {
    return () => {
      if (downloadUrl) {
        try { URL.revokeObjectURL(downloadUrl); }
        catch (err) { console.warn('[HeadPose3D] revokeObjectURL failed:', err); }
      }
    };
  }, [downloadUrl]);

  // 啟動：OpenCV → 準備 Mat → FaceMesh & Camera
  useEffect(() => {
    let stopRequested = false;

    async function boot() {
      try {
        const cv = await loadOpenCV();
        if (stopRequested) return;

        // 建立/暫存 Mat（重用）
        const cameraMatrix = makeCameraMatrix(cv, VIDEO_WIDTH, VIDEO_HEIGHT, fovDeg);
        const distCoeffs   = cv.Mat.zeros(4, 1, cv.CV_64F);
        const objectPoints = cv.matFromArray(6, 1, cv.CV_64FC3, MODEL_3D_POINTS);
        const imagePoints  = new cv.Mat(6, 1, cv.CV_64FC2);
        const rvec         = new cv.Mat(3, 1, cv.CV_64F);
        const tvec         = new cv.Mat(3, 1, cv.CV_64F);
        const Rm           = new cv.Mat(3, 3, cv.CV_64F);
        const modelAxis    = cv.matFromArray(4, 1, cv.CV_64FC3, [
          0, 0, 0,
          axisLen, 0, 0,
          0, axisLen, 0,
          0, 0, axisLen,
        ]);
        const projected    = new cv.Mat();

        matsRef.current = {
          cv,
          cameraMatrix, distCoeffs, objectPoints, imagePoints,
          rvec, tvec, Rm, modelAxis, projected,
        };

        setCvReady(true);

        // FaceMesh
        const face = new FaceMesh({
          locateFile: (f) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${f}`,
        });
        face.setOptions({
          maxNumFaces: 1,
          refineLandmarks: true,
          minDetectionConfidence: 0.6,
          minTrackingConfidence: 0.5,
          selfieMode: SCREEN_MIRRORED,
        });

        face.onResults((res) => {
          const now = performance.now();
          if (lastTsRef.current) {
            const dt = now - lastTsRef.current;
            emaDtRef.current = emaDtRef.current * 0.9 + dt * 0.1;
            setFps(Math.round(1000 / Math.max(1, emaDtRef.current)));
          }
          lastTsRef.current = now;

          const canvas = canvasRef.current;
          const ctx = canvas?.getContext('2d');
          if (!canvas || !ctx || !res?.image) return;

          ctx.save();
          ctx.clearRect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);
          ctx.drawImage(res.image, 0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);

          const lmList = res.multiFaceLandmarks?.[0];
          if (!lmList) {
            drawLabel(ctx, 'No face', 12, 22, '#ffffff');
            setAngles({ yaw: 0, pitch: 0, roll: 0 });
            ctx.restore();
            return;
          }

          // 嘴角依目前 variant 選擇索引
          const mouthL = mouthIdxRef.current.L;
          const mouthR = mouthIdxRef.current.R;

          // 取 6 個 2D 點（並畫黃色點以便校正）
          const pick = (idx) => ({ x: lmList[idx].x * VIDEO_WIDTH, y: lmList[idx].y * VIDEO_HEIGHT });
          const pts2d = [
            pick(FM_NOSE_TIP),
            pick(FM_CHIN),
            pick(FM_LEFT_EYE),
            pick(FM_RIGHT_EYE),
            pick(mouthL),
            pick(mouthR),
          ];
          pts2d.forEach((p) => drawPoint(ctx, p, 3.5, colors.yellow));

          const { cv } = matsRef.current;

          // === 使用暫存 Mat：imagePoints 直接寫入 ===
          const ip = matsRef.current.imagePoints.data64F; // [x0,y0, x1,y1, ...]
          for (let i = 0; i < 6; i++) {
            const base = i * 2;
            ip[base] = pts2d[i].x;
            ip[base + 1] = pts2d[i].y;
          }

          try {
            cv.solvePnP(
              matsRef.current.objectPoints,
              matsRef.current.imagePoints,
              matsRef.current.cameraMatrix,
              matsRef.current.distCoeffs,
              matsRef.current.rvec,
              matsRef.current.tvec,
              false,
              cv.SOLVEPNP_ITERATIVE
            );

            // Rodrigues → R
            cv.Rodrigues(matsRef.current.rvec, matsRef.current.Rm);
            const R = Array.from(matsRef.current.Rm.data64F);

            // Euler
            let { yaw, pitch, roll } = rmatToEulerXYZ(R);

            // 鏡像畫面時修正（自拍）
            if (SCREEN_MIRRORED) {
              yaw  = -yaw;
              roll = -roll;
            }

            // 中立位校正
            yaw   -= neutralRef.current.yaw;
            pitch -= neutralRef.current.pitch;
            roll  -= neutralRef.current.roll;

            // 指數平滑
            const dt = Math.max(16, emaDtRef.current); // ms
            const alpha = 1 - Math.exp(-dt / Math.max(1, cfgRef.current.smoothingMs));
            const prev = filteredRef.current;
            const filt = {
              yaw:   prev.yaw   + alpha * (yaw   - prev.yaw),
              pitch: prev.pitch + alpha * (pitch - prev.pitch),
              roll:  prev.roll  + alpha * (roll  - prev.roll),
            };
            filteredRef.current = filt;

            // 若在自動校準，收集極值
            if (autoCalRef.current.active) {
              const ac = autoCalRef.current;
              ac.minYaw = Math.min(ac.minYaw, filt.yaw);
              ac.maxYaw = Math.max(ac.maxYaw, filt.yaw);
              ac.minPitch = Math.min(ac.minPitch, filt.pitch);
              ac.maxPitch = Math.max(ac.maxPitch, filt.pitch);
              ac.minRoll = Math.min(ac.minRoll, filt.roll);
              ac.maxRoll = Math.max(ac.maxRoll, filt.roll);

              // 到時限就產生門檻
              if (now - ac.start >= ac.windowMs) {
                autoCalRef.current.active = false;

                // 以比例產生門檻：負向用 min*percent（更靠近 0），正向用 max*percent
                const p = Math.min(0.95, Math.max(0.3, autoCalibPercent));
                const leftYaw  = ac.minYaw * p;   // 負值 * p → 例如 -30 * 0.6 = -18
                const rightYaw = ac.maxYaw * p;
                const upPitch    = ac.minPitch * p;
                const downPitch  = ac.maxPitch * p;
                const tiltLeft   = ac.minRoll * p;
                const tiltRight  = ac.maxRoll * p;

                // 檢查幅度是否足夠（避免亂校）
                const good =
                  Math.abs(ac.minYaw)   > 10 || ac.maxYaw   > 10 ||
                  Math.abs(ac.minPitch) > 8  || ac.maxPitch > 8  ||
                  Math.abs(ac.minRoll)  > 10 || ac.maxRoll  > 10;

                if (good) {
                  const newTh = {
                    ...dynThresholds, // 保留 NEUTRAL 與任何客製鍵
                    LEFT:       { yaw: Math.min(-5, leftYaw) },   // 至少要有點門檻
                    RIGHT:      { yaw: Math.max( 5, rightYaw) },
                    UP:         { pitch: Math.min(-5, upPitch) },
                    DOWN:       { pitch: Math.max( 5, downPitch) },
                    TILT_LEFT:  { roll: Math.min(-5, tiltLeft) },
                    TILT_RIGHT: { roll: Math.max( 5, tiltRight) },
                  };
                  setDynThresholds(newTh);
                  setAutoCalStatus('done');
                  setAutoCalInfo({
                    minYaw: ac.minYaw.toFixed(1), maxYaw: ac.maxYaw.toFixed(1),
                    minPitch: ac.minPitch.toFixed(1), maxPitch: ac.maxPitch.toFixed(1),
                    minRoll: ac.minRoll.toFixed(1), maxRoll: ac.maxRoll.toFixed(1),
                    usedPercent: p,
                    newTh,
                  });
                } else {
                  setAutoCalStatus('canceled');
                  setAutoCalInfo({ reason: 'not_enough_motion' });
                }
              }
            }

            // UI 節流
            const uiInterval = 1000 / Math.max(1, cfgRef.current.uiHz);
            if (now - lastUiUpdateRef.current > uiInterval) {
              lastUiUpdateRef.current = now;
              setAngles({
                yaw: Math.round(filt.yaw),
                pitch: Math.round(filt.pitch),
                roll: Math.round(filt.roll),
              });
              onPose?.(filt);
            }

            // 方向偵測（依優先順序 + 滯留時間）
            const dir = classifyDirectionByConfig(
              filt,
              cfgRef.current.thresholds,
              cfgRef.current.dirOrder
            );
            if (dir !== lastDirRef.current) {
              lastDirRef.current = dir;
              lastDirStartRef.current = now;
            } else if (now - lastDirStartRef.current >= cfgRef.current.dwellMs) {
              if (direction !== dir) setDirection(dir);
              onDirection?.(dir);
            }

            // 3D 軸投影（原點放鼻尖）
            cv.projectPoints(
              matsRef.current.modelAxis,
              matsRef.current.rvec,
              matsRef.current.tvec,
              matsRef.current.cameraMatrix,
              matsRef.current.distCoeffs,
              matsRef.current.projected
            );
            const arr = Array.from(matsRef.current.projected.data64F); // [x0,y0, xX,yX, xY,yY, xZ,yZ]
            const p0 = { x: arr[0], y: arr[1] };
            const px = { x: arr[2], y: arr[3] };
            const py = { x: arr[4], y: arr[5] };
            const pz = { x: arr[6], y: arr[7] };

            drawSegment(ctx, p0, px, colors.red, 4);
            drawSegment(ctx, p0, py, colors.green, 4);
            drawSegment(ctx, p0, pz, colors.blue, 4);
            drawPoint(ctx, p0, 5, colors.white);

            // 標籤（顯示平滑後值）
            drawLabel(ctx, `Yaw ${Math.round(filt.yaw)}°`, 12, 22, colors.white);
            drawLabel(ctx, `Pitch ${Math.round(filt.pitch)}°`, 12, 42, colors.white);
            drawLabel(ctx, `Roll ${Math.round(filt.roll)}°`, 12, 62, colors.white);
            drawLabel(ctx, `FPS ${fps}`, VIDEO_WIDTH - 90, 24, colors.white);
            drawLabel(ctx, `DIR ${direction}`, VIDEO_WIDTH - 120, 46, colors.white);

          } catch (err) {
            console.warn('[HeadPose3D] solvePnP/project error:', err);
          }

          ctx.restore();
        });

        faceRef.current = face;

        // 啟相機（等待 videoRef 準備好）
        const startCamera = () => {
          if (!videoRef.current) {
            rafRef.current = requestAnimationFrame(startCamera);
            return;
          }
          const camera = new cam.Camera(videoRef.current, {
            width: VIDEO_WIDTH,
            height: VIDEO_HEIGHT,
            onFrame: async () => {
              try {
                await face.send({ image: videoRef.current });
              } catch (err) {
                console.warn('[HeadPose3D] face.send error:', err);
              }
            },
          });
          cameraRef.current = camera;
          camera.start();
        };
        rafRef.current = requestAnimationFrame(startCamera);
      } catch (err) {
        console.warn('[HeadPose3D] OpenCV boot failed:', err);
        setCvReady(false);
      }
    }

    boot();

    return () => {
      // 清理
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      try { if (cameraRef.current) cameraRef.current.stop(); }
      catch (err) { console.warn('[HeadPose3D] camera stop error:', err); }
      try { if (faceRef.current) faceRef.current.close(); }
      catch (err) { console.warn('[HeadPose3D] face close error:', err); }

      // 釋放暫存 Mat
      const m = matsRef.current;
      if (m) {
        try {
          m.cameraMatrix?.delete();
          m.distCoeffs?.delete();
          m.objectPoints?.delete();
          m.imagePoints?.delete();
          m.rvec?.delete();
          m.tvec?.delete();
          m.Rm?.delete();
          m.modelAxis?.delete();
          m.projected?.delete();
        } catch (err) {
          console.warn('[HeadPose3D] mats delete error:', err);
        }
        matsRef.current = null;
      }
    };
  }, [colors, fovDeg, axisLen]);

  // 錄影
  const supportedMime = useMemo(() => {
    const cands = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
    for (const m of cands) {
      if (window.MediaRecorder?.isTypeSupported?.(m)) return m;
    }
    return '';
  }, []);

  const startRecording = () => {
    if (!canvasRef.current || isRecording) return;
    try {
      const stream = canvasRef.current.captureStream(30);
      const rec = new MediaRecorder(stream, supportedMime ? { mimeType: supportedMime } : undefined);
      recRef.current = rec;
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e?.data?.size) chunksRef.current.push(e.data); };
      rec.onstop = () => {
        try {
          const blob = new Blob(chunksRef.current, { type: supportedMime || 'video/webm' });
          if (downloadUrl) URL.revokeObjectURL(downloadUrl);
          setDownloadUrl(URL.createObjectURL(blob));
        } catch (err) {
          console.warn('[HeadPose3D] blob compose error:', err);
        }
        setIsRecording(false);
      };
      rec.start();
      setIsRecording(true);

      // 倒數 8 秒
      let s = 8;
      setTimer(`${s}s`);
      const id = setInterval(() => {
        s -= 1;
        setTimer(s > 0 ? `${s}s` : t('recording_finished', { defaultValue: '錄影完成' }));
        if (s <= 0) {
          clearInterval(id);
          try { rec.stop(); }
          catch (err) { console.warn('[HeadPose3D] rec.stop error:', err); }
        }
      }, 1000);
    } catch (err) {
      console.warn('[HeadPose3D] MediaRecorder error:', err);
      alert(t('recording_not_supported', { defaultValue: '此瀏覽器不支援畫面錄影。' }));
    }
  };

  // 角度歸零/校正
  function calibrateNeutral() {
    const a = filteredRef.current; // 用平滑後值更穩
    neutralRef.current = { ...a };
  }

  // 方向自動校準：開始 / 取消 / 還原預設
  function startAutoCalibrate() {
    const a = filteredRef.current;
    autoCalRef.current = {
      ...autoCalRef.current,
      active: true,
      start: performance.now(),
      minYaw: a.yaw, maxYaw: a.yaw,
      minPitch: a.pitch, maxPitch: a.pitch,
      minRoll: a.roll, maxRoll: a.roll,
    };
    setAutoCalStatus('running');
    setAutoCalInfo(null);
  }
  function cancelAutoCalibrate() {
    autoCalRef.current.active = false;
    setAutoCalStatus('canceled');
  }
  function restoreDefaultThresholds() {
    setDynThresholds(thresholdsProp);
    setAutoCalStatus('idle');
    setAutoCalInfo(null);
  }

  return (
    <div className="container py-4 text-center">
      <h2 className="mb-3">
        {t('head_pose_title_3d', { defaultValue: '頭部 3D 姿態（FaceMesh + solvePnP）' })}
      </h2>

      {!cvReady && (
        <div className="alert alert-info py-2 mb-3" role="status" aria-live="polite">
          Loading OpenCV.js…
        </div>
      )}

      {/* 隱藏 video：僅供 FaceMesh 讀取 */}
      <video ref={videoRef} playsInline muted style={{ display: 'none' }} />

      {/* 畫面輸出 */}
      <div className="guest-card d-inline-block p-2">
        <canvas
          ref={canvasRef}
          width={VIDEO_WIDTH}
          height={VIDEO_HEIGHT}
          className="rounded"
          style={{ border: '1px solid rgba(255,255,255,0.2)' }}
        />
      </div>

      {/* 控制列：錄影 + 校正 + 嘴角切換 + FPS */}
      <div className="mt-3">
        <p className="mb-0">
          {t('countdown', { defaultValue: '倒數' })}: {timer || '--'} &nbsp;•&nbsp; FPS: {fps || '--'}
        </p>
        <div className="d-flex gap-2 flex-wrap justify-content-center mt-2">
          <button
            className={`btn ${isRecording ? 'btn-secondary' : 'btn-accent btn-primary'}`}
            onClick={startRecording}
            disabled={isRecording || !cvReady}
          >
            {isRecording
              ? t('recording...', { defaultValue: '錄影中…' })
              : t('start_recording', { defaultValue: '開始錄影' })}
          </button>

          <button className="btn btn-outline-light" onClick={calibrateNeutral} disabled={!cvReady}>
            {t('calibrate_neutral', { defaultValue: '歸零/校正' })}
          </button>

          <button
            className="btn btn-outline-info"
            onClick={() => setMouthVariant(v => (v === 'standard' ? 'inner' : 'standard'))}
            disabled={!cvReady}
            title="61/291 ↔ 78/308"
          >
            {t('mouth_indices', { defaultValue: '嘴角索引' })}: {mouthVariant === 'standard' ? '61/291' : '78/308'}
          </button>

          {downloadUrl && (
            <a className="btn btn-success" href={downloadUrl} download="head_pose_3d.webm">
              {t('download_recording', { defaultValue: '下載錄影' })}
            </a>
          )}
        </div>
      </div>

      {/* 自動校準控制 */}
      <div className="mt-3">
        <div className="d-flex gap-2 flex-wrap justify-content-center">
          <button
            className="btn btn-warning"
            onClick={startAutoCalibrate}
            disabled={!cvReady || autoCalRef.current.active}
            title="請在 5 秒內左右轉、抬頭低頭、左右傾，盡量做到你的極限"
          >
            {t('start_dir_auto_calib', { defaultValue: '開始方向自動校準（5s）' })}
          </button>
          <button
            className="btn btn-outline-secondary"
            onClick={cancelAutoCalibrate}
            disabled={!autoCalRef.current.active}
          >
            {t('cancel', { defaultValue: '取消' })}
          </button>
          <button
            className="btn btn-outline-danger"
            onClick={restoreDefaultThresholds}
          >
            {t('restore_defaults', { defaultValue: '還原預設門檻' })}
          </button>
        </div>
        <p className="small mt-2">
          {t('auto_calib_status', { defaultValue: '校準狀態' })}: <strong>{autoCalStatus}</strong>
          {autoCalStatus === 'running' && ' — 請左右轉、上下點頭、左右傾！'}
        </p>
      </div>

      {/* 即時數值表 + 門檻顯示 */}
      <div className="table-responsive mt-3" style={{ maxWidth: 720, margin: '0 auto' }}>
        <table className="table table-sm table-bordered align-middle">
          <thead>
            <tr>
              <th>指標</th>
              <th>目前值（°）</th>
              <th colSpan={2}>方向門檻（°）</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Yaw（左右轉）</td>
              <td><strong>{angles.yaw}</strong></td>
              <td>LEFT ≤ <code>{dynThresholds.LEFT?.yaw ?? '-'}</code></td>
              <td>RIGHT ≥ <code>{dynThresholds.RIGHT?.yaw ?? '-'}</code></td>
            </tr>
            <tr>
              <td>Pitch（點頭）</td>
              <td><strong>{angles.pitch}</strong></td>
              <td>UP ≤ <code>{dynThresholds.UP?.pitch ?? '-'}</code></td>
              <td>DOWN ≥ <code>{dynThresholds.DOWN?.pitch ?? '-'}</code></td>
            </tr>
            <tr>
              <td>Roll（側傾）</td>
              <td><strong>{angles.roll}</strong></td>
              <td>TILT_LEFT ≤ <code>{dynThresholds.TILT_LEFT?.roll ?? '-'}</code></td>
              <td>TILT_RIGHT ≥ <code>{dynThresholds.TILT_RIGHT?.roll ?? '-'}</code></td>
            </tr>
          </tbody>
        </table>
        <p className="mt-2">
          {t('direction', { defaultValue: '方向' })}: <strong>{direction}</strong>
        </p>
        {autoCalInfo && autoCalInfo.newTh && (
          <details className="text-start" style={{ maxWidth: 720, margin: '0 auto' }}>
            <summary>校準詳細（極值與採用比例）</summary>
            <div className="small mt-2">
              <div>Yaw: min {autoCalInfo.minYaw}°, max {autoCalInfo.maxYaw}°</div>
              <div>Pitch: min {autoCalInfo.minPitch}°, max {autoCalInfo.maxPitch}°</div>
              <div>Roll: min {autoCalInfo.minRoll}°, max {autoCalInfo.maxRoll}°</div>
              <div>使用比例 p = {autoCalInfo.usedPercent}</div>
            </div>
          </details>
        )}
      </div>

      <p className="small text-muted mt-2">
        ※ 使用近似相機內參與通用 3D 臉部模型；正式用途請進行相機標定與模型擬合以降低偏差。
      </p>
    </div>
  );
}
