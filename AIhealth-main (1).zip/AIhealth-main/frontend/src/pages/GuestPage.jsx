import React, { useEffect, useRef, useState, Suspense, lazy, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Hand, ActivitySquare, X, User, Link as LinkIcon, RotateCcw, Trophy } from 'lucide-react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMicrophone, faMicrophoneSlash } from '@fortawesome/free-solid-svg-icons';

import GuestTopBar from './GuestTopBar';
import './GuestPage.css';

// ✅ 以 import.meta.env 為主
const __DEV__ =
  typeof import.meta !== 'undefined' &&
  import.meta.env &&
  (Boolean(import.meta.env.DEV) || String(import.meta.env.MODE || '').toLowerCase() === 'development');

// Lazy-load heavy components
const HandGestureRecorder = lazy(() => import('./HandGestureRecorder'));
const BodyPoseRecorder   = lazy(() => import('./BodyPoseRecorder'));
const VoiceAssistant     = lazy(() => import('./VoiceAssistant'));
const HeadPoseRecorder   = lazy(() => import('./HeadPoseRecorder'));       // 2D 頭部檢測
const HeadPose3DRecorder = lazy(() => import('./HeadPose3DRecorder'));     // 3D 頭部檢測
const TableTennisL       = lazy(() => import('./TableTennisL'));           // 🏓 桌球分析

export default function GuestPage() {
  const { t } = useTranslation();

  // 'gesture' | 'body' | 'head' | 'head3d' | 'tabletennis' | null
  const [activePanel, setActivePanel] = useState(null);
  const [showAssistant, setShowAssistant] = useState(false);

  // 進度追蹤（示意）
  const [weeklyProgress, setWeeklyProgress] = useState(75);
  const [exerciseFreq, setExerciseFreq] = useState(3);

  // 面板開啟時自動捲動/聚焦
  const panelRef = useRef(null);

  // 五個 Tab 的 refs（提供鍵盤左右切換時聚焦）
  const tabRefs = useRef({
    gesture: null,
    body: null,
    head: null,
    head3d: null,
    tabletennis: null,
  });

  // ---------- 初次載入：還原面板 / 語音 ----------
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const panelQ = params.get('panel');
      const assistantQ = params.get('assistant');

      const savedPanel = window.localStorage.getItem('guest_active_panel');
      const savedAssistant = window.localStorage.getItem('guest_show_assistant');

      const validPanels = new Set(['gesture', 'body', 'head', 'head3d', 'tabletennis']);
      const fromQuery = validPanels.has(panelQ) ? panelQ : null;
      const fromStorage = validPanels.has(savedPanel) ? savedPanel : null;

      const initPanel = fromQuery ?? fromStorage ?? null;
      const initAssistant =
        assistantQ === '1' ? true : assistantQ === '0' ? false : savedAssistant === '1';

      setActivePanel(initPanel);
      setShowAssistant(!!initAssistant);

      const p = Number(window.localStorage.getItem('guest_weekly_progress') || '75');
      const f = Number(window.localStorage.getItem('guest_ex_freq') || '3');
      setWeeklyProgress(Number.isFinite(p) ? p : 75);
      setExerciseFreq(Number.isFinite(f) ? f : 3);
    } catch (e) {
      if (__DEV__) console.debug('[GuestPage] init restore failed:', e);
    }
  }, []);

  // ---------- 同步 URL 與 localStorage（可深連結） ----------
  useEffect(() => {
    try {
      const url = new URL(window.location.href);
      if (activePanel) url.searchParams.set('panel', activePanel);
      else url.searchParams.delete('panel');
      url.searchParams.set('assistant', showAssistant ? '1' : '0');
      window.history.replaceState({}, '', url);

      window.localStorage.setItem('guest_active_panel', activePanel ?? '');
      window.localStorage.setItem('guest_show_assistant', showAssistant ? '1' : '0');
      window.localStorage.setItem('guest_weekly_progress', String(weeklyProgress));
      window.localStorage.setItem('guest_ex_freq', String(exerciseFreq));
    } catch (e) {
      if (__DEV__) console.debug('[GuestPage] sync URL/localStorage failed:', e);
    }
  }, [activePanel, showAssistant, weeklyProgress, exerciseFreq]);

  // ---------- 快捷鍵：G/B/H/3/T/V/ESC ----------
  useEffect(() => {
    const onKey = (e) => {
      const k = e.key;
      if (k === 'g' || k === 'G') setActivePanel('gesture');
      else if (k === 'b' || k === 'B') setActivePanel('body');
      else if (k === 'h' || k === 'H') setActivePanel('head');
      else if (k === '3') setActivePanel('head3d');
      else if (k === 't' || k === 'T') setActivePanel('tabletennis');
      else if (k === 'v' || k === 'V') setShowAssistant((v) => !v);
      else if (k === 'Escape') {
        setActivePanel(null);
        setShowAssistant(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ---------- 懶載入預取 ----------
  const prefetchGesture     = useCallback(() => import('./HandGestureRecorder'), [],);
  const prefetchBody        = useCallback(() => import('./BodyPoseRecorder'), [],);
  const prefetchHead        = useCallback(() => import('./HeadPoseRecorder'), [],);
  const prefetchHead3D      = useCallback(() => import('./HeadPose3DRecorder'), [],);
  const prefetchTableTennis = useCallback(() => import('./TableTennisL'), [],);

  // ---------- handlers ----------
  const openGesture      = useCallback(() => setActivePanel('gesture'), []);
  const openBody         = useCallback(() => setActivePanel('body'), []);
  const openHead         = useCallback(() => setActivePanel('head'), []);
  const openHead3D       = useCallback(() => setActivePanel('head3d'), []);
  const openTableTennis  = useCallback(() => setActivePanel('tabletennis'), []);
  const closePanels      = useCallback(() => setActivePanel(null), []);

  // 鍵盤左右切換
  const moveFocus = useCallback((dir) => {
    const order = ['gesture', 'body', 'head', 'head3d', 'tabletennis'];
    const idx = order.indexOf(activePanel ?? 'gesture');
    const nextIdx = (idx + dir + order.length) % order.length;
    const key = order[nextIdx];
    const el = tabRefs.current[key];
    if (el) el.focus();
  }, [activePanel]);

  const onTabKeyDown = useCallback((e, key) => {
    if (e.key === 'ArrowRight') { e.preventDefault(); moveFocus(+1); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); moveFocus(-1); }
    else if (e.key === 'Home') { e.preventDefault(); tabRefs.current['gesture']?.focus(); }
    else if (e.key === 'End') { e.preventDefault(); tabRefs.current['tabletennis']?.focus(); }
    else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (key === 'gesture') openGesture();
      if (key === 'body') openBody();
      if (key === 'head') openHead();
      if (key === 'head3d') openHead3D();
      if (key === 'tabletennis') openTableTennis();
    }
  }, [moveFocus, openGesture, openBody, openHead, openHead3D, openTableTennis]);

  // 開啟面板自動捲動＋聚焦
  useEffect(() => {
    if (activePanel && panelRef.current) {
      panelRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      const id = setTimeout(() => {
        try { panelRef.current?.focus(); } catch (e) {}
      }, 250);
      return () => clearTimeout(id);
    }
  }, [activePanel]);

  const panelAriaLabel =
    activePanel === 'gesture' ? t('open_gesture_recognition', { defaultValue: 'Open Hand Gesture' }) :
    activePanel === 'body'    ? t('body_recognition_open',    { defaultValue: 'Open Body Pose'   }) :
    activePanel === 'head'    ? t('head_recognition_open',    { defaultValue: 'Open Head Pose'   }) :
    activePanel === 'head3d'  ? t('head3d_recognition_open',  { defaultValue: 'Open 3D Head Pose'}) :
    activePanel === 'tabletennis' ? t('open_tabletennis',     { defaultValue: 'Open Table Tennis'}) : '';

  // 深連結
  const copyDeepLink = async () => {
    try {
      const url = new URL(window.location.href);
      await navigator.clipboard.writeText(url.toString());
      alert(t('copied_link', { defaultValue: '已複製當前連結！' }));
    } catch {
      alert(t('copy_failed', { defaultValue: '複製失敗，請再試一次。' }));
    }
  };

  // 重置
  const resetState = () => {
    try {
      setActivePanel(null);
      setShowAssistant(false);
      const url = new URL(window.location.href);
      url.searchParams.delete('panel');
      url.searchParams.delete('assistant');
      window.history.replaceState({}, '', url);
      window.localStorage.removeItem('guest_active_panel');
      window.localStorage.removeItem('guest_show_assistant');
    } catch {}
  };

  // IDs 對應（Tab ↔ Panel）
  const tabIds = { gesture:'tab-gesture', body:'tab-body', head:'tab-head', head3d:'tab-head3d', tabletennis:'tab-tabletennis' };
  const panelIds = { gesture:'panel-gesture', body:'panel-body', head:'panel-head', head3d:'panel-head3d', tabletennis:'panel-tabletennis' };

  return (
    <div className="ha-bg">
      {/* 共用頂部 BAR */}
      <GuestTopBar active="rehab" />

      <div className="container py-5">
        <header className="mb-4">
          <h1 className="ha-h1">{t('rehab_guidance', { defaultValue: 'Rehabilitation Guidance' })}</h1>

          {/* 工具列：深連結／重置／語音助理 */}
          <div className="d-flex flex-wrap gap-2 mt-3">
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary rounded-pill d-inline-flex align-items-center gap-1"
              onClick={copyDeepLink}
              title={t('copy_deep_link', { defaultValue: 'Copy deep link' })}
            >
              <LinkIcon size={16} />
              {t('copy_link', { defaultValue: '複製連結' })}
            </button>

            <button
              type="button"
              className="btn btn-sm btn-outline-danger rounded-pill d-inline-flex align-items-center gap-1"
              onClick={resetState}
              title={t('reset_state', { defaultValue: 'Reset state' })}
            >
              <RotateCcw size={16} />
              {t('reset', { defaultValue: '重置' })}
            </button>

            <button
              type="button"
              className="btn btn-sm btn-outline-dark rounded-pill d-inline-flex align-items-center gap-2"
              onClick={() => setShowAssistant((v) => !v)}
              aria-pressed={showAssistant}
              aria-controls="voice-assistant-panel"
              title={
                showAssistant
                  ? t('close_voice_assistant', { defaultValue: 'Close Voice Assistant' })
                  : t('open_voice_assistant', { defaultValue: 'Open Voice Assistant' })
              }
            >
              <FontAwesomeIcon icon={showAssistant ? faMicrophoneSlash : faMicrophone} />
              {showAssistant
                ? t('close_voice_assistant', { defaultValue: '關閉語音助理' })
                : t('open_voice_assistant', { defaultValue: '開啟語音助理' })}
            </button>
          </div>
        </header>

        {/* ===== Featured Rehabilitation Programs ===== */}
        <section className="mb-5">
          <h2 className="ha-section-title">
            {t('featured_programs', { defaultValue: 'Featured Rehabilitation Programs' })}
          </h2>

          <div className="row g-3">
            <div className="col-12 col-md-4">
              <article className="ha-card">
                <img src="\public\uploads\PicS1.png" alt="" aria-hidden="true" />
                <div className="content">
                  <h3>Post-Surgery Recovery</h3>
                  <p>Guidance for recovery after surgery.</p>
                </div>
              </article>
            </div>

            <div className="col-12 col-md-4">
              <article className="ha-card">
                <img src="https://images.unsplash.com/photo-1605296867304-46d5465a13f1?q=80&w=1200&auto=format&fit=crop" alt="" aria-hidden="true" />
                <div className="content">
                  <h3>Balance and Mobility</h3>
                  <p>Exercises to improve balance and mobility.</p>
                </div>
              </article>
            </div>

            <div className="col-12 col-md-4">
              <article className="ha-card">
                <img src="\public\uploads\NOVA2.jpg" alt="" aria-hidden="true" />
                <div className="content">
                  <h3>Joint Pain Relief</h3>
                  <p>Techniques to alleviate joint pain.</p>
                </div>
              </article>
            </div>
          </div>
        </section>

        {/* ===== Interactive Exercises（五個核心功能卡片） ===== */}
        <section className="mb-5">
          <h2 className="ha-section-title">
            {t('interactive_exercises', { defaultValue: 'Interactive Exercises' })}
          </h2>

          <div className="d-flex flex-column gap-3">
            {/* 1) Hand Gesture */}
            <article className="ha-ex-card">
              <div className="thumb">
                <img src="\public\uploads\gpic1.jpg" alt="" aria-hidden="true" />
              </div>
              <div className="meta">
                <h3>{t('gesture_area', { defaultValue: 'Hand Gesture Area' })}</h3>
                <p className="text-muted mb-2">
                  {t('gesture_desc', { defaultValue: 'Real-time hand keypoints, ROM tracking, CSV export.' })}
                </p>
                <p className="text-muted">{t('video_voice_included', { defaultValue: 'Video overlay and voice guidance supported.' })}</p>
              </div>
              <button className="ha-primary" onClick={openGesture} onMouseEnter={prefetchGesture}>
                {t('start', { defaultValue: 'Start' })}
              </button>
            </article>

            {/* 2) Body Pose */}
            <article className="ha-ex-card">
              <div className="thumb">
                <img src="\public\uploads\gpic2.jpg" alt="" aria-hidden="true" />
              </div>
              <div className="meta">
                <h3>{t('body_area', { defaultValue: 'Body Pose Area' })}</h3>
                <p className="text-muted mb-2">
                  {t('body_desc', { defaultValue: 'Full-body landmarks for rehab drills and posture checks.' })}
                </p>
                <p className="text-muted">{t('video_voice_included', { defaultValue: 'Video overlay and voice guidance included.' })}</p>
              </div>
              <button className="ha-primary" onClick={openBody} onMouseEnter={prefetchBody}>
                {t('start', { defaultValue: 'Start' })}
              </button>
            </article>

            {/* 3) Head Pose 2D */}
            <article className="ha-ex-card">
              <div className="thumb">
                <img src="\public\uploads\gpic3.jpg" alt="" aria-hidden="true" />
              </div>
              <div className="meta">
                <h3>{t('head_area', { defaultValue: 'Head Pose Area' })}</h3>
                <p className="text-muted mb-2">
                  {t('head_desc', { defaultValue: '2D yaw/pitch/roll with symmetry cues and CSV logging.' })}
                </p>
                <p className="text-muted">{t('video_voice_included', { defaultValue: 'Video overlay and voice guidance included.' })}</p>
              </div>
              <button className="ha-primary" onClick={openHead} onMouseEnter={prefetchHead}>
                {t('start', { defaultValue: 'Start' })}
              </button>
            </article>

            {/* 4) Head Pose 3D */}
            <article className="ha-ex-card">
              <div className="thumb">
                <img src="\public\uploads\gpic4.jpg" alt="" aria-hidden="true" />
              </div>
              <div className="meta">
                <h3>{t('head3d_area', { defaultValue: 'Head Pose 3D Area' })}</h3>
                <p className="text-muted mb-2">
                  {t('head3d_desc', { defaultValue: '3D head orientation visualization for advanced rehab.' })}
                </p>
                <p className="text-muted">{t('video_voice_included', { defaultValue: 'Video overlay and voice guidance included.' })}</p>
              </div>
              <button className="ha-primary" onClick={openHead3D} onMouseEnter={prefetchHead3D}>
                {t('start', { defaultValue: 'Start' })}
              </button>
            </article>

            {/* 5) Table Tennis */}
            <article className="ha-ex-card">
              <div className="thumb">
                <img src="\public\uploads\gpic5.jpg" alt="" aria-hidden="true" />
              </div>
              <div className="meta">
                <h3>{t('tabletennis_area', { defaultValue: 'Table Tennis' })}</h3>
                <p className="text-muted mb-2">
                  {t('tt_desc', { defaultValue: 'Lite analyzer: keypoints overlay, ready for stroke/tempo.' })}
                </p>
                <p className="text-muted">{t('video_voice_included', { defaultValue: 'Video overlay and voice guidance included.' })}</p>
              </div>
              <button className="ha-primary" onClick={openTableTennis} onMouseEnter={prefetchTableTennis}>
                {t('start', { defaultValue: 'Start' })}
              </button>
            </article>
          </div>
        </section>

        {/* ===== Progress Tracking ===== */}
        <section className="mb-5">
          <h2 className="ha-section-title">
            {t('progress_tracking', { defaultValue: 'Progress Tracking' })}
          </h2>

          <div className="row g-3">
            <div className="col-12 col-lg-8">
              <article className="ha-metric">
                <div className="d-flex justify-content-between align-items-end mb-2">
                  <div className="label">{t('weekly_completion', { defaultValue: 'Weekly Exercise Completion' })}</div>
                  <div className="value">{weeklyProgress}%</div>
                </div>
                <div className="ha-progress">
                  <div className="bar" style={{ width: `${Math.max(0, Math.min(100, weeklyProgress))}%` }} />
                </div>
                <p className="text-muted mt-2 mb-0">{t('encourage_text', { defaultValue: "You're doing great! Keep up the good work." })}</p>
              </article>
            </div>

            <div className="col-12 col-lg-4">
              <article className="ha-metric small">
                <div className="label">{t('exercise_frequency', { defaultValue: 'Exercise Frequency' })}</div>
                <div className="big">
                  <span className="big-number">{exerciseFreq}</span>
                  <span className="big-unit">&nbsp;{t('times_per_week', { defaultValue: 'times/week' })}</span>
                </div>
                <p className="text-muted mb-0">{t('last4weeks', { defaultValue: 'Last 4 Weeks' })}</p>
              </article>
            </div>
          </div>
        </section>

        {/* ===== Dynamic Panel ===== */}
        {activePanel && (
          <section
            ref={panelRef}
            tabIndex={-1}
            className="position-relative border rounded shadow mb-4 ha-live-panel"
            aria-live="polite"
            aria-label={panelAriaLabel}
            id={panelIds[activePanel]}
            role="tabpanel"
            aria-labelledby={tabIds[activePanel]}
          >
            <button
              type="button"
              onClick={closePanels}
              className="btn btn-sm btn-danger position-absolute top-0 end-0 m-2"
              title={t('close_recognition', { defaultValue: 'Close' })}
              aria-label={t('close_recognition', { defaultValue: 'Close' })}
            >
              <X size={16} />
            </button>

            <Suspense
              fallback={
                <div className="p-4 text-center text-muted" style={{ minHeight: 340 }}>
                  Loading…
                </div>
              }
            >
              {activePanel === 'gesture' && <HandGestureRecorder />}
              {activePanel === 'body' && <BodyPoseRecorder />}
              {activePanel === 'head' && <HeadPoseRecorder />}
              {activePanel === 'head3d' && <HeadPose3DRecorder />}
              {activePanel === 'tabletennis' && <TableTennisL />}
            </Suspense>
          </section>
        )}

        {/* ===== Voice assistant UI ===== */}
        {showAssistant && (
          <section
            id="voice-assistant-panel"
            className="border rounded p-3 bg-light mt-3 ha-voice"
            role="region"
            aria-label={t('open_voice_assistant', { defaultValue: 'Voice Assistant' })}
          >
            <Suspense fallback={<div className="p-3 text-center text-muted">Loading…</div>}>
              <VoiceAssistant />
            </Suspense>
          </section>
        )}

        {/* Back to home */}
        <div className="text-center mt-4">
          <Link to="/" className="btn btn-outline-primary rounded-pill px-4">
            {t('back_to_home', { defaultValue: 'Back to Home' })}
          </Link>
        </div>
      </div>
    </div>
  );
}
