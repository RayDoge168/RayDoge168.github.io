// HandRomDock.jsx — 手部 ROM 底部 Dock（純 JS 版）
import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import RomAngleChart from './RomAngleChart';
import HandRomCsvDownload from './HandRomCsvDownload';

export default function HandRomDock({
  show,
  onClose,
  liveHistory,
  history,
  liveSeconds,
  testSeconds,
  testing,
  onStartTesting,
  onStopTesting,
  fps,
  fingers,
  jointsPerFinger,
  fingerColors,
  lineDashByJoint,
  labelFor,
  visibleSeriesKeys,
  jointsIndexByFinger,
  testStartAtMs,
  csvRebuildSignal = 0,
  onRequestCsvRebuild,
  t,
  yRange = { min: 0, max: 140 },
}) {
  const [tab, setTab] = useState('live'); // 'live' | 'test'

  if (!show) return null;

  const renderChart = (mode) => {
    const data = mode === 'live'
      ? (liveHistory && liveHistory.length ? liveHistory : [])
      : (history && history.length ? history : []);
    return (
      <div
        className="rom-dock__body"
        onClick={() => onRequestCsvRebuild && onRequestCsvRebuild()}
      >
        <RomAngleChart
          history={data}
          fingers={fingers}
          jointsPerFinger={jointsPerFinger}
          fingerColors={fingerColors}
          lineDashByJoint={lineDashByJoint}
          labelFor={labelFor}
          title=""
          height={260}
          showLegend
          yRange={yRange}
          maintainAspectRatio={false}
          animations={false}
        />
      </div>
    );
  };

  return ReactDOM.createPortal(
    <div className="rom-dock guest-card">
      <div className="rom-dock__header">
        <div className="btn-group btn-group-sm" role="tablist" aria-label="Hand ROM tabs">
          <button
            type="button"
            className={`btn ${tab === 'live' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setTab('live')}
            aria-selected={tab === 'live'}
          >
            {t?.('rom_live_chart_title', { defaultValue: '即時角度' })} ({liveSeconds}s)
          </button>
          <button
            type="button"
            className={`btn ${tab === 'test' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setTab('test')}
            aria-selected={tab === 'test'}
          >
            {t?.('rom_chart_title', { defaultValue: '角度趨勢圖' })} ({testSeconds}s)
          </button>
        </div>

        <div className="flex-grow-1" />

        {!testing ? (
          <button className="btn btn-success btn-sm me-2" onClick={onStartTesting}>
            {t?.('rom_start', { defaultValue: '開始施測' })}
          </button>
        ) : (
          <button className="btn btn-danger btn-sm me-2" onClick={onStopTesting}>
            {t?.('rom_stop', { defaultValue: '停止施測' })}
          </button>
        )}

        <HandRomCsvDownload
          history={history}
          testStartAtMs={testStartAtMs}
          visibleKeys={visibleSeriesKeys}
          jointsIndexByFinger={jointsIndexByFinger}
          filenamePrefix="HandROM_Test"
          label="CSV"
          className="btn btn-outline-primary btn-sm me-2"
          rebuildSignal={csvRebuildSignal}
        />

        <span className="small text-muted me-2">
          {t?.('rom_est_fps', { defaultValue: 'FPS' })}: {fps}
        </span>

        <button
          className="btn btn-sm btn-outline-secondary"
          onClick={onClose}
          aria-label={t?.('close', { defaultValue: '關閉' })}
        >
          ×
        </button>
      </div>

      {tab === 'live' ? renderChart('live') : renderChart('test')}
    </div>,
    document.body
  );
}
