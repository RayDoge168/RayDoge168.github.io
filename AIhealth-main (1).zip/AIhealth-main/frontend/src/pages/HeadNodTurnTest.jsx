// HeadNodTurnTest.jsx — Yaw / Pitch / Roll 測驗（步驟＋示意圖＋自動評分）
import React, { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { useTranslation } from 'react-i18next';

/**
 * props:
 * - liveAngles: { yaw, pitch, roll } 由 HeadPoseRecorder 送進來
 * - seconds?: 施測秒數（預設 8）
 * - images?: { yaw, pitch, roll } 示意圖路徑（預設 AAA1TEST.jpg/AAA2TEST.jpg）
 * - onClose?: () => void
 */
export default function HeadNodTurnTest({
  liveAngles = { yaw: 0, pitch: 0, roll: 0 },
  seconds = 8,
  images = { yaw: 'AAA1TEST.jpg', pitch: 'AAA2TEST.jpg', roll: 'AAA2TEST.jpg' },
  onClose,
}) {
  const { t } = useTranslation();

  // 測驗狀態
  const [running, setRunning] = useState(false);
  const [leftSec, setLeftSec] = useState(null);
  const [maxAbs, setMaxAbs] = useState({ yaw: 0, pitch: 0, roll: 0 });
  const [result, setResult] = useState(null); // { maxAbs, grades, stage }

  const timerRef = useRef(null);

  // 分級門檻（可自行微調）
  const yawCuts   = [15, 30, 45];  // 0 / 1 / 2 / 3
  const pitchCuts = [10, 20, 30];
  const rollCuts  = [8, 15, 20];

  const gradeByCuts = (v, cuts) => (v >= cuts[2] ? 3 : v >= cuts[1] ? 2 : v >= cuts[0] ? 1 : 0);

  // 每次 liveAngles 變動且測驗中：更新絕對值最大角度
  useEffect(() => {
    if (!running) return;
    setMaxAbs(prev => ({
      yaw:   Math.max(prev.yaw,   Math.abs(liveAngles.yaw   ?? 0)),
      pitch: Math.max(prev.pitch, Math.abs(liveAngles.pitch ?? 0)),
      roll:  Math.max(prev.roll,  Math.abs(liveAngles.roll  ?? 0)),
    }));
  }, [liveAngles, running]);

  // 結束並計分
  const endAndScore = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    setRunning(false);
    setLeftSec(null);

    const gYaw   = gradeByCuts(maxAbs.yaw, yawCuts);
    const gPitch = gradeByCuts(maxAbs.pitch, pitchCuts);
    const gRoll  = gradeByCuts(maxAbs.roll, rollCuts);

    // Heuristic Stage（示意，用於教學/展示）
    // 全部 >=2 → Stage 5；任兩個 >=2 → Stage 4；任一 >=1 → Stage 3；否則 Stage 2
    const arr = [gYaw, gPitch, gRoll];
    const n2  = arr.filter(g => g >= 2).length;
    const n1  = arr.filter(g => g >= 1).length;
    const stage = n2 === 3 ? 5 : n2 >= 2 ? 4 : n1 >= 1 ? 3 : 2;

    setResult({
      maxAbs,
      grades: { yaw: gYaw, pitch: gPitch, roll: gRoll },
      stage,
    });
  };

  // 開始/停止
  const start = () => {
    if (running) return;
    setResult(null);
    setMaxAbs({ yaw: 0, pitch: 0, roll: 0 });
    setRunning(true);

    let t = Math.max(3, Math.min(30, Math.round(seconds)));
    setLeftSec(t);
    timerRef.current = setInterval(() => {
      t -= 1; setLeftSec(t);
      if (t <= 0) endAndScore();
    }, 1000);
  };
  const stop = () => endAndScore();

  // 卸載清理
  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  const badge = (g) =>
    g >= 3 ? <span className="badge text-bg-success">3</span> :
    g === 2 ? <span className="badge text-bg-primary">2</span> :
    g === 1 ? <span className="badge text-bg-warning">1</span> :
              <span className="badge text-bg-secondary">0</span>;

  return (
    <div className="border rounded p-3 mt-3 position-relative" style={{ background: 'rgba(255,255,255,0.9)' }}>
      {/* 關閉鈕 */}
      {onClose && (
        <button
          className="btn btn-sm btn-outline-secondary position-absolute top-0 end-0 m-2"
          onClick={onClose}
          aria-label={t('close', { defaultValue: '關閉' })}
        >
          <X size={16} />
        </button>
      )}

      <h5 className="text-center mb-3">🧑‍🦱 {t('head_test_title', { defaultValue: '頭部動作測驗（Yaw / Pitch / Roll）' })}</h5>

      {/* 步驟＋示意圖 */}
      <div className="row g-3">
        <div className="col-md-4 text-center">
          <div className="small text-muted mb-1">Step 1 — Yaw（左右轉頭）</div>
          <img src={images.yaw} alt="Yaw demo" className="img-fluid rounded border" />
        </div>
        <div className="col-md-4 text-center">
          <div className="small text-muted mb-1">Step 2 — Pitch（點頭上下）</div>
          <img src={images.pitch} alt="Pitch demo" className="img-fluid rounded border" />
        </div>
        <div className="col-md-4 text-center">
          <div className="small text-muted mb-1">Step 3 — Roll（側傾左右）</div>
          <img src={images.roll} alt="Roll demo" className="img-fluid rounded border" />
        </div>
      </div>

      {/* 控制列 */}
      <div className="d-flex gap-2 justify-content-center align-items-center mt-3">
        {!running ? (
          <button className="btn btn-primary btn-sm" onClick={start}>
            {t('start_test', { defaultValue: '開始測驗' })} ({seconds}s)
          </button>
        ) : (
          <button className="btn btn-danger btn-sm" onClick={stop}>
            {t('stop_test', { defaultValue: '停止測驗' })}
          </button>
        )}
        {leftSec != null && (
          <span className="small text-muted">
            {t('rom_countdown', { defaultValue: '倒數' })}：{leftSec}s
          </span>
        )}
      </div>

      {/* 即時／最大值顯示 */}
      <div className="table-responsive mt-3" style={{ maxWidth: 640, margin: '0 auto' }}>
        <table className="table table-sm table-bordered align-middle">
          <thead>
            <tr>
              <th>指標</th>
              <th>目前值（°）</th>
              <th>本次最大（°）</th>
              <th>等級（0–3）</th>
            </tr>
          </thead>
          <tbody>
            {['yaw','pitch','roll'].map(k => {
              const cuts = k==='yaw'?yawCuts:k==='pitch'?pitchCuts:rollCuts;
              const g = gradeByCuts(maxAbs[k], cuts);
              return (
                <tr key={k}>
                  <td className="text-capitalize">{k}</td>
                  <td>{Math.round(liveAngles[k] ?? 0)}</td>
                  <td><strong>{Math.round(maxAbs[k])}</strong></td>
                  <td>{badge(g)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* 結果 */}
      {result && (
        <div className="text-center mt-2">
          <p className="mb-1">
            <strong>{t('suggested_stage', { defaultValue: '建議階段' })}：</strong>
            <span style={{ color: result.stage >= 4 ? 'green' : result.stage >= 3 ? '#a16207' : '#b91c1c' }}>
              {t('rom_stage', { defaultValue: '階段' })} {result.stage}
            </span>
          </p>
          <p className="small text-muted mb-0">
            {t('disclaimer_demo', { defaultValue: '此分級僅為示意與互動教學，非臨床診斷。' })}
          </p>
        </div>
      )}
    </div>
  );
}
