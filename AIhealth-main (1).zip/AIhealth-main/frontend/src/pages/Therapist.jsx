export default function Therapist() {
  return (
    <div className="container py-4">
      <h2 className="mb-4 text-center">治療師介面</h2>

      <div className="mb-5">
        <label className="form-label fw-bold">輸入病患 Email（最多綁定 2 位）</label>
        <input type="email" className="form-control mb-2" placeholder="patient1@example.com" />
        <input type="email" className="form-control" placeholder="patient2@example.com" />
      </div>

      <div className="mb-5">
        <label className="form-label fw-bold">選擇檢測項目（可複選）</label>
        <div className="form-check">
          <input className="form-check-input" type="checkbox" id="check1" />
          <label className="form-check-label" htmlFor="check1">手勢辨識</label>
        </div>
        <div className="form-check">
          <input className="form-check-input" type="checkbox" id="check2" />
          <label className="form-check-label" htmlFor="check2">肢體辨識</label>
        </div>
      </div>

      <div>
        <h5 className="fw-bold mb-3">檢測結果</h5>
        <ul className="list-group">
          <li className="list-group-item">patient1@example.com - 平衡正常</li>
          <li className="list-group-item">patient2@example.com - 有右手異常</li>
        </ul>
      </div>
    </div>
  )
}
