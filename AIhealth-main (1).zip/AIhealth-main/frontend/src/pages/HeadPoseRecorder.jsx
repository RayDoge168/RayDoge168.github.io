// HeadPoseRecorder.jsx — Head yaw/pitch/roll with overlay + bottom Dock (CSV, start/stop test)
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pose } from '@mediapipe/pose';
import * as cam from '@mediapipe/camera_utils';
import { useTranslation } from 'react-i18next';
import ReactDOM from 'react-dom';
import HeadPoseDock from './HeadPoseDock';

// ----- Video & View -----
const VIDEO_WIDTH = 640;
const VIDEO_HEIGHT = 480;
const SCREEN_MIRRORED = true; // selfie-like preview

// ----- BlazePose face-related indices -----
const IDX = {
  nose: 0,
  lEyeInner: 1,
  lEye: 2,
  lEyeOuter: 3,
  rEyeInner: 4,
  rEye: 5,
  rEyeOuter: 6,
  lEar: 7,
  rEar: 8,
  mouthL: 9,
  mouthR: 10,
};

// ---------- helpers ----------
const isVisible = (pt, th = 0.4) => pt && (pt.visibility == null || pt.visibility >= th);

function readCssVar(name, fallback) {
  if (typeof window === 'undefined') return fallback;
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function drawLine(ctx, ax, ay, bx, by, color, width = 3) {
  ctx.beginPath();
  ctx.moveTo(ax * VIDEO_WIDTH, ay * VIDEO_HEIGHT);
  ctx.lineTo(bx * VIDEO_WIDTH, by * VIDEO_HEIGHT);
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.lineCap = 'round';
  ctx.stroke();
}

function drawPoint(ctx, x, y, r = 4, color = '#ff6aa0') {
  ctx.beginPath();
  ctx.arc(x * VIDEO_WIDTH, y * VIDEO_HEIGHT, r, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
}

function drawLabel(ctx, text, x, y, color = '#00e') {
  ctx.font = '12px Arial';
  const pad = 3;
  const m = ctx.measureText(text);
  const w = m.width + pad * 2;
  const h = 14 + pad * 2;
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.fillRect(x * VIDEO_WIDTH, y * VIDEO_HEIGHT - h, w, h);
  ctx.fillStyle = color;
  ctx.fillText(text, x * VIDEO_WIDTH + pad, y * VIDEO_HEIGHT - pad);
}

function dist(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y;
  return Math.hypot(dx, dy);
}

function clamp(v, a, b) {
  return Math.max(a, Math.min(b, v));
}

/** Heuristic yaw/pitch/roll (degrees) from 2D face keypoints. */
function computeHeadAngles(lm, mirrored = true) {
  if (!lm) return { yaw: 0, pitch: 0, roll: 0 };

  const haveEyes = isVisible(lm[IDX.lEye]) && isVisible(lm[IDX.rEye]);
  const haveEars = isVisible(lm[IDX.lEar]) && isVisible(lm[IDX.rEar]);
  const haveNose = isVisible(lm[IDX.nose]);
  const haveMouth = isVisible(lm[IDX.mouthL]) && isVisible(lm[IDX.mouthR]);

  let roll = 0;
  if (haveEyes) {
    const L = lm[IDX.lEye], R = lm[IDX.rEye];
    const ang = Math.atan2(R.y - L.y, R.x - L.x) * (180 / Math.PI);
    roll = -ang;
  }

  let yaw = 0;
  if (haveEars && haveNose) {
    const dL = dist(lm[IDX.nose], lm[IDX.lEar]);
    const dR = dist(lm[IDX.nose], lm[IDX.rEar]);
    const norm = (dL + dR) || 1;
    const asym = (dL - dR) / norm; // left minus right
    yaw = clamp(asym * 90, -60, 60);
  }

  let pitch = 0;
  if (haveEyes && haveMouth && haveNose) {
    const eyeMid = { x: (lm[IDX.lEye].x + lm[IDX.rEye].x) / 2, y: (lm[IDX.lEye].y + lm[IDX.rEye].y) / 2 };
    const mouthMid = { x: (lm[IDX.mouthL].x + lm[IDX.mouthR].x) / 2, y: (lm[IDX.mouthL].y + lm[IDX.mouthR].y) / 2 };
    const dyBand = mouthMid.y - eyeMid.y;
    const ratio = dyBand ? (lm[IDX.nose].y - eyeMid.y) / dyBand : 0;
    pitch = clamp((0.5 - ratio) * 90, -60, 60);
  }

  if (mirrored) {
    yaw = -yaw;
    roll = -roll;
  }
  return { yaw: Math.round(yaw), pitch: Math.round(pitch), roll: Math.round(roll) };
}

export default function HeadPoseRecorder() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const cameraRef = useRef(null);
  const poseRef = useRef(null);
  const rafRef = useRef(0);

  const [angles, setAngles] = useState({ yaw: 0, pitch: 0, roll: 0 });
  const [downloadUrl, setDownloadUrl] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [timer, setTimer] = useState('');

  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);

  const { t } = useTranslation();

  // ---- chart & dock data (live/test series) ----
  const [headLiveSeconds, setHeadLiveSeconds] = useState(8);
  const [headTestSeconds, setHeadTestSeconds] = useState(8);
  const [headAvgDtMs, setHeadAvgDtMs] = useState(100);
  const [headLiveSeries, setHeadLiveSeries] = useState([]); // [{timestamp,yaw,pitch,roll}]
  const [headTestSeries, setHeadTestSeries] = useState([]);
  const [headTesting, setHeadTesting] = useState(false);
  const [headCountdown, setHeadCountdown] = useState(null);
  const headStartAtRef = useRef(null);
  const headTimerRef = useRef(null);
  const lastHeadTickRef = useRef(null);

  // ---- refs to avoid re-init Pose on state change ----
  const headLiveSecondsRef = useRef(headLiveSeconds);
  useEffect(() => { headLiveSecondsRef.current = headLiveSeconds; }, [headLiveSeconds]);
  const headTestingRef = useRef(headTesting);
  useEffect(() => { headTestingRef.current = headTesting; }, [headTesting]);
  const headAvgDtMsRef = useRef(headAvgDtMs);
  useEffect(() => { headAvgDtMsRef.current = headAvgDtMs; }, [headAvgDtMs]);

  // ---- colors ----
  const uiCyan = useMemo(() => String(readCssVar('--ui-cyan', '#22d3ee')), []);
  const uiMagenta = useMemo(() => String(readCssVar('--ui-magenta', '#e879f9')), []);
  const uiViolet = useMemo(() => String(readCssVar('--ui-violet', '#a78bfa')), []);

  // ---- recording mime detection ----
  const supportedMime = useMemo(() => {
    const c = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
    for (const m of c) {
      if (window.MediaRecorder?.isTypeSupported?.(m)) return m;
    }
    return '';
  }, []);

  useEffect(() => () => { if (downloadUrl) URL.revokeObjectURL(downloadUrl); }, [downloadUrl]);

  // ---- Pose init + draw loop (init once) ----
  useEffect(() => {
    let lastProcessed = 0;
    const pose = new Pose({ locateFile: f => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${f}` });
    pose.setOptions({
      modelComplexity: 1,
      smoothLandmarks: true,
      enableSegmentation: false,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.5,
      selfieMode: SCREEN_MIRRORED,
    });

    pose.onResults(res => {
      const now = Date.now();
      if (now - lastProcessed < 60) return; // throttle
      lastProcessed = now;

      const cvs = canvasRef.current;
      if (!cvs || !res?.image) return;
      const ctx = cvs.getContext('2d');
      ctx.save();
      ctx.clearRect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);
      ctx.drawImage(res.image, 0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);

      const lm = res.poseLandmarks;
      if (lm?.length) {
        const a = computeHeadAngles(lm, SCREEN_MIRRORED);
        setAngles(a);

        const leftEye = lm[IDX.lEye], rightEye = lm[IDX.rEye], nose = lm[IDX.nose];
        const mouthL = lm[IDX.mouthL], mouthR = lm[IDX.mouthR];

        // Roll overlay (eye line + label)
        if (isVisible(leftEye) && isVisible(rightEye)) {
          drawLine(ctx, leftEye.x, leftEye.y, rightEye.x, rightEye.y, uiCyan, 4);
          const ex = (leftEye.x + rightEye.x) / 2;
          const ey = (leftEye.y + rightEye.y) / 2;
          drawPoint(ctx, ex, ey, 4, uiCyan);
          drawLabel(ctx, `Roll: ${a.roll}°`, ex + 0.01, ey - 0.015, uiCyan);
        }

        // Pitch overlay (eyes -> nose -> mouth)
        if (isVisible(nose) && isVisible(leftEye) && isVisible(rightEye) && isVisible(mouthL) && isVisible(mouthR)) {
          const ex = (leftEye.x + rightEye.x) / 2;
          const ey = (leftEye.y + rightEye.y) / 2;
          const mx = (mouthL.x + mouthR.x) / 2;
          const my = (mouthL.y + mouthR.y) / 2;
          drawLine(ctx, ex, ey, nose.x, nose.y, uiMagenta, 3);
          drawLine(ctx, nose.x, nose.y, mx, my, uiMagenta, 3);
          drawPoint(ctx, nose.x, nose.y, 4.5, uiMagenta);
          drawLabel(ctx, `Pitch: ${a.pitch}°`, nose.x + 0.01, nose.y - 0.015, uiMagenta);
        }

        // Yaw overlay (ear baseline + nose->ears)
        if (isVisible(nose) && isVisible(lm[IDX.lEar]) && isVisible(lm[IDX.rEar])) {
          drawLine(ctx, lm[IDX.lEar].x, lm[IDX.lEar].y, lm[IDX.rEar].x, lm[IDX.rEar].y, 'rgba(255,255,255,0.35)', 2);
          drawLine(ctx, nose.x, nose.y, lm[IDX.lEar].x, lm[IDX.lEar].y, uiViolet, 2);
          drawLine(ctx, nose.x, nose.y, lm[IDX.rEar].x, lm[IDX.rEar].y, uiViolet, 2);
          drawLabel(ctx, `Yaw: ${a.yaw}°`, nose.x + 0.01, nose.y + 0.035, uiViolet);
        }

        // estimate dt (EMA) + update ref
        if (lastHeadTickRef.current) {
          const dt = now - lastHeadTickRef.current;
          const raw = headAvgDtMsRef.current ? headAvgDtMsRef.current * 0.9 + dt * 0.1 : dt;
          const nextDt = clamp(Math.round(raw), 30, 300);
          headAvgDtMsRef.current = nextDt;
          setHeadAvgDtMs(nextDt);
        }
        lastHeadTickRef.current = now;

        // live window size by seconds
        const liveWindow = Math.max(
          10,
          Math.round((headLiveSecondsRef.current * 1000) / Math.max(1, headAvgDtMsRef.current))
        );
        setHeadLiveSeries(prev => {
          const next = [...prev, { timestamp: now, ...a }];
          return next.length > liveWindow ? next.slice(next.length - liveWindow) : next;
        });

        if (headTestingRef.current) {
          setHeadTestSeries(prev => [...prev.slice(-999), { timestamp: now, ...a }]);
        }
      }

      ctx.restore();
    });

    poseRef.current = pose;

    const init = () => {
      if (!videoRef.current) {
        rafRef.current = requestAnimationFrame(init);
        return;
      }
      const camera = new cam.Camera(videoRef.current, {
        width: VIDEO_WIDTH,
        height: VIDEO_HEIGHT,
        onFrame: async () => {
          try {
            await pose.send({ image: videoRef.current });
          } catch (e) {
            // swallow send errors to avoid breaking loop
            if (typeof console !== 'undefined' && console.debug) {
              console.debug('[HeadPoseRecorder] pose.send error:', e);
            }
          }
        },
      });
      cameraRef.current = camera;
      camera.start().catch(err => {
        console.error('[HeadPoseRecorder] camera.start failed:', err);
        alert('無法啟動相機，請檢查瀏覽器權限或裝置是否支援。');
      });
    };
    rafRef.current = requestAnimationFrame(init);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);

      try {
        cameraRef.current?.stop?.();
      } catch (e) {
        if (typeof console !== 'undefined' && console.debug) {
          console.debug('[HeadPoseRecorder] camera.stop failed:', e);
        }
      }

      try {
        poseRef.current?.close?.();
      } catch (e) {
        if (typeof console !== 'undefined' && console.debug) {
          console.debug('[HeadPoseRecorder] pose.close failed:', e);
        }
      }

      // release MediaStream tracks
      try {
        const v = videoRef.current;
        const ms = v?.srcObject;
        if (ms && typeof ms.getTracks === 'function') {
          ms.getTracks().forEach(tr => tr.stop());
        }
        if (v) v.srcObject = null;
      } catch (_) {}
    };
    // init once
  }, []);

  // ---- recording (canvas capture) ----
  const startRecording = () => {
    if (!canvasRef.current || isRecording) return;
    try {
      const stream = canvasRef.current.captureStream(30);
      const rec = new MediaRecorder(stream, supportedMime ? { mimeType: supportedMime } : undefined);
      mediaRecorderRef.current = rec;
      chunksRef.current = [];
      rec.ondataavailable = e => { if (e.data?.size) chunksRef.current.push(e.data); };
      rec.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: supportedMime || 'video/webm' });
        if (downloadUrl) URL.revokeObjectURL(downloadUrl);
        setDownloadUrl(URL.createObjectURL(blob));
        setIsRecording(false);
      };
      rec.start();
      setIsRecording(true);

      let s = 8;
      setTimer(`${s}s`);
      const id = setInterval(() => {
        s -= 1;
        setTimer(s > 0 ? `${s}s` : t('recording_finished', { defaultValue: '錄影完成' }));
        if (s <= 0) {
          clearInterval(id);
          try {
            if (rec && typeof rec.stop === 'function' && rec.state !== 'inactive') {
              rec.stop();
            }
          } catch (e) {
            if (typeof console !== 'undefined' && console.debug) {
              console.debug('[MediaRecorder] stop() failed:', e);
            }
          }
        }
      }, 1000);
    } catch (err) {
      console.error(err);
      alert(t('recording_not_supported', { defaultValue: '此瀏覽器不支援畫面錄影。' }));
    }
  };

  // ---- head test start/stop ----
  const startHeadTest = () => {
    if (headTesting) return;
    setHeadTesting(true);
    setHeadTestSeries([]);
    headStartAtRef.current = Date.now();

    if (headTimerRef.current) { clearInterval(headTimerRef.current); headTimerRef.current = null; }
    let tsec = clamp(Math.round(headTestSeconds), 3, 30);
    setHeadCountdown(tsec);
    headTimerRef.current = setInterval(() => {
      tsec -= 1; setHeadCountdown(tsec);
      if (tsec <= 0) {
        clearInterval(headTimerRef.current);
        headTimerRef.current = null;
        setHeadTesting(false);
        setHeadCountdown(null);
      }
    }, 1000);
  };

  const stopHeadTest = () => {
    if (headTimerRef.current) { clearInterval(headTimerRef.current); headTimerRef.current = null; }
    setHeadTesting(false);
    setHeadCountdown(null);
  };

  useEffect(() => () => {
    if (headTimerRef.current) { clearInterval(headTimerRef.current); headTimerRef.current = null; }
  }, []);

  const fps = Math.round(1000 / Math.max(1, headAvgDtMs));
  const portalTarget = typeof document !== 'undefined' ? document.body : null;

  return (
    <div className="container py-4 text-center">
      <h2 className="mb-3">{t('head_pose_title', { defaultValue: '頭部姿態（Yaw/Pitch/Roll）' })}</h2>

      {/* hidden video for MediaPipe Pose */}
      <video
        ref={videoRef}
        playsInline
        muted
        autoPlay
        style={{ display: 'none' }}
        width={VIDEO_WIDTH}
        height={VIDEO_HEIGHT}
      />

      {/* output canvas */}
      <div className="guest-card d-inline-block p-2">
        <canvas
          ref={canvasRef}
          width={VIDEO_WIDTH}
          height={VIDEO_HEIGHT}
          className="rounded"
          style={{ border: '1px solid rgba(255,255,255,0.2)' }}
        />
      </div>

      {/* controls (video record like body) */}
      <div className="mt-3">
        <p className="mb-0">{t('countdown', { defaultValue: '倒數' })}: {timer || '--'}</p>
        <div className="d-flex gap-2 justify-content-center mt-2">
          <button
            className={`btn ${isRecording ? 'btn-secondary' : 'btn-accent btn-primary'}`}
            onClick={startRecording}
            disabled={isRecording}
          >
            {isRecording
              ? t('recording...', { defaultValue: '錄影中…' })
              : t('start_recording', { defaultValue: '開始施測' })}
          </button>
          {downloadUrl && (
            <a className="btn btn-success" href={downloadUrl} download="head_pose.webm">
              {t('download_recording', { defaultValue: '下載錄影' })}
            </a>
          )}
        </div>
      </div>

      {/* quick sliders for live/test seconds */}
      <div className="d-flex flex-wrap gap-3 justify-content-center align-items-center mt-3">
        <label className="small d-flex align-items-center gap-2">
          {t('rom_live_seconds', { defaultValue: '即時圖顯示秒數' })}：
          <input
            type="range" min="3" max="60"
            value={headLiveSeconds}
            onChange={e => setHeadLiveSeconds(parseInt(e.target.value, 10))}
          />
          <strong>{headLiveSeconds}s</strong>
        </label>
        <label className="small d-flex align-items-center gap-2">
          {t('rom_test_seconds', { defaultValue: '施測秒數' })}：
          <input
            type="range" min="3" max="30"
            value={headTestSeconds}
            onChange={e => setHeadTestSeconds(parseInt(e.target.value, 10))}
          />
          <strong>{headTestSeconds}s</strong>
        </label>
        <span className="small text-muted">
          {t('rom_est_fps', { defaultValue: '估計 FPS' })}: {fps}
        </span>
      </div>

      {/* live numbers table */}
      <div className="table-responsive mt-3" style={{ maxWidth: 500, margin: '0 auto' }}>
        <table className="table table-sm table-bordered align-middle">
          <thead>
            <tr>
              <th>Yaw (°)</th>
              <th>Pitch (°)</th>
              <th>Roll (°)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{Math.round(angles.yaw ?? 0)}</td>
              <td>{Math.round(angles.pitch ?? 0)}</td>
              <td>{Math.round(angles.roll ?? 0)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* bottom dock (portal) */}
      {portalTarget && ReactDOM.createPortal(
        <HeadPoseDock
          liveSeries={headLiveSeries}
          testSeries={headTestSeries}
          fps={fps}
          isTesting={headTesting}
          countdown={headCountdown}
          testSeconds={headTestSeconds}
          testStartAt={headStartAtRef.current}
          onStartTest={startHeadTest}
          onStopTest={stopHeadTest}
        />,
        portalTarget
      )}
    </div>
  );
}
