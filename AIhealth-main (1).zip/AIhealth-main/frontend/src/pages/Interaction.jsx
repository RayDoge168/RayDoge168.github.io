import React, { useEffect, useMemo, useState, Suspense } from 'react';
import { Hand, ActivitySquare, X } from 'lucide-react';
// ✅ 改用懶載入，降低初始 bundle
const HandGestureRecorder = React.lazy(() => import('./HandGestureRecorder'));
const BodyPoseRecorder  = React.lazy(() => import('./BodyPoseRecorder'));
import { useTranslation } from 'react-i18next';

const MODES = { NONE: null, HAND: 'hand', BODY: 'body' };

export default function Interaction() {
  const { t } = useTranslation();
  const [mode, setMode] = useState(MODES.NONE);

  // ——— 初始：從 URL 或 localStorage 還原模式 ———
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const q = params.get('mode');
      const saved = localStorage.getItem('interactionMode');
      const init = (q === MODES.HAND || q === MODES.BODY) ? q
                : (saved === MODES.HAND || saved === MODES.BODY) ? saved
                : MODES.NONE;
      setMode(init);
    } catch {}
  }, []);

  // ——— 同步 URL 與 localStorage（可深連結）———
  useEffect(() => {
    try {
      const url = new URL(window.location.href);
      if (mode) url.searchParams.set('mode', mode);
      else url.searchParams.delete('mode');
      window.history.replaceState({}, '', url);
      localStorage.setItem('interactionMode', mode ?? '');
    } catch {}
  }, [mode]);

  // ——— 快鍵：H 開手勢、B 開肢體、Esc 關閉 ———
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'h' || e.key === 'H') setMode(MODES.HAND);
      else if (e.key === 'b' || e.key === 'B') setMode(MODES.BODY);
      else if (e.key === 'Escape') setMode(MODES.NONE);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ——— 滑過預載：降低懶載入延遲 ———
  const prefetchHand = () => import('./HandGestureRecorder');
  const prefetchBody = () => import('./BodyPoseRecorder');

  const isHand = mode === MODES.HAND;
  const isBody = mode === MODES.BODY;

  return (
    <div className="container py-4">
      <h2 className="mb-4 text-center">
        {t('interaction_title', { defaultValue: '互動偵測' })}
      </h2>

      <div className="row" role="tablist" aria-label="interaction modes">
        <div className="col-md-6 mb-3">
          <button
            role="tab"
            aria-selected={isHand}
            onMouseEnter={prefetchHand}
            onFocus={prefetchHand}
            onClick={() => setMode(MODES.HAND)}
            className={`interaction-btn p-3 border text-center rounded shadow-sm w-100 d-flex align-items-center justify-content-center ${isHand ? 'bg-primary text-white' : 'bg-light'}`}
            title={t('open_gesture_recognition', { defaultValue: '開啟手勢辨識' })}
          >
            <Hand className="me-2" />
            {t('gesture_area', { defaultValue: '手勢區' })}
          </button>
        </div>

        <div className="col-md-6 mb-3">
          <button
            role="tab"
            aria-selected={isBody}
            onMouseEnter={prefetchBody}
            onFocus={prefetchBody}
            onClick={() => setMode(MODES.BODY)}
            className={`interaction-btn p-3 border text-center rounded shadow-sm w-100 d-flex align-items-center justify-content-center ${isBody ? 'bg-primary text-white' : 'bg-light'}`}
            title={t('body_recognition_open', { defaultValue: '開啟肢體辨識' })}
          >
            <ActivitySquare className="me-2" />
            {t('body_area', { defaultValue: '肢體區' })}
          </button>
        </div>
      </div>

      {/* ---- 動態區域：手勢 / 肢體 二擇一 ---- */}
      {(isHand || isBody) && (
        <div className="position-relative border rounded shadow mb-4">
          <button
            onClick={() => setMode(MODES.NONE)}
            className="btn btn-sm btn-danger position-absolute top-0 end-0 m-2"
            title={t('close_recognition', { defaultValue: '關閉' })}
            aria-label={t('close_recognition', { defaultValue: '關閉辨識' })}
          >
            <X size={16} />
          </button>

          <Suspense
            fallback={
              <div
                className="d-flex justify-content-center align-items-center"
                style={{ minHeight: 340 }}
              >
                <div className="spinner-border" role="status" aria-label="loading" />
              </div>
            }
          >
            {isHand && <HandGestureRecorder />}
            {isBody && <BodyPoseRecorder />}
          </Suspense>
        </div>
      )}

      <p className="text-muted mt-3 text-center">
        {t('auto_check_hint', { defaultValue: '提示：可用鍵盤 H / B 快速切換，Esc 關閉；按鈕滑過會預載元件，加速開啟。' })}
      </p>

      <style>{`
        .interaction-btn { transition: background-color .25s ease, color .25s ease; }
        .interaction-btn:hover { background-color: #e2f0ff; }
      `}</style>
    </div>
  );
}

