import { useState } from "react";
import { Modal, Button, Toast, ToastContainer } from "react-bootstrap";
import PrivacyPolicyModal from "../components/PrivacyPolicyModal";
import { useTranslation } from 'react-i18next'
import { useNavigate } from 'react-router-dom';


export default function Register() {
  const [agreed, setAgreed] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [countryCode, setCountryCode] = useState('+886');
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState('patient');
  const [error, setError] = useState(null);
  const { t } = useTranslation();
  const navigate = useNavigate();

  const handleCheckboxChange = (e) => {
    setAgreed(e.target.checked);
  };

  const handleShowModal = (e) => {
    e.preventDefault(); // 防止跳頁
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!agreed) {
  setShowToast(true);
  return; // 停止表單送出
}

    if (password !== passwordConfirm) {
      setError('兩次輸入的密碼不一致');
      return;
}
    // 這裡可以接註冊 API 呼叫
    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('password', password);
    formData.append('password_confirmation', passwordConfirm);
    formData.append('phone', countryCode + phone);
    formData.append('role', role);
    formData.append('agree_terms', agreed ? '1' : '0');
    formData.append('agree_privacy', agreed ? '1' : '0');
    
try {
    setLoading(true);
    const res = await fetch('https://medical.futlife.fr.to/api/auth/register/', {
      method: 'POST',
      body: formData,
});

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || '註冊失敗');
}
setShowSuccessToast(true);
setTimeout(() => {
  setShowSuccessToast(false);
  navigate('/login');
}, 2000);


} catch (err) {
  setError(err.message);
}finally {
  setLoading(false);
  }
  }
  return (
    <div className="container py-5" style={{ maxWidth: 400, position: "relative" }}>
      <h2 className="text-center mb-4">{t('register')}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
  <input type="email" className="form-control" placeholder={t('form_email')} value={email} onChange={(e) => setEmail(e.target.value)} />
</div>

        <div className="mb-3">
          <input type="password" className="form-control" placeholder={t('form_password')} value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
          <div className="mb-3">
        <input type="password" className="form-control" placeholder="再次輸入密碼" value={passwordConfirm} onChange={(e) => setPasswordConfirm(e.target.value)} required />
          </div>
        <div className="mb-3">
          <input type="text" className="form-control" placeholder={t('form_name')} value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
  {/* 國碼 + 電話號碼欄位 */}
<div className="mb-3 row gx-2">
  <div className="col-4">
    <select className="form-select" value={countryCode} onChange={(e) => setCountryCode(e.target.value)}>
      <option value="+886">+886 台灣</option>
      <option value="+86">+86 中國</option>
      <option value="+1">+1 美國</option>
      <option value="+81">+81 日本</option>
    </select>
  </div>
  <div className="col-8">
    <input type="tel" className="form-control" placeholder="手機號碼" value={phone} onChange={(e) => setPhone(e.target.value)} required />
  </div>
</div>

{/* 角色選擇欄位 */}
<div className="mb-3">
  <label className="form-label">角色</label>
  <select className="form-select" value={role} onChange={(e) => setRole(e.target.value)} required>
    <option value="patient">病患</option>
    <option value="therapist">治療師</option>
    <option value="caregiver">照護者</option>
  </select>
</div>

        <div className="form-check mb-3">
          <input
            className="form-check-input"
            type="checkbox"
            id="agreeCheck"
            checked={agreed}
            onChange={handleCheckboxChange}
          />
          <label className="form-check-label" htmlFor="agreeCheck">
            {t('form_agree_prefix')}
            <a href="#" onClick={handleShowModal}>
              {t('form_agree_link')}
            </a>
          </label>
        </div>
  
        <button type="submit" className="btn btn-success w-100 rounded-pill shadow-sm" disabled={loading}>
  {loading ? '提交中...' : t('register')}
</button>

      </form>
       {error && <div className="alert alert-danger text-center my-2">{error}</div>}   
  
      {/* 個資同意書 Modal */}
      <PrivacyPolicyModal show={showModal} onClose={handleCloseModal} />
  
      {/* Toast 提醒訊息 */}
      <ToastContainer position="top-center" className="p-3">
  <Toast
    bg="success"
    onClose={() => setShowSuccessToast(false)}
    show={showSuccessToast}
    delay={2000}
    autohide
  >
    <Toast.Body className="text-white">
      註冊成功，2秒後將導向登入頁
    </Toast.Body>
  </Toast>

  <Toast
    bg="warning"
    onClose={() => setShowToast(false)}
    show={showToast}
    delay={2000}
    autohide
  >
    <Toast.Body className="text-dark">
      請先勾選並同意個資與服務條款！
    </Toast.Body>
  </Toast>
</ToastContainer>

    </div>
  );
}