import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import GuestTopBar from './GuestTopBar';
import {
  Heart, Stethoscope, Footprints, CheckCircle2, Pill, Dumbbell, Clock
} from 'lucide-react';
import './GuestPage.css';

export default function GuestMyHealth() {
  const { t } = useTranslation();

  const [name, setName] = useState('Guest');
  const [reminders, setReminders] = useState([
    {
      id: 'med',
      icon: <Pill size={18} />,
      title: t('take_bp_med', { defaultValue: 'Take your blood pressure medication' }),
      time: '10:00 AM',
      done: false,
    },
    {
      id: 'walk',
      icon: <Dumbbell size={18} />,
      title: t('walk_30m', { defaultValue: 'Eat lunch and walk for 30 mins' }),
      time: '12:00 PM',
      done: false,
    },
  ]);

  useEffect(() => {
    try {
      const n = window?.localStorage?.getItem('userName');
      if (n) setName(n);
    } catch {}
  }, []);

  const toggleDone = (id) => {
    setReminders((list) =>
      list.map((r) => (r.id === id ? { ...r, done: !r.done } : r))
    );
  };

  return (
    <div className="ha-bg">
      {/* ✅ 保留 Guest 系列的 BAR */}
      <GuestTopBar active="my-health" />

      <div className="container py-5">
        {/* ===== Header ===== */}
        <header className="mb-4">
          <h1 className="ha-h1">{t('my_health_dashboard', { defaultValue: 'My Health Dashboard' })}</h1>
          <p className="text-muted m-0">
            {t('welcome_summary', {
              defaultValue: `Welcome back, ${name}! Here's a summary of your health.`,
            })}
          </p>
        </header>

        {/* ===== Snapshot ===== */}
        <section className="mb-4">
          <h2 className="mh-section-title">
            {t('todays_snapshot', { defaultValue: "Today's Health Snapshot" })}
          </h2>

          <div className="row g-3">
            {/* Heart Rate */}
            <div className="col-12 col-md-4">
              <article className="mh-metric">
                <div className="icon"><Heart size={22} /></div>
                <div className="label">{t('heart_rate', { defaultValue: 'Heart Rate' })}</div>
                <div className="value">
                  <span className="num">72</span>
                  <span className="unit">&nbsp;bpm</span>
                </div>
                <div className="mh-chip mh-chip--up">+2% {t('vs_yesterday', { defaultValue: 'vs yesterday' })}</div>
              </article>
            </div>

            {/* Blood Pressure */}
            <div className="col-12 col-md-4">
              <article className="mh-metric">
                <div className="icon"><Stethoscope size={22} /></div>
                <div className="label">{t('blood_pressure', { defaultValue: 'Blood Pressure' })}</div>
                <div className="value">
                  <span className="num">120/80</span>
                </div>
                <div className="mh-sub">{t('normal', { defaultValue: 'Normal' })}</div>
              </article>
            </div>

            {/* Steps */}
            <div className="col-12 col-md-4">
              <article className="mh-metric">
                <div className="icon"><Footprints size={22} /></div>
                <div className="label">{t('steps', { defaultValue: 'Steps' })}</div>
                <div className="value">
                  <span className="num">3,500</span>
                </div>
                <div className="mh-chip mh-chip--up">+5% {t('vs_yesterday', { defaultValue: 'vs yesterday' })}</div>
              </article>
            </div>
          </div>
        </section>

        {/* ===== Main grid: Reminders + Tips ===== */}
        <section className="mb-2">
          <div className="row g-3">
            {/* Left: Health Reminders */}
            <div className="col-12 col-lg-7">
              <h2 className="mh-section-title">{t('health_reminders', { defaultValue: 'Health Reminders' })}</h2>

              <div className="d-flex flex-column gap-3">
                {reminders.map((r) => (
                  <button
                    key={r.id}
                    className={`mh-reminder ${r.done ? 'is-done' : ''}`}
                    onClick={() => toggleDone(r.id)}
                    aria-pressed={r.done}
                    title={r.done ? t('mark_undone', { defaultValue: 'Mark as not done' }) : t('mark_done', { defaultValue: 'Mark as done' })}
                  >
                    <div className="left">
                      <div className="bullet">{r.icon}</div>
                      <div className="text">
                        <div className="title">{r.title}</div>
                        <div className="time"><Clock size={14} className="me-1" />{r.time}</div>
                      </div>
                    </div>
                    <div className="right">
                      <CheckCircle2 size={20} />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Right: Personalized Health Tips */}
            <div className="col-12 col-lg-5">
              <h2 className="mh-section-title">{t('personalized_tips', { defaultValue: 'Personalized Health Tips' })}</h2>

              <article className="mh-tip">
                <img
                  src="https://images.unsplash.com/photo-1547721064-da6cfb341d50?q=80&w=1200&auto=format&fit=crop"
                  alt=""
                  aria-hidden="true"
                />
                <div className="content">
                  <div className="tip-tag">{t('tip_of_day', { defaultValue: 'Tip of the Day' })}</div>
                  <h3 className="tip-title">{t('stay_hydrated', { defaultValue: 'Stay Hydrated' })}</h3>
                  <p className="tip-desc">
                    {t('stay_hydrated_desc', {
                      defaultValue:
                        'Aim for at least 8 glasses of water to maintain healthy blood pressure.',
                    })}
                  </p>
                </div>
              </article>

              <article className="mh-tip">
                <img
                  src="https://images.unsplash.com/photo-1584467735871-6b9365d43a21?q=80&w=1200&auto=format&fit=crop"
                  alt=""
                  aria-hidden="true"
                />
                <div className="content">
                  <div className="tip-tag">{t('activity_suggestion', { defaultValue: 'Activity Suggestion' })}</div>
                  <h3 className="tip-title">{t('gentle_stretch', { defaultValue: 'Gentle Stretching' })}</h3>
                  <p className="tip-desc">
                    {t('gentle_stretch_desc', {
                      defaultValue:
                        'Improve flexibility and reduce stiffness with simple daily stretches.',
                    })}
                  </p>
                </div>
              </article>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
