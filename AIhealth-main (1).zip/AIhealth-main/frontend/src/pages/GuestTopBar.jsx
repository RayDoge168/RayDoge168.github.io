import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Droplets, Bell, Pencil, Languages, Check, Accessibility, RotateCcw } from 'lucide-react';

export default function GuestTopBar() {
  const { t, i18n } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();

  const [guestName, setGuestName] = useState('GUEST');
  const [editingName, setEditingName] = useState(false);

  // ===== 語言選單 =====
  const [langOpen, setLangOpen] = useState(false);
  const [langUp, setLangUp] = useState(false);
  const langBtnRef = useRef(null);
  const langMenuRef = useRef(null);
  const SUPPORTED = ['en', 'zh', 'ja', 'nl'];
  const currentLang = (i18n.language || 'en').split('-')[0];

  // ===== 顯示設定（高齡友善） =====
  const [dispOpen, setDispOpen] = useState(false);
  const [dispUp, setDispUp] = useState(false);
  const dispBtnRef = useRef(null);
  const dispMenuRef = useRef(null);

  // 0=100%, 1=112.5%, 2=125%, 4=130%, 5=150%, 3=200%(預設), 6=250%, 7=300%
  const [fontLevel, setFontLevel] = useState(() => Number(localStorage.getItem('haFontLevel') ?? '3'));
  const [contrast, setContrast] = useState(() => {
    const saved = localStorage.getItem('haContrast');
    return saved == null ? true : saved === '1';
  });
  const [firstApplied, setFirstApplied] = useState(false);

  // 窄螢幕偵測（Bar 需要時可換行）
  const [isNarrow, setIsNarrow] = useState(() => (typeof window !== 'undefined' ? window.innerWidth <= 540 : false));

  // 字級 class 對應
  const ALL_FONT_CLASSES = ['ha-font-lg','ha-font-xl','ha-font-130','ha-font-150','ha-font-2x','ha-font-250','ha-font-300'];
  const LEVEL_TO_CLASS = { 0:'', 1:'ha-font-lg', 2:'ha-font-xl', 4:'ha-font-130', 5:'ha-font-150', 3:'ha-font-2x', 6:'ha-font-250', 7:'ha-font-300' };

  const computeFlip = useCallback((btnEl, menuEl, setUp) => {
    if (!btnEl || !menuEl) return;
    const btn = btnEl.getBoundingClientRect();
    const menuHeight = Math.min(menuEl.scrollHeight, 400);
    const spaceBelow = window.innerHeight - btn.bottom;
    const spaceAbove = btn.top;
    setUp(spaceBelow < menuHeight && spaceAbove > spaceBelow);
  }, []);

  // 讀取名稱
  useEffect(() => {
    try {
      const n = window?.localStorage?.getItem('userName');
      if (n) setGuestName(n);
    } catch {}
  }, []);

  // 點外面關閉兩個選單
  useEffect(() => {
    const onDocClick = (e) => {
      if (langOpen) {
        const insideBtn = langBtnRef.current?.contains(e.target);
        const insideMenu = langMenuRef.current?.contains(e.target);
        if (!insideBtn && !insideMenu) setLangOpen(false);
      }
      if (dispOpen) {
        const insideBtn = dispBtnRef.current?.contains(e.target);
        const insideMenu = dispMenuRef.current?.contains(e.target);
        if (!insideBtn && !insideMenu) setDispOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [langOpen, dispOpen]);

  // 路由切換 / 視窗縮放
  useEffect(() => { setLangOpen(false); setDispOpen(false); }, [location.pathname]);
  useEffect(() => {
    let timer = null;
    const onResize = () => {
      setLangOpen(false); setDispOpen(false);
      clearTimeout(timer);
      timer = setTimeout(() => setIsNarrow(window.innerWidth <= 540), 120);
    };
    window.addEventListener('resize', onResize);
    return () => { window.removeEventListener('resize', onResize); clearTimeout(timer); };
  }, []);

  // ===== 套用顯示偏好（全站） =====
  const applyDisplayPrefs = useCallback((level = fontLevel, hc = contrast) => {
    const html = document.documentElement;
    html.classList.remove(...ALL_FONT_CLASSES);
    const cls = LEVEL_TO_CLASS[level] || '';
    if (cls) html.classList.add(cls);
    html.classList.toggle('ha-contrast', hc);
    html.classList.add('ha-senior'); // 放大觸控範圍與行高
  }, [fontLevel, contrast]);

  // 初訪 → 預設 2× + 高對比
  useEffect(() => {
    if (firstApplied) return;
    const hasVisited = localStorage.getItem('haSeniorVisited');
    if (!hasVisited) {
      setFontLevel(3);
      setContrast(true);
      localStorage.setItem('haFontLevel', '3');
      localStorage.setItem('haContrast', '1');
      localStorage.setItem('haSeniorVisited', '1');
    }
    setFirstApplied(true);
  }, [firstApplied]);

  // 實際套用 + 持久化
  useEffect(() => {
    applyDisplayPrefs(fontLevel, contrast);
    localStorage.setItem('haFontLevel', String(fontLevel));
    localStorage.setItem('haContrast', contrast ? '1' : '0');
  }, [fontLevel, contrast, applyDisplayPrefs]);

  // 選單定位與焦點
  useEffect(() => {
    if (langOpen) {
      computeFlip(langBtnRef.current, langMenuRef.current, setLangUp);
      setTimeout(() => langMenuRef.current?.querySelector('button.ha-lang-item')?.focus(), 0);
    } else { langBtnRef.current?.focus(); }
  }, [langOpen, computeFlip]);

  useEffect(() => {
    if (dispOpen) {
      computeFlip(dispBtnRef.current, dispMenuRef.current, setDispUp);
      setTimeout(() => dispMenuRef.current?.querySelector('.ha-chip')?.focus(), 0);
    } else { dispBtnRef.current?.focus(); }
  }, [dispOpen, computeFlip]);

  // 語言切換
  const changeLang = async (lng) => {
    await i18n.changeLanguage(lng);
    localStorage.setItem('i18nextLng', lng);
    localStorage.setItem('lang', lng);
    setLangOpen(false);
  };

  const labelFor = (lng) => {
    switch (lng) {
      case 'zh': return t('language_zh', { defaultValue: '繁體中文' });
      case 'ja': return t('language_ja', { defaultValue: '日本語' });
      case 'nl': return t('language_nl', { defaultValue: 'Nederlands' });
      default:   return t('language_en', { defaultValue: 'English' });
    }
  };

  // 根據所有語言標籤動態計算「語言按鈕」與「選單」的最小寬度（跟字級一起放大）
  const langLabels = SUPPORTED.map((lng) => labelFor(lng) || '');
  const longestCh = Math.max(...langLabels.map(s => s.length));
  // ch 會隨 font-size 放大，clamp 避免過大或過小
  const langBtnMinWidth = `clamp(200px, ${Math.min(40, longestCh + 8)}ch, 5px)`;
  const langMenuMinWidth = `clamp(220px, ${Math.min(44, longestCh + 12)}ch, 560px)`;

  const saveName = () => {
    const name = (guestName || '').trim() || 'GUEST';
    try {
      window.localStorage.setItem('userName', name);
      window.dispatchEvent(new CustomEvent('user-name-updated', { detail: { name } }));
    } catch {}
    setEditingName(false);
  };

  // /guest 內就捲動；不在就導到對應 hash
  const goOrScroll = useCallback((hashId) => {
    if (/^\/guest(\/|$)/.test(location.pathname)) {
      const el = document.getElementById(hashId);
      if (el) {
        const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        el.scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth', block: 'start' });
        return;
      }
    }
    navigate(`/guest#${hashId}`);
  }, [location.pathname, navigate]);

  const isActive = (path) => location.pathname === path;

  const moveMenuFocus = (container, dir) => {
    if (!container) return;
    const items = Array.from(container.querySelectorAll('button[role="menuitem"],button.ha-lang-item,.ha-chip,.ha-toggle'));
    if (!items.length) return;
    const idx = items.findIndex((el) => el === document.activeElement);
    const next = idx === -1 ? 0 : (idx + dir + items.length) % items.length;
    items[next].focus();
  };

  const resetPrefs = () => {
    setFontLevel(0);
    setContrast(false);
    localStorage.setItem('haFontLevel', '0');
    localStorage.setItem('haContrast', '0');
    applyDisplayPrefs(0, false);
  };

  // Bar：需要時換行，避免擠壓
  const shouldWrap = isNarrow || fontLevel >= 6; // 2.5× 或 3× 強制可換行
  const navLinksStyle = {
    display: 'flex',
    flexWrap: shouldWrap ? 'wrap' : 'nowrap',
    whiteSpace: shouldWrap ? 'normal' : 'nowrap',
    overflowX: shouldWrap ? 'visible' : 'auto',
    overflowY: 'hidden',
    rowGap: 8,
    columnGap: 8,
    maxWidth: shouldWrap ? '100%' : 'min(55vw, 720px)'
  };

  return (
    <nav className="ha-nav ha-nav--compact" role="navigation" aria-label={t('guest_navigation', { defaultValue: 'Guest navigation' })}>
      {/* Left: Brand + Links */}
      <div className="ha-left" style={{ alignItems: 'center', minWidth: 0 }}>
        <div className="ha-brand" style={{ display: 'flex', alignItems: 'center', whiteSpace: 'nowrap' }}>
          <Droplets size={22} />
          <span className="ms-2 fw-bold">HealthAssist</span>
        </div>

        <ul className="ha-nav-links" role="tablist" aria-label="sections" style={navLinksStyle}>
          <li className={isActive('/') ? 'is-active' : ''}><NavLink to="/">{t('home', { defaultValue: 'Home' })}</NavLink></li>
          <li className={/^\/guest(\/|$)/.test(location.pathname) ? 'is-active' : ''}><NavLink to="/guest">{t('rehab', { defaultValue: 'Rehabilitation' })}</NavLink></li>
          <li className={isActive('/my-health') ? 'is-active' : ''}><NavLink to="/my-health">{t('my_health', { defaultValue: 'My Health' })}</NavLink></li>
          <li><button type="button" className="ha-chip" onClick={() => goOrScroll('exercises')} title={t('exercises', { defaultValue: 'Exercises' })} style={{ flex: '0 0 auto' }}>{t('exercises', { defaultValue: 'Exercises' })}</button></li>
          <li><button type="button" className="ha-chip" onClick={() => goOrScroll('progress')}  title={t('progress', { defaultValue: 'Progress' })}  style={{ flex: '0 0 auto' }}>{t('progress', { defaultValue: 'Progress' })}</button></li>
        </ul>
      </div>

      {/* Right: Display / Lang / Bell / Name */}
      <div className="ha-right" style={{ flexWrap: 'nowrap' }}>
        {/* 顯示設定（高齡友善） */}
        <div className="ha-display" ref={dispMenuRef} style={{ position: 'relative' }}>
          <button
            ref={dispBtnRef}
            type="button"
            className="ha-icon-btn ha-display-btn"
            aria-haspopup="menu"
            aria-expanded={dispOpen}
            aria-controls="display-menu"
            aria-label={t('display_settings', { defaultValue: 'Display settings' })}
            title={t('display_settings', { defaultValue: 'Display settings' })}
            onClick={() => setDispOpen((v) => !v)}
            onKeyDown={(e) => {
              if (['ArrowDown','Enter',' '].includes(e.key)) { e.preventDefault(); setDispOpen(true); }
              if (e.key === 'Escape') setDispOpen(false);
            }}
          >
            <Accessibility size={18} />
            <span className="ha-display-label">{t('textsize', { defaultValue: 'TEXT SIZE' })}</span>
          </button>

          {dispOpen && (
            <div
              id="display-menu"
              role="menu"
              className={`ha-display-menu ${dispUp ? 'is-up' : ''}`}
              tabIndex={-1}
              onKeyDown={(e) => {
                if (e.key === 'Escape') { e.preventDefault(); setDispOpen(false); }
                if (e.key === 'ArrowDown') { e.preventDefault(); moveMenuFocus(dispMenuRef.current, +1); }
                if (e.key === 'ArrowUp')   { e.preventDefault(); moveMenuFocus(dispMenuRef.current, -1); }
                if (e.key === 'Home')      { e.preventDefault(); moveMenuFocus(dispMenuRef.current,  1e9); }
                if (e.key === 'End')       { e.preventDefault(); moveMenuFocus(dispMenuRef.current, -1e9); }
              }}
            >
              <div className="ha-display-row" role="group" aria-label={t('text_size', { defaultValue: 'Text size' })}>
                <span className="ha-display-title">{t('text_size', { defaultValue: 'Text size' })}</span>
                <div className="ha-display-actions" role="radiogroup" aria-label={t('text_size', { defaultValue: 'Text size' })}>
                  <button className={`ha-chip ${fontLevel===0?'is-active':''}`} onClick={() => setFontLevel(0)} role="radio" aria-checked={fontLevel===0} title="100%">A</button>
                  <button className={`ha-chip ${fontLevel===1?'is-active':''}`} onClick={() => setFontLevel(1)} role="radio" aria-checked={fontLevel===1} title="112.5%">A+</button>
                  <button className={`ha-chip ${fontLevel===2?'is-active':''}`} onClick={() => setFontLevel(2)} role="radio" aria-checked={fontLevel===2} title="125%">A++</button>
                  <button className={`ha-chip ${fontLevel===4?'is-active':''}`} onClick={() => setFontLevel(4)} role="radio" aria-checked={fontLevel===4} title="130%">A×1.3</button>
                  <button className={`ha-chip ${fontLevel===5?'is-active':''}`} onClick={() => setFontLevel(5)} role="radio" aria-checked={fontLevel===5} title="150%">A×1.5</button>
                  <button className={`ha-chip ${fontLevel===3?'is-active':''}`} onClick={() => setFontLevel(3)} role="radio" aria-checked={fontLevel===3} title="200%">A×2</button>
                  <button className={`ha-chip ${fontLevel===6?'is-active':''}`} onClick={() => setFontLevel(6)} role="radio" aria-checked={fontLevel===6} title="250%">A×2.5</button>
                  <button className={`ha-chip ${fontLevel===7?'is-active':''}`} onClick={() => setFontLevel(7)} role="radio" aria-checked={fontLevel===7} title="300%">A×3</button>
                </div>
              </div>

              <div className="ha-display-row" role="group" aria-label={t('contrast', { defaultValue: 'Contrast' })}>
                <span className="ha-display-title">{t('high_contrast', { defaultValue: 'High contrast' })}</span>
                <button
                  className={`ha-toggle ${contrast?'is-on':'is-off'}`}
                  onClick={() => setContrast((v)=>!v)}
                  aria-pressed={contrast}
                  title={contrast ? t('turn_off', { defaultValue: 'Turn off' }) : t('turn_on', { defaultValue: 'Turn on' })}
                >
                  <span className="dot" />
                </button>
              </div>

              <div className="ha-display-row">
                <button className="ha-primary w-100" onClick={() => { setFontLevel(3); setContrast(true); }} title={t('apply_senior_preset', { defaultValue: 'Apply senior preset' })}>
                  {t('apply_senior_preset', { defaultValue: 'Apply senior preset' })}
                </button>
              </div>

              <div className="ha-display-row">
                <button type="button" className="ha-reset w-100" onClick={() => { setFontLevel(0); setContrast(false); resetPrefs(); }} title={t('reset_defaults', { defaultValue: 'Reset to defaults' })}>
                  <RotateCcw size={16} />
                  <span className="ms-2">{t('reset_defaults', { defaultValue: 'Reset to defaults' })}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 語言切換（按鈕寬度自動根據內容變寬） */}
        <div className="ha-lang" ref={langMenuRef} style={{ position: 'relative' }}>
          <button
            ref={langBtnRef}
            type="button"
            className="ha-icon-btn ha-lang-btn"
            aria-haspopup="menu"
            aria-expanded={langOpen}
            aria-controls="lang-menu"
            aria-label={t('language', { defaultValue: 'Language' })}
            title={t('language', { defaultValue: 'Language' })}
            onClick={() => setLangOpen((v) => !v)}
            onKeyDown={(e) => {
              if (['ArrowDown','Enter',' '].includes(e.key)) { e.preventDefault(); setLangOpen(true); }
              if (e.key === 'Escape') setLangOpen(false);
            }}
            style={{
              minWidth: langBtnMinWidth,  // ★ 依語言長度 + 字級動態變寬
              justifyContent: 'space-between',
              paddingInline: 12
            }}
          >
            <Languages size={18} />
            <span className="ha-lang-label" style={{ whiteSpace: 'nowrap' }}>{labelFor(currentLang)}</span>
          </button>

          {langOpen && (
            <div
              id="lang-menu"
              role="menu"
              className={`ha-lang-menu ${langUp ? 'is-up' : ''}`}
              tabIndex={-1}
              style={{ minWidth: langMenuMinWidth }}  // ★ 選單寬度也跟著加大
              onKeyDown={(e) => {
                if (e.key === 'Escape') { e.preventDefault(); setLangOpen(false); }
                if (e.key === 'ArrowDown') { e.preventDefault(); moveMenuFocus(langMenuRef.current, +1); }
                if (e.key === 'ArrowUp')   { e.preventDefault(); moveMenuFocus(langMenuRef.current, -1); }
                if (e.key === 'Home')      { e.preventDefault(); moveMenuFocus(langMenuRef.current,  1e9); }
                if (e.key === 'End')       { e.preventDefault(); moveMenuFocus(langMenuRef.current, -1e9); }
              }}
            >
              {SUPPORTED.map((lng) => (
                <button
                  key={lng}
                  role="menuitemradio"
                  aria-checked={currentLang === lng}
                  className={`ha-lang-item ${currentLang === lng ? 'is-active' : ''}`}
                  onClick={() => changeLang(lng)}
                >
                  <span>{labelFor(lng)}</span>
                  {currentLang === lng && <Check size={16} aria-hidden className="ms-2" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 通知 */}
        <button className="ha-icon-btn" title={t('notifications', { defaultValue: 'Notifications' })} aria-label={t('notifications', { defaultValue: 'Notifications' })}>
          <Bell size={20} />
        </button>

        {/* 名稱編輯 */}
        {!editingName ? (
          <button type="button" className="ha-name-btn" onClick={() => setEditingName(true)} title={t('edit_name', { defaultValue: 'Edit name' })}>
            <span className="avatar" aria-hidden>👤</span>
            <span className="name">{guestName}</span>
            <Pencil size={16} className="ms-1" />
          </button>
        ) : (
          <div className="ha-name-edit">
            <input
              className="form-control form-control-sm"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') setEditingName(false); }}
              autoFocus
              aria-label={t('your_name', { defaultValue: 'Your name' })}
            />
            <button type="button" className="btn btn-sm btn-primary" onClick={saveName}>
              {t('save', { defaultValue: 'Save' })}
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
