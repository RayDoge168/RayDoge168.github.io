import { Link } from 'react-router-dom'

export default function Forgot() {
  return (
    <div className="container py-5" style={{ maxWidth: 400 }}>
      <h2 className="text-center mb-4">忘記密碼</h2>

      <form>
        <div className="mb-3">
          <input type="email" className="form-control" placeholder="請輸入註冊用 Email" />
        </div>
        <button type="submit" className="btn btn-secondary w-100 rounded-pill shadow-sm mb-3" disabled>
          發送重設連結
        </button>
      </form>

      <div className="alert alert-warning text-center small">
        ⚠ 此功能尚未啟用，日後會提供 Email 重設連結功能。
      </div>

      <div className="text-center">
        <Link to="/login" className="btn btn-link small text-decoration-none">返回登入頁</Link>
      </div>
    </div>
  )
}
