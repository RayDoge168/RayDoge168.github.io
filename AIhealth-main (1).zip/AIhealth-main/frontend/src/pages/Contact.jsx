export default function Contact() {
    return (
      <div className="container py-5">
        <h1 className="mb-4">聯絡我們</h1>
        <p>若您有任何合作提案、產品諮詢或媒體聯繫，歡迎透過以下方式與我們聯絡：</p>
        <ul>
          <li>📧 Email：contact@NOVATERA AI.com</li>
          <li>📞 電話：(02) 1234-5678</li>
          <li>🏢 地址：台北市科技路123號9樓</li>
        </ul>
      </div>
    )
  }