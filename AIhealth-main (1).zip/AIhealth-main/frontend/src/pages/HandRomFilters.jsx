// HandRomFilters.jsx
import React from 'react';
import { useTranslation } from 'react-i18next';
import { FINGERS, JOINTS } from './handRomFiltersUtils'; // ⬅️ 改從 utils 取用

export default function HandRomFilters({
  fingers, setFingers,
  joints, setJoints,
  onReset,
  className = 'd-flex flex-wrap gap-3 justify-content-center align-items-center'
}) {
  const { t } = useTranslation();

  const toggle = (objSetter, key) =>
    objSetter(prev => ({ ...prev, [key]: !prev[key] }));

  const allFingersOn = FINGERS.every(f => fingers[f]);
  const allJointsOn  = JOINTS.every(j => joints[j]);

  const setAll = (objSetter, keys, on) => {
    const next = {};
    keys.forEach(k => { next[k] = !!on; });
    objSetter(next);
  };

  return (
    <div className={className}>
      <div className="d-flex align-items-center gap-2">
        <strong>{t('rom_finger_groups', { defaultValue: 'Finger Groups' })}:</strong>
        {FINGERS.map(f => (
          <label key={f} className="form-check d-flex align-items-center gap-1">
            <input
              type="checkbox"
              className="form-check-input"
              checked={!!fingers[f]}
              onChange={() => toggle(setFingers, f)}
            />
            <span>{t(`finger_${f}`, { defaultValue: f })}</span>
          </label>
        ))}
        <button
          className="btn btn-light btn-sm"
          onClick={() => setAll(setFingers, FINGERS, !allFingersOn)}
        >
          {allFingersOn
            ? t('hide_all', { defaultValue: 'Hide All' })
            : t('show_all', { defaultValue: 'Show All' })}
        </button>
      </div>

      <div className="d-flex align-items-center gap-2">
        <strong>{t('rom_joint_groups', { defaultValue: 'Joint Groups' })}:</strong>
        {JOINTS.map(j => (
          <label key={j} className="form-check d-flex align-items-center gap-1">
            <input
              type="checkbox"
              className="form-check-input"
              checked={!!joints[j]}
              onChange={() => toggle(setJoints, j)}
            />
            <span>{t(`joint_${j}`, { defaultValue: j })}</span>
          </label>
        ))}
        <button
          className="btn btn-light btn-sm"
          onClick={() => setAll(setJoints, JOINTS, !allJointsOn)}
        >
          {allJointsOn
            ? t('hide_all', { defaultValue: 'Hide All' })
            : t('show_all', { defaultValue: 'Show All' })}
        </button>
      </div>

      {onReset && (
        <button className="btn btn-outline-secondary btn-sm" onClick={onReset}>
          {t('reset', { defaultValue: 'Reset' })}
        </button>
      )}
    </div>
  );
}
