export default function Product() {
    return (
      <div className="container py-5">
        <h1 className="mb-4">產品與研發</h1>
        <p>
          團隊正在研發結合 AI、影像偵測與臨床應用的數位化功能評估工具，協助醫療人員提升評估效率與準確性。
        </p>
        <ul>
          <li>數位化 Purdue Pegboard Test</li>
          <li>AI 動作分析模組</li>
          <li>個案回饋互動介面</li>
        </ul>
      </div>
    )
  }
  