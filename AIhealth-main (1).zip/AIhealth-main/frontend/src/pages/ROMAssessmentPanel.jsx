// ROMAssessmentPanel.jsx — 整合 HandRomDock（純 JS 版）
import React, { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';
import HandRomDock from './HandRomDock';
import HandRomCsvDownload from './HandRomCsvDownload';
import HandRomFilters from './HandRomFilters';
import { filterFingerSeriesKeys } from './handRomFiltersUtils';
import RomAngleChart from './RomAngleChart'; // 若不想在面板內再顯示圖，可刪除這行及下方區塊
import { useTranslation } from 'react-i18next';

// 五段 ROM 分級閾值（示意）
const ROM_THRESHOLDS = {
  thumb: { MCP: [10, 30, 50, 70, 90],  IP: [20, 40, 60, 80, 100] },
  index: { MCP: [20, 40, 60, 80, 100], PIP: [30, 50, 70, 90, 110], DIP: [20, 40, 60, 80, 100] },
  middle:{ MCP: [20, 40, 60, 80, 100], PIP: [30, 50, 70, 90, 110], DIP: [20, 40, 60, 80, 100] },
  ring:  { MCP: [20, 40, 60, 80, 100], PIP: [30, 50, 70, 90, 110], DIP: [20, 40, 60, 80, 100] },
  pinky: { MCP: [20, 40, 60, 80, 100], PIP: [30, 50, 70, 90, 110], DIP: [20, 40, 60, 80, 100] },
};

const FINGER_LABELS = ['thumb', 'index', 'middle', 'ring', 'pinky'];
const JOINTS_PER_FINGER = {
  thumb: ['MCP', 'IP'],
  index: ['MCP', 'PIP', 'DIP'],
  middle:['MCP', 'PIP', 'DIP'],
  ring:  ['MCP', 'PIP', 'DIP'],
  pinky: ['MCP', 'PIP', 'DIP'],
};

// CSV 欄位順序（完整）
const COLUMN_ORDER = [
  ['thumb','MCP'], ['thumb','IP'],
  ['index','MCP'], ['index','PIP'], ['index','DIP'],
  ['middle','MCP'], ['middle','PIP'], ['middle','DIP'],
  ['ring','MCP'], ['ring','PIP'], ['ring','DIP'],
  ['pinky','MCP'], ['pinky','PIP'], ['pinky','DIP'],
];

// 顏色與線型
const fingerColors = {
  thumb: '#ff6384',
  index: '#36a2eb',
  middle:'#4bc0c0',
  ring:  '#9966ff',
  pinky: '#f6c026',
};
const LINE_DASH = { MCP: [], PIP: [6, 3], DIP: [2, 3], IP: [6, 3] };

// 畫面寬高（與 HandGestureRecorder 的 canvas 相同）
const W = 540, H = 310;

export default function ROMAssessmentPanel({ landmarks, onDataUpdate }) {
  const { t } = useTranslation();

  // ===== 狀態 =====
  const [jointAngles, setJointAngles] = useState({});
  const [brunnstromStage, setBrunnstromStage] = useState(null);
  const [fuglScore, setFuglScore] = useState(0);

  const [history, setHistory] = useState([]);     // 測試紀錄（施測）
  const [liveHistory, setLiveHistory] = useState([]); // 即時歷史窗口
  const [testing, setTesting] = useState(false);
  const [countdown, setCountdown] = useState(null);

  const [avgDtMs, setAvgDtMs] = useState(100);
  const lastTickRef = useRef(null);
  const timerRef = useRef(null);
  const testStartAtRef = useRef(null);

  const [liveSeconds, setLiveSeconds] = useState(8);
  const [testSeconds, setTestSeconds] = useState(8);

  // Dock
  const [showDock, setShowDock] = useState(true);

  // CSV 重建 signal（點擊圖表時 +1）
  const [csvRebuildSignal, setCsvRebuildSignal] = useState(0);
  const requestCsvRebuild = () => setCsvRebuildSignal((n) => n + 1);

  // Filter（手指/關節）— 預設全開
  const [fingerOn, setFingerOn] = useState({
    thumb: true, index: true, middle: true, ring: true, pinky: true
  });
  const [jointOn, setJointOn] = useState({
    MCP: true, PIP: true, DIP: true, IP: true
  });

  // 可見子集（依 Filter）
  const VISIBLE_FINGERS = FINGER_LABELS.filter(f => fingerOn[f]);
  const VISIBLE_JOINTS_PER_FINGER = {};
  VISIBLE_FINGERS.forEach(f => {
    VISIBLE_JOINTS_PER_FINGER[f] = (JOINTS_PER_FINGER[f] || []).filter(j => jointOn[j]);
  });

  // 給 RomAngleChart 的 i18n 標籤
  const labelFor = (finger, joint) =>
    `${t(`finger_${finger}`, { defaultValue: finger })} - ${t(`joint_${joint}`, { defaultValue: joint })}`;

  // 可見序列鍵 & joints index map（CSV 用）
  const JOINT_INDEX = {};
  Object.entries(JOINTS_PER_FINGER).forEach(([f, arr]) => {
    JOINT_INDEX[f] = {};
    arr.forEach((j, i) => { JOINT_INDEX[f][j] = i; });
  });

  const ALL_SERIES_KEYS = COLUMN_ORDER.map(([f, j]) => `${f}_${j}`);
  const VISIBLE_SERIES = filterFingerSeriesKeys(ALL_SERIES_KEYS, fingerOn, jointOn);

  // ===== 工具 =====
  const getAngle = (a, b, c) => {
    const v1 = [a[0] - b[0], a[1] - b[1]];
    const v2 = [c[0] - b[0], c[1] - b[1]];
    const mag1 = Math.hypot(v1[0], v1[1]);
    const mag2 = Math.hypot(v2[0], v2[1]);
    if (mag1 === 0 || mag2 === 0) return 180;
    const dot = v1[0]*v2[0] + v1[1]*v2[1];
    const cosTheta = Math.min(Math.max(dot / (mag1 * mag2), -1), 1);
    return Math.acos(cosTheta) * (180 / Math.PI);
  };

  const getJointColor = (finger, jointName, angle) => {
    const thresholds = ROM_THRESHOLDS[finger]?.[jointName] || [0, 25, 50, 75, 100];
    if (angle >= thresholds[4]) return 'green';
    if (angle >= thresholds[3]) return 'limegreen';
    if (angle >= thresholds[2]) return 'orange';
    if (angle >= thresholds[1]) return 'darkorange';
    return 'red';
  };

  // ===== 角度計算 & 歷史推入 =====
  useEffect(() => {
    if (!landmarks || landmarks.length !== 21) {
      setJointAngles({});
      if (!testing) { setBrunnstromStage(null); setFuglScore(0); }
      return;
    }

    const now = Date.now();

    if (lastTickRef.current) {
      const dt = now - lastTickRef.current;
      setAvgDtMs(prev => {
        const ema = prev ? prev * 0.9 + dt * 0.1 : dt;
        return Math.max(30, Math.min(300, Math.round(ema)));
      });
    }
    lastTickRef.current = now;

    const pts = landmarks.map(pt => [pt.x * W, pt.y * H]);
    const data = {
      thumb:  [ getAngle(pts[0], pts[1],  pts[2]),  getAngle(pts[2],  pts[3],  pts[4])  ],
      index:  [ getAngle(pts[0], pts[5],  pts[6]),  getAngle(pts[5],  pts[6],  pts[7]),  getAngle(pts[6],  pts[7],  pts[8])  ],
      middle: [ getAngle(pts[0], pts[9],  pts[10]), getAngle(pts[9],  pts[10], pts[11]), getAngle(pts[10], pts[11], pts[12]) ],
      ring:   [ getAngle(pts[0], pts[13], pts[14]), getAngle(pts[13], pts[14], pts[15]), getAngle(pts[14], pts[15], pts[16]) ],
      pinky:  [ getAngle(pts[0], pts[17], pts[18]), getAngle(pts[17], pts[18], pts[19]), getAngle(pts[18], pts[19], pts[20]) ],
    };
    setJointAngles(data);

    // 簡易判定
    const canExtendAll = ['index', 'middle', 'ring', 'pinky'].every(f => data[f]?.[1] < 20);
    const canMakeFist  = ['index', 'middle', 'ring', 'pinky'].every(f => (data[f]?.[0] > 70 && data[f]?.[1] > 90));
    let stage = 2;
    if (canMakeFist && canExtendAll) stage = 5;
    else if (canMakeFist) stage = 3;
    else if (data.thumb?.[0] > 40 || data.index?.[0] > 40) stage = 4;
    setBrunnstromStage(stage);

    let computedScore = 0;
    if (canMakeFist) computedScore += 2;
    if (canExtendAll) computedScore += 2;
    if (data.thumb && data.index && data.thumb[1] > 40 && data.index[2] > 60) computedScore += 2;
    if (data.index && data.index[1] > 60 && data.index[2] > 60) computedScore += 2;
    setFuglScore(computedScore);

    if (testing) {
      setHistory(prev => [...prev.slice(-999), { timestamp: now, angles: data }]);
    }

    const liveWindow = Math.max(10, Math.round((liveSeconds * 1000) / Math.max(1, avgDtMs)));
    setLiveHistory(prev => {
      const next = [...prev, { timestamp: now, angles: data }];
      return next.length > liveWindow ? next.slice(next.length - liveWindow) : next;
    });

    if (onDataUpdate) {
      onDataUpdate({ angles: data, brunnstrom: stage, score: computedScore, timestamp: now });
    }
  }, [landmarks, testing, liveSeconds, avgDtMs, onDataUpdate]);

  // ===== CSV：當下角度快照 =====
  const exportCurrentCSV = () => {
    const rows = [['Finger', 'Joint', 'Angle(deg)']];
    for (const finger of FINGER_LABELS) {
      const joints = JOINTS_PER_FINGER[finger];
      const angles = jointAngles[finger] || [];
      joints.forEach((jn, j) => {
        const a = angles[j];
        rows.push([finger, jn, a !== undefined ? Math.round(a) : '']);
      });
    }
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'ROM_CurrentSnapshot.csv';
    a.click();
  };

  // ===== 施測控制 =====
  const startTesting = () => {
    if (testing) return;
    setTesting(true);
    setHistory([]);
    setBrunnstromStage(null);
    setFuglScore(0);
    testStartAtRef.current = Date.now();

    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }

    let tLeft = Math.max(3, Math.min(30, Math.round(testSeconds)));
    setCountdown(tLeft);
    timerRef.current = setInterval(() => {
      tLeft -= 1;
      setCountdown(tLeft);
      if (tLeft <= 0) {
        clearInterval(timerRef.current);
        timerRef.current = null;
        setTesting(false);
        setCountdown(null);
      }
    }, 1000);
  };

  const stopTesting = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    setTesting(false);
    setCountdown(null);
  };

  useEffect(() => () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
  }, []);

  const estFps = Math.round(1000 / Math.max(1, avgDtMs));

  return (
    <>
      <div className="bg-white border p-3 rounded mt-3">
        <h5 className="text-center mb-3">🧠 {t('rom_title', { defaultValue: 'ROM 評估' })}</h5>

        {(!landmarks || landmarks.length !== 21) && (
          <div className="alert alert-warning text-center py-1 mb-2">
            ⚠️ {t('rom_hand_not_detected', { defaultValue: '未偵測到完整手部關鍵點' })}
          </div>
        )}

        {/* 篩選器（可移除） */}
        <HandRomFilters
          fingers={fingerOn} setFingers={setFingerOn}
          joints={jointOn} setJoints={setJointOn}
        />

        {/* 秒數 / FPS */}
        <div className="d-flex flex-wrap gap-3 justify-content-center align-items-center mb-2 mt-2">
          <label className="small d-flex align-items-center gap-2">
            {t('rom_live_seconds', { defaultValue: '即時圖顯示秒數' })}：
            <input type="range" min="3" max="60" value={liveSeconds}
              onChange={e => setLiveSeconds(parseInt(e.target.value, 10))} />
            <strong>{liveSeconds}s</strong>
          </label>
          <label className="small d-flex align-items-center gap-2">
            {t('rom_test_seconds', { defaultValue: '施測秒數' })}：
            <input type="range" min="3" max="30" value={testSeconds}
              onChange={e => setTestSeconds(parseInt(e.target.value, 10))} />
            <strong>{testSeconds}s</strong>
          </label>
          <span className="small text-muted">
            {t('rom_est_fps', { defaultValue: '估計 FPS' })}: {estFps} ({avgDtMs}ms)
          </span>
        </div>

        {/* 當下角度表 */}
        <table className="table table-sm table-bordered">
          <thead>
            <tr>
              <th>{t('rom_finger', { defaultValue: '手指' })}</th>
              <th>{t('rom_joint', { defaultValue: '關節' })}</th>
              <th>{t('rom_angle', { defaultValue: '角度' })}</th>
            </tr>
          </thead>
          <tbody>
            {FINGER_LABELS.map(finger => {
              const joints = JOINTS_PER_FINGER[finger];
              const angles = jointAngles[finger] || [];
              return joints.map((jn, j) => {
                const a = angles[j];
                const color = a !== undefined ? getJointColor(finger, jn, a) : undefined;
                return (
                  <tr key={`${finger}-${jn}`}>
                    {j === 0 ? <td rowSpan={joints.length}>{t(`finger_${finger}`, { defaultValue: finger })}</td> : null}
                    <td>{t(`joint_${jn}`, { defaultValue: jn })}</td>
                    <td style={{ color }}>{a !== undefined ? `${Math.round(a)}°` : '—'}</td>
                  </tr>
                );
              });
            })}
          </tbody>
        </table>

        {/* 指標 + 面板內 CSV */}
        <div className="text-center">
          <p>
            <strong>{t('rom_brunnstrom', { defaultValue: 'Brunnstrom 階段' })}：</strong>
            <span style={{ color: brunnstromStage >= 4 ? 'green' : 'orange' }}>
              {t('rom_stage', { defaultValue: '階段' })} {brunnstromStage ?? '?'}
            </span>
          </p>
          <p>
            <strong>{t('rom_fugl_score', { defaultValue: '手部綜合分數' })}：</strong>
            <span style={{ color: fuglScore >= 6 ? 'green' : 'orange' }}>
              {fuglScore} / 8
            </span>
          </p>

          <div className="d-flex gap-2 justify-content-center">
            <button className="btn btn-outline-secondary btn-sm" onClick={exportCurrentCSV}>
              {t('rom_download_csv', { defaultValue: '下載快照 CSV' })}
            </button>
            <HandRomCsvDownload
              history={history}
              testStartAtMs={testStartAtRef.current}
              visibleKeys={VISIBLE_SERIES}
              jointsIndexByFinger={JOINT_INDEX}
              filenamePrefix="HandROM_Test"
              label={t('rom_download_rom_csv', { defaultValue: '下載 ROM 施測 CSV' })}
              className="btn btn-outline-primary btn-sm"
              rebuildSignal={csvRebuildSignal}
            />
          </div>
        </div>

        {/* （可選）面板內折線圖；點擊可觸發 CSV 重建 */}
        {liveHistory.length >= 2 && (
          <div className="mt-4" onClick={requestCsvRebuild}>
            <RomAngleChart
              history={liveHistory}
              fingers={VISIBLE_FINGERS}
              jointsPerFinger={VISIBLE_JOINTS_PER_FINGER}
              fingerColors={fingerColors}
              lineDashByJoint={LINE_DASH}
              labelFor={labelFor}
              title={`${t('rom_live_chart_title', { defaultValue: '即時角度' })}（${liveSeconds}s）`}
              height={280}
              showLegend
              yRange={{ min: 0, max: 140 }}
              maintainAspectRatio={false}
              animations={false}
            />
          </div>
        )}
        {history.length >= 2 && (
          <div className="mt-4" onClick={requestCsvRebuild}>
            <RomAngleChart
              history={history}
              fingers={VISIBLE_FINGERS}
              jointsPerFinger={VISIBLE_JOINTS_PER_FINGER}
              fingerColors={fingerColors}
              lineDashByJoint={LINE_DASH}
              labelFor={labelFor}
              title={`${t('rom_chart_title', { defaultValue: '角度趨勢圖' })}（${testSeconds}s）`}
              height={280}
              showLegend
              yRange={{ min: 0, max: 140 }}
              maintainAspectRatio={false}
              animations={false}
            />
          </div>
        )}

        {/* 施測控制（面板內） */}
        <div className="text-center mt-3">
          {!testing ? (
            <button className="btn btn-primary btn-sm" onClick={startTesting}>
              {t('rom_start', { defaultValue: '開始施測' })} ({testSeconds}s)
            </button>
          ) : (
            <button className="btn btn-danger btn-sm" onClick={stopTesting}>
              {t('rom_stop', { defaultValue: '停止施測' })}
            </button>
          )}
          {countdown !== null && (
            <p className="mt-2">
              {t('rom_countdown', { defaultValue: '倒數' })}：{countdown}s
            </p>
          )}
        </div>
      </div>

      {/* ===== 底部 Dock（抽離元件） ===== */}
      {(showDock && (liveHistory.length >= 2 || history.length >= 2)) && (
        <HandRomDock
          show
          onClose={() => setShowDock(false)}
          liveHistory={liveHistory}
          history={history}
          liveSeconds={liveSeconds}
          testSeconds={testSeconds}
          testing={testing}
          onStartTesting={startTesting}
          onStopTesting={stopTesting}
          fps={Math.round(1000 / Math.max(1, avgDtMs))}
          fingers={VISIBLE_FINGERS}
          jointsPerFinger={VISIBLE_JOINTS_PER_FINGER}
          fingerColors={fingerColors}
          lineDashByJoint={LINE_DASH}
          labelFor={labelFor}
          visibleSeriesKeys={VISIBLE_SERIES}
          jointsIndexByFinger={JOINT_INDEX}
          testStartAtMs={testStartAtRef.current}
          csvRebuildSignal={csvRebuildSignal}
          onRequestCsvRebuild={requestCsvRebuild}
          t={t}
          yRange={{ min: 0, max: 140 }}
        />
      )}

      {/* 關閉後的浮動重開按鈕 */}
      {!showDock && (liveHistory.length >= 2 || history.length >= 2) &&
        ReactDOM.createPortal(
          <button className="rom-dock-fab btn btn-primary btn-sm" onClick={() => setShowDock(true)}>
            ROM
          </button>,
          document.body
        )
      }
    </>
  );
}
