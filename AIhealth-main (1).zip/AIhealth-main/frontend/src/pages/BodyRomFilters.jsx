// BodyRomFilters.jsx
import React from 'react';
import { useTranslation } from 'react-i18next';

const PARTS = ['Shoulder','Elbow','Wrist','Hip','Knee','Ankle'];

export default function BodyRomFilters({
  parts, setParts,        // {Shoulder:true, ...}
  sides, setSides,        // {R:true, L:true}
  onReset,                // 可選
  className = 'd-flex flex-wrap gap-3 justify-content-center align-items-center'
}) {
  const { t } = useTranslation();

  const togglePart = (p) => setParts(prev => ({ ...prev, [p]: !prev[p] }));
  const toggleSide = (k) => setSides(prev => ({ ...prev, [k]: !prev[k] }));

  const allPartsOn  = PARTS.every(p => parts[p]);
  const anyPartsOn  = PARTS.some(p => parts[p]);
  const allSidesOn  = sides.R && sides.L;

  const setAllParts = (on) => {
    const next = {}; PARTS.forEach(p => next[p] = !!on);
    setParts(next);
  };
  const setAllSides = (on) => setSides({ R: !!on, L: !!on });

  return (
    <div className={className}>
      {/* 側別 */}
      <div className="d-flex align-items-center gap-2">
        <strong>{t('side', { defaultValue: 'Side' })}:</strong>
        <label className="form-check d-flex align-items-center gap-1">
          <input type="checkbox" className="form-check-input" checked={sides.R} onChange={() => toggleSide('R')} />
          <span>{t('right_hand', { defaultValue: 'Right' })}</span>
        </label>
        <label className="form-check d-flex align-items-center gap-1">
          <input type="checkbox" className="form-check-input" checked={sides.L} onChange={() => toggleSide('L')} />
          <span>{t('left_hand', { defaultValue: 'Left' })}</span>
        </label>
        <button className="btn btn-light btn-sm" onClick={() => setAllSides(!allSidesOn)}>
          {allSidesOn ? t('hide_all', { defaultValue: 'Hide All' }) : t('show_all', { defaultValue: 'Show All' })}
        </button>
      </div>

      {/* 關節群組 */}
      <div className="d-flex align-items-center gap-2">
        <strong>{t('joint_groups', { defaultValue: 'Joint Groups' })}:</strong>
        {PARTS.map(p => (
          <label key={p} className="form-check d-flex align-items-center gap-1">
            <input type="checkbox" className="form-check-input" checked={!!parts[p]} onChange={() => togglePart(p)} />
            <span>{t(`joint_${p}`, { defaultValue: p })}</span>
          </label>
        ))}
        <button className="btn btn-light btn-sm" onClick={() => setAllParts(!allPartsOn)}>
          {(allPartsOn && anyPartsOn) ? t('hide_all', { defaultValue: 'Hide All' }) : t('show_all', { defaultValue: 'Show All' })}
        </button>
      </div>

      {onReset && (
        <button className="btn btn-outline-secondary btn-sm" onClick={onReset}>
          {t('reset', { defaultValue: 'Reset' })}
        </button>
      )}
    </div>
  );
}

/** 幫助方法：依過濾條件產生可見的 series key（維持傳入順序） */
export function filterSeriesKeys(allKeys, parts, sides) {
  return allKeys.filter(k => {
    const side = k.startsWith('R') ? 'R' : 'L';
    const part = k.split('-')[1];
    return !!sides[side] && !!parts[part];
  });
}
