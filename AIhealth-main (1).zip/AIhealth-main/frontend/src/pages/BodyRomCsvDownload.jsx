// BodyRomCsvDownload.jsx
import React, { useEffect, useState } from 'react';

// 將名稱清洗成安全的檔名前綴
function sanitizePrefix(s, fallback = 'BodyROM_Test') {
  const raw = (s ?? '').toString().trim();
  if (!raw) return fallback;
  const underscored = raw.replace(/\s+/g, '_');
  // 只保留英數、底線、減號、括號、點
  const safe = underscored.replace(/[^\w\-().]/g, '');
  return (safe || fallback).slice(0, 48);
}

export default function BodyRomCsvDownload({
  history,               // [{ timestamp:number, angles: { 'R-Shoulder':deg, ... } }]
  testStartAtMs,         // number | null
  columnKeys,            // ['R-Shoulder', 'R-Elbow', ...]
  filenamePrefix,        // 不給時自動用 localStorage.userName
  label = 'CSV',
  className = 'btn btn-outline-primary btn-sm',
  rebuildSignal = 0,     // 讓外部手動觸發 CSV 重建
}) {
  const [url, setUrl] = useState(null);
  const [name, setName] = useState(null);

  // 取得使用者名稱（GuestPage 以 'userName' 儲存）
  const userName = typeof window !== 'undefined'
    ? (window.localStorage.getItem('userName') || '')
    : '';

  // 最終前綴：prop > userName > 預設
  const effectivePrefix = sanitizePrefix(filenamePrefix ?? userName, 'BodyROM_Test');

  const revoke = () => { if (url) URL.revokeObjectURL(url); };

  const buildCsvText = (hist) => {
    if (!hist?.length) return null;
    const startTs = (typeof testStartAtMs === 'number' ? testStartAtMs : hist[0].timestamp);
    const startISO = new Date(startTs).toISOString();

    const cols = ['t_offset_s', 'timestamp_iso', ...columnKeys.map(k => k.replace('-', '_'))];
    const headerMeta = [
      `TestStartISO,${startISO}`,
      `FilePrefix,${effectivePrefix}`,
    ];
    const rows = [cols];

    for (const rec of hist) {
      const offsetSec = ((rec.timestamp - startTs) / 1000).toFixed(2);
      const iso = new Date(rec.timestamp).toISOString();
      const angleRow = columnKeys.map((k) => {
        const v = rec.angles?.[k];
        return typeof v === 'number' ? Math.round(v).toString() : '';
      });
      rows.push([offsetSec, iso, ...angleRow]);
    }
    return [headerMeta.join('\n'), rows.map(r => r.join(',')).join('\n')].join('\n');
  };

  useEffect(() => {
    revoke();
    if (!history?.length) { setUrl(null); setName(null); return; }

    const csv = buildCsvText(history);
    if (!csv) { setUrl(null); setName(null); return; }

    const blob = new Blob([csv], { type: 'text/csv' });
    const newUrl = URL.createObjectURL(blob);
    const startISO = new Date(typeof testStartAtMs === 'number' ? testStartAtMs : history[0].timestamp)
      .toISOString().replace(/[:.]/g, '-');

    setUrl(newUrl);
    setName(`${effectivePrefix}_${startISO}.csv`);

    return () => { URL.revokeObjectURL(newUrl); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [history, testStartAtMs, rebuildSignal, effectivePrefix]);

  useEffect(() => () => revoke(), []); // 卸載清理

  if (!url) return <button className={className} disabled>{label}</button>;
  return <a className={className} href={url} download={name}>{label}</a>;
}
