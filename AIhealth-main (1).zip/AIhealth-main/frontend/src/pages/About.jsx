export default function About() {
    return (
      <div className="container py-5">
        <h1 className="mb-4">關於我們</h1>
        <p>
          云磐淞科（NOVATERA AI）致力於智慧醫療領域的創新發展，專注於人機互動技術、職能治療工具與 AI 輔助評估方案。
        </p>
        <p>
          我們秉持以人為本、科技創新的理念，與各大醫療機構、學研單位合作，打造兼具實用性與精準度的健康科技產品。
        </p>
      </div>
    )
  }
  