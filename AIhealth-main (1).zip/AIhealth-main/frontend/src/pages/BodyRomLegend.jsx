// BodyRomLegend.jsx — 簡單色階圖例（JS 版）
import React from 'react';

export default function BodyRomLegend({ className = '' }) {
  const items = [
    { c: 'green',      label: 'Excellent' },
    { c: 'limegreen',  label: 'Good' },
    { c: 'orange',     label: 'Fair' },
    { c: 'darkorange', label: 'Borderline' },
    { c: 'red',        label: 'Poor' },
  ];
  return (
    <div className={className}>
      {items.map(it => (
        <span key={it.c} className="me-3">
          <span style={{
            display: 'inline-block', width: 10, height: 10, background: it.c, borderRadius: 2, marginRight: 6
          }} />
          <small>{it.label}</small>
        </span>
      ))}
    </div>
  );
}
