// HandGestureRecorder.jsx 
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { Hands } from '@mediapipe/hands';
import * as cam from '@mediapipe/camera_utils';
import ROMAssessmentPanel from './ROMAssessmentPanel';
import { useTranslation } from 'react-i18next';

const VIDEO_WIDTH = 540;
const VIDEO_HEIGHT = 310;

// 關節走線定義（每根手指一條鏈）
const fingerJoints = [
  [0, 1, 2, 3, 4],      // Thumb
  [5, 6, 7, 8],         // Index
  [9, 10, 11, 12],      // Middle
  [13, 14, 15, 16],     // Ring
  [17, 18, 19, 20],     // Pinky
];

// 預設顏色（可在 UI 即時改）
const DEFAULT_FINGER_COLORS = ['#ff4d4f', '#40c463', '#2f54eb', '#fa8c16', '#722ed1'];

function vector2dAngle(v1, v2) {
  const dot = v1[0] * v2[0] + v1[1] * v2[1];
  const mag1 = Math.hypot(v1[0], v1[1]);
  const mag2 = Math.hypot(v2[0], v2[1]);
  if (mag1 === 0 || mag2 === 0) return 180;
  let cosTheta = dot / (mag1 * mag2);
  cosTheta = Math.min(Math.max(cosTheta, -1), 1);
  return Math.acos(cosTheta) * (180 / Math.PI);
}

function computeJointAngles(landmarks) {
  const pts = landmarks.map(pt => [pt.x * VIDEO_WIDTH, pt.y * VIDEO_HEIGHT]);
  const anglesPerFinger = [];
  for (let joints of fingerJoints) {
    const angles = [];
    for (let i = 0; i < joints.length - 2; i++) {
      const a = pts[joints[i]];
      const b = pts[joints[i + 1]];
      const c = pts[joints[i + 2]];
      const v1 = [a[0] - b[0], a[1] - b[1]];
      const v2 = [c[0] - b[0], c[1] - b[1]];
      angles.push(vector2dAngle(v1, v2));
    }
    anglesPerFinger.push(angles);
  }
  return anglesPerFinger;
}

function computeThumbToPalmAngle(landmarks) {
  const pts = landmarks.map(pt => [pt.x * VIDEO_WIDTH, pt.y * VIDEO_HEIGHT]);
  const wrist = pts[0];
  const thumbBase = pts[2];
  const thumbTip = pts[4];
  const palmCenter = [
    (pts[5][0] + pts[9][0] + pts[13][0] + pts[17][0]) / 4,
    (pts[5][1] + pts[9][1] + pts[13][1] + pts[17][1]) / 4,
  ];
  const vPalm = [palmCenter[0] - wrist[0], palmCenter[1] - wrist[1]];
  const vThumb = [thumbTip[0] - thumbBase[0], thumbTip[1] - thumbBase[1]];
  return vector2dAngle(vThumb, vPalm);
}

function handAngle(landmarks) {
  const pts = landmarks.map(pt => [pt.x * VIDEO_WIDTH, pt.y * VIDEO_HEIGHT]);
  const angles = [];
  const pairs = [
    [0, 2, 3, 4],
    [0, 6, 7, 8],
    [0, 10, 11, 12],
    [0, 14, 15, 16],
    [0, 18, 19, 20],
  ];
  for (let [base, mid, tip1, tip2] of pairs) {
    const v1 = [pts[base][0] - pts[mid][0], pts[base][1] - pts[mid][1]];
    const v2 = [pts[tip1][0] - pts[tip2][0], pts[tip1][1] - pts[tip2][1]];
    angles.push(vector2dAngle(v1, v2));
  }
  return angles;
}

function handPos([f1, f2, f3, f4, f5]) {
  if (f1 < 50 && f2 >= 50 && f3 >= 50 && f4 >= 50 && f5 >= 50) return 'good';
  if (f1 >= 50 && f2 >= 50 && f3 < 50 && f4 >= 50 && f5 >= 50) return 'no!!!';
  if (f1 < 50 && f2 < 50 && f3 >= 50 && f4 >= 50 && f5 < 50) return 'ROCK!';
  if (f1 >= 50 && f2 >= 50 && f3 >= 50 && f4 >= 50 && f5 >= 50) return '0';
  if (f1 >= 50 && f2 >= 50 && f3 >= 50 && f4 >= 50 && f5 < 50) return 'pink';
  if (f1 >= 50 && f2 < 50 && f3 >= 50 && f4 >= 50 && f5 >= 50) return '1';
  if (f1 >= 50 && f2 < 50 && f3 < 50 && f4 >= 50 && f5 >= 50) return '2';
  if (f1 >= 50 && f2 >= 50 && f3 < 50 && f4 < 50 && f5 < 50) return 'ok';
  if (f1 < 50 && f2 >= 50 && f3 < 50 && f4 < 50 && f5 < 50) return 'ok';
  if (f1 >= 50 && f2 < 50 && f3 < 50 && f4 < 50 && f5 > 50) return '3';
  if (f1 >= 50 && f2 < 50 && f3 < 50 && f4 < 50 && f5 < 50) return '4';
  if (f1 < 50 && f2 < 50 && f3 < 50 && f4 < 50 && f5 < 50) return '5';
  if (f1 < 50 && f2 >= 50 && f3 >= 50 && f4 >= 50 && f5 < 50) return '6';
  if (f1 < 50 && f2 < 50 && f3 >= 50 && f4 >= 50 && f5 >= 50) return '7';
  if (f1 < 50 && f2 < 50 && f3 < 50 && f4 >= 50 && f5 >= 50) return '8';
  if (f1 < 50 && f2 < 50 && f3 < 50 && f4 < 50 && f5 >= 50) return '9';
  return '';
}

export default function HandGestureRecorder() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const cameraRef = useRef(null);
  const handsRef = useRef(null);
  const initRafRef = useRef(0);

  const [gesture, setGesture] = useState('');
  const [handedness, setHandedness] = useState('');
  const [timer, setTimer] = useState('');
  const [downloadUrl, setDownloadUrl] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [currentLandmarks, setCurrentLandmarks] = useState(null);

  // 🔧 新增：外觀與功能控制
  const [fingerColors, setFingerColors] = useState(DEFAULT_FINGER_COLORS);
  const [showLines, setShowLines] = useState(true);
  const [showPoints, setShowPoints] = useState(true);
  const [showAngles, setShowAngles] = useState(true);
  const [showThumbPalmAngle, setShowThumbPalmAngle] = useState(true);
  const [lineWidth, setLineWidth] = useState(3);
  const [pointRadius, setPointRadius] = useState(5);
  const [screenMirrored, setScreenMirrored] = useState(true); // 取代原本的常數

  const mediaRecorderRef = useRef(null);
  const recordedChunksRef = useRef([]);
  const { t } = useTranslation();

  const supportedMime = useMemo(() => {
    const candidates = [
      'video/webm;codecs=vp9',
      'video/webm;codecs=vp8',
      'video/webm'
    ];
    for (const m of candidates) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(m)) {
        return m;
      }
    }
    return '';
  }, []);

  // 若切換鏡像，通知 Mediapipe
  useEffect(() => {
    if (handsRef.current) {
      try {
        handsRef.current.setOptions({ selfieMode: screenMirrored });
      } catch {}
    }
  }, [screenMirrored]);

  useEffect(() => {
    let lastProcessed = 0;

    const hands = new Hands({
      locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
    });
    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.7,
      minTrackingConfidence: 0.5,
      selfieMode: screenMirrored,
    });
    hands.onResults(results => {
      const now = Date.now();
      if (now - lastProcessed < 100) return;
      lastProcessed = now;

      const canvas = canvasRef.current;
      if (!canvas || !results.image) return;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(results.image, 0, 0, canvas.width, canvas.height);

      if (results.multiHandLandmarks?.length) {
        const lms = results.multiHandLandmarks[0];
        setCurrentLandmarks(lms);

        if (results.multiHandedness?.length) {
          const label = results.multiHandedness[0].label; // 'Left' | 'Right'
          const uiLabel = screenMirrored
            ? (label === 'Left' ? 'Right' : 'Left')
            : label;
          setHandedness(uiLabel);
        }

        // 線段
        if (showLines) {
          fingerJoints.forEach((joints, i) => {
            for (let j = 0; j < joints.length - 1; j++) {
              const a = lms[joints[j]];
              const b = lms[joints[j + 1]];
              ctx.beginPath();
              ctx.moveTo(a.x * VIDEO_WIDTH, a.y * VIDEO_HEIGHT);
              ctx.lineTo(b.x * VIDEO_WIDTH, b.y * VIDEO_HEIGHT);
              ctx.strokeStyle = fingerColors[i] || '#ffffff';
              ctx.lineWidth = lineWidth;
              ctx.stroke();
            }
          });
        }

        // 點
        if (showPoints) {
          for (let pt of lms) {
            ctx.beginPath();
            ctx.arc(pt.x * VIDEO_WIDTH, pt.y * VIDEO_HEIGHT, pointRadius, 0, Math.PI * 2);
            ctx.fillStyle = '#ff4d4f';
            ctx.fill();
          }
        }

        // 角度標註（每節）
        if (showAngles) {
          const jointAngles = computeJointAngles(lms);
          jointAngles.forEach((angles, fingerIdx) => {
            angles.forEach((angle, j) => {
              const p = lms[fingerJoints[fingerIdx][j + 1]];
              ctx.fillStyle = '#2f54eb';
              ctx.font = '12px Arial';
              ctx.fillText(angle.toFixed(0), p.x * VIDEO_WIDTH + 5, p.y * VIDEO_HEIGHT - 5);
            });
          });
        }

        // 拇指-掌心角度
        if (showThumbPalmAngle) {
          const thumbPalmAngle = computeThumbToPalmAngle(lms);
          ctx.fillStyle = '#40c463';
          ctx.font = '14px Arial';
          ctx.fillText(
            `${t('thumb_to_palm', { defaultValue: '拇指-掌心角' })}: ${thumbPalmAngle.toFixed(0)}`,
            10, 20
          );
        }

        const angles = handAngle(lms);
        setGesture(handPos(angles));
      } else {
        setGesture('');
        setHandedness('');
        setCurrentLandmarks(null);
      }
    });

    handsRef.current = hands;

    const initCamera = () => {
      if (videoRef.current) {
        const camera = new cam.Camera(videoRef.current, {
          onFrame: async () => {
            await hands.send({ image: videoRef.current });
          },
          width: VIDEO_WIDTH,
          height: VIDEO_HEIGHT,
        });
        cameraRef.current = camera;
        camera.start();
      } else {
        initRafRef.current = requestAnimationFrame(initCamera);
      }
    };
    initRafRef.current = requestAnimationFrame(initCamera);

    return () => {
      if (initRafRef.current) cancelAnimationFrame(initRafRef.current);
      try { cameraRef.current?.stop(); } catch {}
      try { handsRef.current?.close(); } catch {}
      if (downloadUrl) URL.revokeObjectURL(downloadUrl);
    };
    // 變更 i18n 文案時重新繪製標籤
  }, [t, screenMirrored, fingerColors, showLines, showPoints, showAngles, showThumbPalmAngle, lineWidth, pointRadius]); 

  const startRecording = () => {
    if (!canvasRef.current) return;
    try {
      const stream = canvasRef.current.captureStream(30);
      const rec = new MediaRecorder(stream, supportedMime ? { mimeType: supportedMime } : undefined);
      mediaRecorderRef.current = rec;
      recordedChunksRef.current = [];
      rec.ondataavailable = e => { if (e.data?.size > 0) recordedChunksRef.current.push(e.data); };
      rec.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: supportedMime || 'video/webm' });
        const url = URL.createObjectURL(blob);
        if (downloadUrl) URL.revokeObjectURL(downloadUrl);
        setDownloadUrl(url);
        setIsRecording(false);
      };
      rec.start();
      setIsRecording(true);

      // 倒數 8 秒自動停止
      let seconds = 8;
      setTimer(`${seconds}s`);
      const id = setInterval(() => {
        seconds -= 1;
        setTimer(seconds > 0 ? `${seconds}s` : t('recording_finished', { defaultValue: '錄影完成' }));
        if (seconds <= 0) {
          clearInterval(id);
          try { rec.stop(); } catch {}
        }
      }, 1000);
    } catch (e) {
      console.error('MediaRecorder error:', e);
      alert(t('recording_not_supported', { defaultValue: '此瀏覽器不支援畫面錄影。' }));
    }
  };

  const handleColorChange = (idx, val) => {
    setFingerColors(prev => prev.map((c, i) => (i === idx ? val : c)));
  };

  return (
  <div className="container py-4">
    <h2 className="mb-3 text-center">
      {t('gesture_recording_title', { defaultValue: '手勢錄影偵測' })}
    </h2>

    {/* 隱藏 video，僅供 MediaPipe 讀取 */}
    <video ref={videoRef} playsInline muted style={{ display: 'none' }} />

    {/* 並排：左＝畫面與控制／右＝ROM 面板 */}
    <div className="row g-3 align-items-start">
      {/* 左欄：畫面 + 目前結果 + 操作列 + 外觀控制列（保留原有功能） */}
      <div className="col-lg-7">
        {/* 畫面輸出 */}
        <div className="guest-card d-inline-block p-2">
          <canvas
            ref={canvasRef}
            width={VIDEO_WIDTH}
            height={VIDEO_HEIGHT}
            className="rounded"
            style={{ border: '1px solid rgba(255,255,255,0.2)' }}
          />
        </div>

        {/* 目前結果 */}
        <div className="mt-3">
          <p className="mb-1">
            {t('gesture_result', { defaultValue: '手勢' })}: <strong>{gesture || '--'}</strong>
          </p>
          <p className="mb-1">
            {t('handedness_result', { defaultValue: '判定手別' })}：
            <strong>
              {handedness
                ? (handedness === 'Right'
                    ? t('right_hand', { defaultValue: '右手' })
                    : t('left_hand', { defaultValue: '左手' }))
                : t('no_detection', { defaultValue: '未偵測' })}
            </strong>
          </p>
          <p className="mb-0">
            {t('countdown', { defaultValue: '倒數' })}: {timer || '--'}
          </p>
        </div>

        {/* 操作列：錄影 */}
        <div className="d-flex gap-2 justify-content-start mt-3">
          <button
            className={`btn ${isRecording ? 'btn-secondary' : 'btn-accent btn-primary'}`}
            onClick={startRecording}
            disabled={isRecording}
          >
            {isRecording
              ? t('recording...', { defaultValue: '錄影中…' })
              : t('start_recording', { defaultValue: '開始施測' })}
          </button>

          {downloadUrl && (
            <a className="btn btn-success" href={downloadUrl} download="hand_gesture.webm">
              {t('download_recording', { defaultValue: '下載錄影' })}
            </a>
          )}
        </div>

        {/* 🎛️ 外觀控制列 */}
        <div className="mt-4">
          <div className="d-flex flex-wrap gap-3 align-items-center">
            <label className="form-check">
              <input
                type="checkbox"
                className="form-check-input"
                checked={showLines}
                onChange={e => setShowLines(e.target.checked)}
              />
              <span className="ms-1">
                {t('show_lines', { defaultValue: '顯示線段' })}
              </span>
            </label>
            <label className="form-check">
              <input
                type="checkbox"
                className="form-check-input"
                checked={showPoints}
                onChange={e => setShowPoints(e.target.checked)}
              />
              <span className="ms-1">
                {t('show_points', { defaultValue: '顯示關鍵點' })}
              </span>
            </label>
            <label className="form-check">
              <input
                type="checkbox"
                className="form-check-input"
                checked={showAngles}
                onChange={e => setShowAngles(e.target.checked)}
              />
              <span className="ms-1">
                {t('show_joint_angles', { defaultValue: '顯示關節角度' })}
              </span>
            </label>
            <label className="form-check">
              <input
                type="checkbox"
                className="form-check-input"
                checked={showThumbPalmAngle}
                onChange={e => setShowThumbPalmAngle(e.target.checked)}
              />
              <span className="ms-1">
                {t('show_thumb_palm', { defaultValue: '顯示拇指-掌心角' })}
              </span>
            </label>
            <label className="form-check">
              <input
                type="checkbox"
                className="form-check-input"
                checked={screenMirrored}
                onChange={e => setScreenMirrored(e.target.checked)}
              />
              <span className="ms-1">
                {t('mirror_mode', { defaultValue: '鏡像模式' })}
              </span>
            </label>
          </div>

          <div className="d-flex flex-wrap gap-3 align-items-center mt-3">
            <label>
              {t('line_width', { defaultValue: '線寬' })}:&nbsp;
              <input
                type="range"
                min="1"
                max="8"
                value={lineWidth}
                onChange={e => setLineWidth(parseInt(e.target.value, 10))}
              />
              &nbsp;<strong>{lineWidth}</strong>
            </label>
            <label>
              {t('point_radius', { defaultValue: '點半徑' })}:&nbsp;
              <input
                type="range"
                min="1"
                max="10"
                value={pointRadius}
                onChange={e => setPointRadius(parseInt(e.target.value, 10))}
              />
              &nbsp;<strong>{pointRadius}</strong>
            </label>
          </div>

          <div className="d-flex flex-wrap gap-3 align-items-center mt-3">
            {fingerColors.map((c, i) => (
              <label key={i} className="d-flex align-items-center gap-2">
                <span>
                  {['拇', '食', '中', '無', '小'][i]}
                  {t('finger', { defaultValue: '指' })}
                </span>
                <input
                  type="color"
                  value={c}
                  onChange={e => handleColorChange(i, e.target.value)}
                  style={{ width: 36, height: 28, border: 'none', background: 'transparent' }}
                  aria-label={`finger-${i}-color`}
                />
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* 右欄：ROM 評估面板（sticky，未偵測也顯示） */}
      <div className="col-lg-5">
        <div className="rom-sticky">
          <ROMAssessmentPanel landmarks={currentLandmarks} />
        </div>
      </div>
    </div>
  </div>
);

}
