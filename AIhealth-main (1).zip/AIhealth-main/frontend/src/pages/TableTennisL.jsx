// TableTennisL.jsx — Minimal table tennis arm & "paddle tip" visualizer
import React, { useEffect, useRef, useState, useCallback } from 'react';

const VIDEO_W = 640;
const VIDEO_H = 480;

export default function TableTennisL() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const animRef = useRef(0);
  const streamRef = useRef(null);
  const detectorRef = useRef(null);

  const [ready, setReady] = useState(false);
  const [running, setRunning] = useState(false);
  const [fps, setFps] = useState(0);
  const [err, setErr] = useState('');
  const [modelType, setModelType] = useState('lite'); // 'lite' | 'full'

  // optional: use mouse as a "ball"
  const [ball, setBall] = useState(null);

  const drawCircle = (ctx, x, y, r = 5) => {
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.closePath(); ctx.fill();
  };

  const drawLine = (ctx, a, b, width = 3) => {
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  };

  const getPt = (kps, i) => kps?.[i] ? { x: kps[i].x, y: kps[i].y, score: kps[i].score ?? 1 } : null;

  const loadDetector = useCallback(async () => {
    setErr('');
    try {
      const [
        poseDetection,
        tfcore,
        tfconv,
        tfwebgl
      ] = await Promise.all([
        import('@tensorflow-models/pose-detection'),
        import('@tensorflow/tfjs-core'),
        import('@tensorflow/tfjs-converter'),
        import('@tensorflow/tfjs-backend-webgl'),
      ]);

      await tfcore.ready();
      await tfcore.setBackend('webgl'); // 速度較快
      await tfcore.ready();

      const det = await poseDetection.createDetector(
        poseDetection.SupportedModels.BlazePose,
        {
          runtime: 'tfjs',
          modelType, // 'lite' 或 'full'
          enableSmoothing: true,
        }
      );
      detectorRef.current = det;
      setReady(true);
    } catch (e) {
      console.error(e);
      setErr(`Detector init failed: ${e?.message || e}`);
    }
  }, [modelType]);

  const startCam = useCallback(async () => {
    setErr('');
    try {
      // 先關掉既有流
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
        streamRef.current = null;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: VIDEO_W, height: VIDEO_H, facingMode: 'user' },
        audio: false,
      });
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      setRunning(true);
    } catch (e) {
      console.error(e);
      setErr(`Camera error: ${e?.message || e}`);
    }
  }, []);

  const stopCam = useCallback(() => {
    setRunning(false);
    if (animRef.current) cancelAnimationFrame(animRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
  }, []);

  useEffect(() => {
    // 初始化偵測器
    loadDetector();
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (detectorRef.current?.dispose) detectorRef.current.dispose();
    };
  }, [loadDetector]);

  // 主循環
  useEffect(() => {
    if (!running) return;

    let last = performance.now();
    const loop = async () => {
      animRef.current = requestAnimationFrame(loop);
      const v = videoRef.current;
      const c = canvasRef.current;
      const det = detectorRef.current;
      if (!v || !c || !det || v.readyState < 2) return;

      const ctx = c.getContext('2d');
      ctx.clearRect(0, 0, c.width, c.height);

      // 繪製原始影像（半透明可直接疊合）
      ctx.globalAlpha = 1.0;
      ctx.drawImage(v, 0, 0, c.width, c.height);

      // 估測
      let poses = [];
      try {
        poses = await det.estimatePoses(v, { flipHorizontal: true });
      } catch (e) {
        console.error(e);
      }

      // 畫骨架：只取可信度最高的 1 人
      const p = poses?.[0];
      const kps = p?.keypoints || p?.keypoints2D || [];

      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.strokeStyle = 'rgba(0,0,0,0.9)';

      const L_SHOULDER = 11, R_SHOULDER = 12, L_ELBOW = 13, R_ELBOW = 14, L_WRIST = 15, R_WRIST = 16;

      const l_sh = getPt(kps, L_SHOULDER);
      const l_el = getPt(kps, L_ELBOW);
      const l_wr = getPt(kps, L_WRIST);
      const r_sh = getPt(kps, R_SHOULDER);
      const r_el = getPt(kps, R_ELBOW);
      const r_wr = getPt(kps, R_WRIST);

      // 畫左臂
      if (l_sh && l_el && l_wr) {
        drawLine(ctx, l_sh, l_el, 4);
        drawLine(ctx, l_el, l_wr, 4);
        drawCircle(ctx, l_sh.x, l_sh.y, 5);
        drawCircle(ctx, l_el.x, l_el.y, 5);
        drawCircle(ctx, l_wr.x, l_wr.y, 6);

        // 推估「球拍尖端」= 從腕沿著(腕-肘)方向外推
        const vx = l_wr.x - l_el.x;
        const vy = l_wr.y - l_el.y;
        const mag = Math.hypot(vx, vy) || 1;
        const tip = { x: l_wr.x + (vx / mag) * 60, y: l_wr.y + (vy / mag) * 60 };
        ctx.fillStyle = 'rgba(20,120,255,0.9)';
        drawCircle(ctx, tip.x, tip.y, 6);
        ctx.fillText('PaddleTip(L)', tip.x + 8, tip.y - 8);
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
      }

      // 右臂（可視需要）
      if (r_sh && r_el && r_wr) {
        drawLine(ctx, r_sh, r_el, 4);
        drawLine(ctx, r_el, r_wr, 4);
        drawCircle(ctx, r_sh.x, r_sh.y, 5);
        drawCircle(ctx, r_el.x, r_el.y, 5);
        drawCircle(ctx, r_wr.x, r_wr.y, 6);

        const vx = r_wr.x - r_el.x;
        const vy = r_wr.y - r_el.y;
        const mag = Math.hypot(vx, vy) || 1;
        const tip = { x: r_wr.x + (vx / mag) * 60, y: r_wr.y + (vy / mag) * 60 };
        ctx.fillStyle = 'rgba(20,120,255,0.9)';
        drawCircle(ctx, tip.x, tip.y, 6);
        ctx.fillText('PaddleTip(R)', tip.x + 8, tip.y - 8);
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
      }

      // 「滑鼠當球」視覺化（點一下 Canvas 設定球的位置）
      if (ball) {
        ctx.fillStyle = 'rgba(255,80,0,0.9)';
        drawCircle(ctx, ball.x, ball.y, 6);
        ctx.fillText('Ball (mouse)', ball.x + 8, ball.y - 8);
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
      }

      ctx.restore();

      // FPS
      const now = performance.now();
      const dt = now - last;
      if (dt > 0) setFps(Math.round(1000 / dt));
      last = now;
    };

    animRef.current = requestAnimationFrame(loop);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [running, ball]);

  const onCanvasClick = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (VIDEO_W / rect.width);
    const y = (e.clientY - rect.top)  * (VIDEO_H / rect.height);
    setBall({ x, y });
  };

  return (
    <div className="p-3">
      <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2">
        <div className="d-flex align-items-center gap-2">
          <label className="form-label mb-0">Model:</label>
          <select
            className="form-select form-select-sm"
            value={modelType}
            onChange={(e) => setModelType(e.target.value)}
            disabled={running}
            title="BlazePose model type"
          >
            <option value="lite">lite (fast)</option>
            <option value="full">full (more accurate)</option>
          </select>
        </div>

        <div className="d-flex align-items-center gap-2">
          <span className="badge bg-secondary">FPS: {fps}</span>
          {!running ? (
            <button className="btn btn-sm btn-primary" onClick={startCam} disabled={!ready}>
              {ready ? 'Start Camera' : 'Loading…'}
            </button>
          ) : (
            <button className="btn btn-sm btn-danger" onClick={stopCam}>Stop</button>
          )}
        </div>
      </div>

      {err && <div className="alert alert-warning py-2">{String(err)}</div>}

      <div className="position-relative" style={{ width: VIDEO_W, maxWidth: '100%' }}>
        <video
          ref={videoRef}
          width={VIDEO_W}
          height={VIDEO_H}
          playsInline
          muted
          style={{ display: 'none' }}
        />
        <canvas
          ref={canvasRef}
          width={VIDEO_W}
          height={VIDEO_H}
          onClick={onCanvasClick}
          className="border rounded w-100"
          aria-label="Table tennis analyzer canvas"
        />
      </div>

      <p className="text-muted mt-2 mb-0" style={{fontSize: 13}}>
        小技巧：點一下畫面設定「球」位置；先用手臂 + 球拍尖端視覺化確認座標/延伸方向，之後再接入真實球偵測或影像處理。
      </p>
    </div>
  );
}
