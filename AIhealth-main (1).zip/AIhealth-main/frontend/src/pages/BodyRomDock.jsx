// BodyRomDock.jsx
import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import BodyRomAngleChart from './BodyRomAngleChart';
import BodyRomCsvDownload from './BodyRomCsvDownload';

export default function BodyRomDock({
  show,
  onClose,
  // 資料
  liveHistory,
  history,
  liveSeconds,
  testSeconds,
  // 操作
  testing,
  onStartTesting,
  onStopTesting,
  fps,
  // 圖表
  seriesKeys,          // ['R-Shoulder',...,'L-Ankle']
  // CSV
  testStartAtMs,
  csvRebuildSignal,
  onRequestCsvRebuild, // () => setSignal(s=>s+1)
  // i18n
  t,
}) {
  const [tab, setTab] = useState('live'); // 'live' | 'test'
  if (!show || (!liveHistory?.length && !history?.length)) return null;

  return ReactDOM.createPortal(
    <div className="rom-dock guest-card">
      <div className="rom-dock__header">
        <div className="btn-group btn-group-sm" role="tablist" aria-label="Body ROM tabs">
          <button
            type="button"
            className={`btn ${tab === 'live' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setTab('live')}
            aria-selected={tab === 'live'}
          >
            {t('rom_live_chart_title', { defaultValue: '即時角度' })} ({liveSeconds}s)
          </button>
          <button
            type="button"
            className={`btn ${tab === 'test' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setTab('test')}
            aria-selected={tab === 'test'}
          >
            {t('rom_chart_title', { defaultValue: '角度趨勢圖' })} ({testSeconds}s)
          </button>
        </div>

        <div className="flex-grow-1" />

        {!testing ? (
          <button className="btn btn-success btn-sm me-2" onClick={onStartTesting}>
            {t('rom_start', { defaultValue: '開始施測' })}
          </button>
        ) : (
          <button className="btn btn-danger btn-sm me-2" onClick={onStopTesting}>
            {t('rom_stop', { defaultValue: '停止施測' })}
          </button>
        )}

        {tab === 'test' && (
          <BodyRomCsvDownload
            history={history}
            testStartAtMs={testStartAtMs}
            columnKeys={seriesKeys}
            filenamePrefix="BodyROM_Test"
            label="CSV"
            className="btn btn-outline-primary btn-sm me-2"
            rebuildSignal={csvRebuildSignal}
          />
        )}

        <span className="small text-muted me-2">
          {t('rom_est_fps', { defaultValue: 'FPS' })}: {fps}
        </span>

        <button
          className="btn btn-sm btn-outline-secondary"
          onClick={onClose}
          aria-label={t('close', { defaultValue: '關閉' })}
        >
          ×
        </button>
      </div>

      <div
        className="rom-dock__body"
        onClick={tab === 'test' ? onRequestCsvRebuild : undefined}
      >
        {tab === 'live' ? (
          <BodyRomAngleChart
            history={liveHistory}
            seriesKeys={seriesKeys}
            title=""
            height={260}
            showLegend
            yRange={{ min: 0, max: 180 }}
            maintainAspectRatio={false}
            animations={false}
          />
        ) : (
          <BodyRomAngleChart
            history={history}
            seriesKeys={seriesKeys}
            title=""
            height={260}
            showLegend
            yRange={{ min: 0, max: 180 }}
            maintainAspectRatio={false}
            animations={false}
          />
        )}
      </div>
    </div>,
    document.body
  );
}
