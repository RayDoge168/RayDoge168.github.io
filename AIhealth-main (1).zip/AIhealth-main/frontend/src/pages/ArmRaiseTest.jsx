// ArmRaiseTest.jsx — 手臂前舉→上舉測試（含示意圖 + 倒數 + Brunnstrom Stage 推估）
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

// 可與 BodyPoseRecorder 共用
const IDX = {
  lShoulder: 11, rShoulder: 12,
  lElbow: 13,    rElbow: 14,
  lWrist: 15,    rWrist: 16,
  lHip: 23,      rHip: 24,
};

// 角度：B 點夾角（以度數回傳）
function angleAtB(pA, pB, pC) {
  if (!pA || !pB || !pC) return null;
  const v1 = [pA.x - pB.x, pA.y - pB.y];
  const v2 = [pC.x - pB.x, pC.y - pB.y];
  const m1 = Math.hypot(v1[0], v1[1]);
  const m2 = Math.hypot(v2[0], v2[1]);
  if (!m1 || !m2) return null;
  let cos = (v1[0]*v2[0] + v1[1]*v2[1]) / (m1*m2);
  cos = Math.min(Math.max(cos, -1), 1);
  return Math.round((Math.acos(cos) * 180) / Math.PI);
}

// （可選）可調整門檻
const STAGE_RULES = {
  // 依據最大肩屈曲（elbow-shoulder-hip 角度）與肘伸直度（shoulder-elbow-wrist 角度）推估
  S1: { shoulderMax:  0,   elbowMin:   0 },   // 幾乎無主動
  S2: { shoulderMax: 20,   elbowMin:   0 },   // 有些許活動（<60 可涵蓋 S2）
  S3: { shoulderMax: 90,   elbowMin:   0 },   // 可過胸（約 ≥90°）
  S4: { shoulderMax: 120,  elbowMin: 150 },   // 可近頭上且肘多數伸直
  S5: { shoulderMax: 150,  elbowMin: 165 },   // 上舉良好且肘近完全伸直
  S6: { shoulderMax: 170,  elbowMin: 170 },   // 接近對稱/正常
};

function estimateStage(maxShoulder, maxElbow) {
  if (maxShoulder == null || maxElbow == null) return null;
  if (maxShoulder >= STAGE_RULES.S6.shoulderMax && maxElbow >= STAGE_RULES.S6.elbowMin) return 6;
  if (maxShoulder >= STAGE_RULES.S5.shoulderMax && maxElbow >= STAGE_RULES.S5.elbowMin) return 5;
  if (maxShoulder >= STAGE_RULES.S4.shoulderMax && maxElbow >= STAGE_RULES.S4.elbowMin) return 4;
  if (maxShoulder >= STAGE_RULES.S3.shoulderMax) return 3;
  if (maxShoulder >= STAGE_RULES.S2.shoulderMax) return 2;
  return 1;
}

export default function ArmRaiseTest({
  poseLandmarks,        // 由 BodyPoseRecorder 傳入的 BlazePose 21/33 點
  screenMirrored = true,
  defaultSide = 'right',// 'right' | 'left'（觀眾視角）
  defaultSeconds = 8,   // 測試秒數
  onClose,              // 關閉面板 callback
}) {
  const { t } = useTranslation();
  const [side, setSide] = useState(defaultSide);
  const [seconds, setSeconds] = useState(defaultSeconds);
  const [testing, setTesting] = useState(false);
  const [countdown, setCountdown] = useState(null);

  // 即時角度
  const [shoulderAngle, setShoulderAngle] = useState('--');
  const [elbowAngle, setElbowAngle] = useState('--');

  // 紀錄期間的極值
  const [maxShoulder, setMaxShoulder] = useState(null);
  const [maxElbow, setMaxElbow] = useState(null);

  // 結果
  const [finalStage, setFinalStage] = useState(null);
  const timerRef = useRef(null);

  // 示意圖（請確保路徑正確；若放 public 根目錄，用 "/AAA1TEST.jpg"）
  // 你也可以改成 import AAA1 from './AAA1TEST.jpg'
  const AAA1 = '/AAA1TEST.jpg';
  const AAA2 = '/AAA2TEST.jpg';

  // 根據觀眾視角與鏡像決定取哪一側的索引
  const sideIdx = useMemo(() => {
    // BlazePose 的 landmark 標籤是以「人體本身左/右」；鏡像時畫面左右相反
    // 我們希望使用「觀眾視角」：畫面右手 = 人體左手（screenMirrored=true）
    const useLeft = (screenMirrored ? side === 'right' : side === 'left');
    return useLeft
      ? { shoulder: IDX.lShoulder, elbow: IDX.lElbow, wrist: IDX.lWrist, hip: IDX.lHip }
      : { shoulder: IDX.rShoulder, elbow: IDX.rElbow, wrist: IDX.rWrist, hip: IDX.rHip };
  }, [side, screenMirrored]);

  // 每當 landmarks 更新，若在測試中就取角度與極值
  useEffect(() => {
    if (!poseLandmarks || !poseLandmarks.length) return;

    const S = poseLandmarks[sideIdx.shoulder];
    const E = poseLandmarks[sideIdx.elbow];
    const W = poseLandmarks[sideIdx.wrist];
    const H = poseLandmarks[sideIdx.hip];

    const sAng = angleAtB(E, S, H);   // 肩屈曲近似：elbow-shoulder-hip
    const eAng = angleAtB(S, E, W);   // 肘伸直度：  shoulder-elbow-wrist

    if (sAng != null) setShoulderAngle(sAng);
    if (eAng != null) setElbowAngle(eAng);

    if (testing) {
      if (sAng != null) setMaxShoulder(prev => (prev == null ? sAng : Math.max(prev, sAng)));
      if (eAng != null) setMaxElbow(prev => (prev == null ? eAng : Math.max(prev, eAng)));
    }
  }, [poseLandmarks, sideIdx, testing]);

  // 啟動測試
  const start = () => {
    if (testing) return;
    setFinalStage(null);
    setMaxShoulder(null);
    setMaxElbow(null);
    setTesting(true);

    let tLeft = Math.max(3, Math.min(30, Math.round(seconds)));
    setCountdown(tLeft);

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      tLeft -= 1;
      setCountdown(tLeft);
      if (tLeft <= 0) {
        clearInterval(timerRef.current);
        timerRef.current = null;
        setTesting(false);
        setCountdown(null);
        // 推估 Stage
        const st = estimateStage(maxShoulder, maxElbow);
        setFinalStage(st);
      }
    }, 1000);
  };

  // 停止測試（提前）
  const stop = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    setTesting(false);
    setCountdown(null);
    const st = estimateStage(maxShoulder, maxElbow);
    setFinalStage(st);
  };

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
  }, []);

  // 顯示公式
  const Formula = () => (
    <code className="d-inline-block p-2 rounded" style={{ background: 'rgba(0,0,0,0.06)' }}>
      θ<sub>shoulder</sub> = ∠(elbow, <strong>shoulder</strong>, hip) &nbsp;&nbsp;|&nbsp;&nbsp;
      θ<sub>elbow</sub> = ∠(shoulder, <strong>elbow</strong>, wrist)
    </code>
  );

  return (
    <div className="guest-card p-3 mt-3">
      {/* 標題 */}
      <div className="d-flex align-items-center justify-content-between">
        <h5 className="mb-2">
          💪 {t('arm_raise_test_title', { defaultValue: '手臂前舉 → 上舉 測試（Brunnstrom 推估）' })}
        </h5>
        {onClose && (
          <button className="btn btn-sm btn-outline-secondary" onClick={onClose} aria-label="Close">
            ×
          </button>
        )}
      </div>

      {/* 說明與示意圖 */}
      <p className="text-muted mb-2">
        {t('arm_raise_instruction', { defaultValue: '請從手臂在身前抬起，持續上舉到頭上方，盡量保持手肘伸直。' })}
      </p>
      <div className="d-flex flex-wrap gap-3 align-items-center">
        <img src={AAA1} alt="Demo 1" style={{ width: 160, borderRadius: 8 }} />
        <img src={AAA2} alt="Demo 2" style={{ width: 160, borderRadius: 8 }} />
        <div className="small">
          <p className="mb-1"><strong>Formula</strong>：<Formula /></p>
          <ul className="mb-0">
            <li>θ<sub>shoulder</sub> = ∠(elbow, shoulder, hip) — 肩屈曲近似</li>
            <li>θ<sub>elbow</sub> = ∠(shoulder, elbow, wrist) — 肘伸直度（越接近 180 越直）</li>
          </ul>
        </div>
      </div>

      {/* 側別與秒數 */}
      <div className="d-flex flex-wrap gap-3 mt-3 align-items-center">
        <div className="btn-group btn-group-sm" role="group" aria-label="test side">
          <button
            type="button"
            className={`btn ${side === 'right' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setSide('right')}
          >{t('right', { defaultValue: '右手（畫面右側）' })}</button>
          <button
            type="button"
            className={`btn ${side === 'left' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setSide('left')}
          >{t('left', { defaultValue: '左手（畫面左側）' })}</button>
        </div>

        <label className="small d-flex align-items-center gap-2">
          {t('rom_test_seconds', { defaultValue: '施測秒數' })}：
          <input
            type="range" min="3" max="30" value={seconds}
            onChange={e => setSeconds(parseInt(e.target.value, 10))}
          />
          <strong>{seconds}s</strong>
        </label>

        <div className="ms-auto d-flex gap-2">
          {!testing ? (
            <button className="btn btn-success btn-sm" onClick={start}>
              {t('rom_start', { defaultValue: '開始測驗' })}
            </button>
          ) : (
            <button className="btn btn-danger btn-sm" onClick={stop}>
              {t('rom_stop', { defaultValue: '停止' })}
            </button>
          )}
          {countdown != null && (
            <span className="badge bg-secondary align-self-center">{countdown}s</span>
          )}
        </div>
      </div>

      {/* 即時角度與極值 */}
      <div className="row mt-3 g-2 text-center">
        <div className="col-6 col-md-3">
          <div className="p-2 border rounded">
            <div className="small text-muted">θ<sub>shoulder</sub> 即時</div>
            <div className="fs-5">{shoulderAngle}°</div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="p-2 border rounded">
            <div className="small text-muted">θ<sub>elbow</sub> 即時</div>
            <div className="fs-5">{elbowAngle}°</div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="p-2 border rounded">
            <div className="small text-muted">θ<sub>shoulder</sub> 最大</div>
            <div className="fs-5">{maxShoulder == null ? '—' : `${maxShoulder}°`}</div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="p-2 border rounded">
            <div className="small text-muted">θ<sub>elbow</sub> 最大</div>
            <div className="fs-5">{maxElbow == null ? '—' : `${maxElbow}°`}</div>
          </div>
        </div>
      </div>

      {/* 結果：Brunnstrom Stage（測試結束才顯示） */}
      {finalStage != null && (
        <div className="text-center mt-3">
          <h6 className="mb-1">{t('arm_raise_stage_result', { defaultValue: '此次動作推估 Brunnstrom Stage' })}</h6>
          <div className="fs-4">
            <strong>Stage {finalStage}</strong>
          </div>
          <div className="small text-muted mt-1">
            {t('arm_raise_rule_hint', {
              defaultValue:
                '規則（可微調）：S3 ≥ 90°；S4 ≥ 120° 且肘 ≥ 150°；S5 ≥ 150° 且肘 ≥ 165°；S6 ≥ 170° 且肘 ≥ 170°。'
            })}
          </div>
        </div>
      )}
    </div>
  );
}
