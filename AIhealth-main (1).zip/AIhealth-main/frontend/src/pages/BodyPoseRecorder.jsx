// BodyPoseRecorder.jsx — colored skeleton & angle-based limb lines (refined + manual color overrides)
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { Pose } from '@mediapipe/pose';
import * as cam from '@mediapipe/camera_utils';
import { useTranslation } from 'react-i18next';
import BodyROMPanel from './BodyROMPanel';

import ArmRaiseTest from './ArmRaiseTest'; // 👈 你已新增的面板

const VIDEO_WIDTH = 640;
const VIDEO_HEIGHT = 480;
const SCREEN_MIRRORED = true; // 是否鏡像呈現（自拍感）

/** BlazePose 索引（主要用到的關節） */
const IDX = {
  lShoulder: 11, rShoulder: 12,
  lElbow: 13,    rElbow: 14,
  lWrist: 15,    rWrist: 16,
  lHip: 23,      rHip: 24,
  lKnee: 25,     rKnee: 26,
  lAnkle: 27,    rAnkle: 28,
  lIndex: 19,    rIndex: 20,
  lFootIndex: 31, rFootIndex: 32,
};

/** 要計算的角度（A-B-C：取 B 點夾角） */
const ANGLE_SPECS = [
  { key: 'L-Shoulder', label: 'Shoulder', pts: [IDX.lElbow, IDX.lShoulder, IDX.lHip] },
  { key: 'R-Shoulder', label: 'Shoulder', pts: [IDX.rElbow, IDX.rShoulder, IDX.rHip] },
  { key: 'L-Elbow',    label: 'Elbow',    pts: [IDX.lShoulder, IDX.lElbow, IDX.lWrist] },
  { key: 'R-Elbow',    label: 'Elbow',    pts: [IDX.rShoulder, IDX.rElbow, IDX.rWrist] },
  { key: 'L-Wrist',    label: 'Wrist',    pts: [IDX.lElbow, IDX.lWrist, IDX.lIndex] },
  { key: 'R-Wrist',    label: 'Wrist',    pts: [IDX.rElbow, IDX.rWrist, IDX.rIndex] },
  { key: 'L-Hip',      label: 'Hip',      pts: [IDX.lShoulder, IDX.lHip, IDX.lKnee] },
  { key: 'R-Hip',      label: 'Hip',      pts: [IDX.rShoulder, IDX.rHip, IDX.rKnee] },
  { key: 'L-Knee',     label: 'Knee',     pts: [IDX.lHip, IDX.lKnee, IDX.lAnkle] },
  { key: 'R-Knee',     label: 'Knee',     pts: [IDX.rHip, IDX.rKnee, IDX.rAnkle] },
  { key: 'L-Ankle',    label: 'Ankle',    pts: [IDX.lKnee, IDX.lAnkle, IDX.lFootIndex] },
  { key: 'R-Ankle',    label: 'Ankle',    pts: [IDX.rKnee, IDX.rAnkle, IDX.rFootIndex] },
];

/** 骨架底線（白細線） */
const SKELETON = [
  [IDX.lShoulder, IDX.lElbow], [IDX.lElbow, IDX.lWrist], [IDX.lWrist, IDX.lIndex],
  [IDX.rShoulder, IDX.rElbow], [IDX.rElbow, IDX.rWrist], [IDX.rWrist, IDX.rIndex],
  [IDX.lShoulder, IDX.lHip], [IDX.rShoulder, IDX.rHip],
  [IDX.lHip, IDX.lKnee], [IDX.lKnee, IDX.lAnkle], [IDX.lAnkle, IDX.lFootIndex],
  [IDX.rHip, IDX.rKnee], [IDX.rKnee, IDX.rAnkle], [IDX.rAnkle, IDX.rFootIndex],
  [IDX.lShoulder, IDX.rShoulder], [IDX.lHip, IDX.rHip],
];

/** 角度對應到兩段加粗著色 */
const ANGLE_TO_SEGMENTS = {
  'L-Shoulder': [[IDX.lElbow, IDX.lShoulder], [IDX.lShoulder, IDX.lHip]],
  'R-Shoulder': [[IDX.rElbow, IDX.rShoulder], [IDX.rShoulder, IDX.rHip]],
  'L-Elbow':    [[IDX.lShoulder, IDX.lElbow], [IDX.lElbow, IDX.lWrist]],
  'R-Elbow':    [[IDX.rShoulder, IDX.rElbow], [IDX.rElbow, IDX.rWrist]],
  'L-Wrist':    [[IDX.lElbow, IDX.lWrist], [IDX.lWrist, IDX.lIndex]],
  'R-Wrist':    [[IDX.rElbow, IDX.rWrist], [IDX.rWrist, IDX.rIndex]],
  'L-Hip':      [[IDX.lShoulder, IDX.lHip], [IDX.lHip, IDX.lKnee]],
  'R-Hip':      [[IDX.rShoulder, IDX.rHip], [IDX.rHip, IDX.rKnee]],
  'L-Knee':     [[IDX.lHip, IDX.lKnee], [IDX.lKnee, IDX.lAnkle]],
  'R-Knee':     [[IDX.rHip, IDX.rKnee], [IDX.rKnee, IDX.rAnkle]],
  'L-Ankle':    [[IDX.lKnee, IDX.lAnkle], [IDX.lAnkle, IDX.lFootIndex]],
  'R-Ankle':    [[IDX.rKnee, IDX.rAnkle], [IDX.rAnkle, IDX.rFootIndex]],
};

function angleAtB(pA, pB, pC) {
  const v1 = [pA.x - pB.x, pA.y - pB.y];
  const v2 = [pC.x - pB.x, pC.y - pB.y];
  const dot = v1[0] * v2[0] + v1[1] * v2[1];
  const mag1 = Math.hypot(v1[0], v1[1]);
  const mag2 = Math.hypot(v2[0], v2[1]);
  if (!mag1 || !mag2) return 180;
  let cos = dot / (mag1 * mag2);
  cos = Math.min(Math.max(cos, -1), 1);
  return (Math.acos(cos) * 180) / Math.PI;
}

function readCssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function drawSegment(ctx, A, B, color, width = 4) {
  ctx.beginPath();
  ctx.moveTo(A.x * VIDEO_WIDTH, A.y * VIDEO_HEIGHT);
  ctx.lineTo(B.x * VIDEO_WIDTH, B.y * VIDEO_HEIGHT);
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.lineCap = 'round';
  ctx.stroke();
}

function drawPoint(ctx, P, radius = 4, color = '#ff375f') {
  ctx.beginPath();
  ctx.arc(P.x * VIDEO_WIDTH, P.y * VIDEO_HEIGHT, radius, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
}

function drawLabel(ctx, text, x, y, color) {
  ctx.font = '12px Arial';
  const pad = 3;
  const metrics = ctx.measureText(text);
  const w = metrics.width + pad * 2;
  const h = 14 + pad * 2;
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(x, y - h + 3, w, h);
  ctx.fillStyle = color;
  ctx.fillText(text, x + pad, y - pad);
}

const isVisible = (pt, th = 0.4) => pt && (pt.visibility == null || pt.visibility >= th);

export default function BodyPoseRecorder() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const cameraRef = useRef(null);
  const poseRef = useRef(null);
  const rafRef = useRef(0);

  const [angleMap, setAngleMap] = useState({});
  const [isRecording, setIsRecording] = useState(false);
  const [timer, setTimer] = useState('');
  const [downloadUrl, setDownloadUrl] = useState(null);
  const [poseLandmarks, setPoseLandmarks] = useState(null);
  const [showArmTest, setShowArmTest] = useState(false);

  // NEW ▼ 顏色編輯狀態
  const [colorEditOpen, setColorEditOpen] = useState(false);
  const [lineColorMode, setLineColorMode] = useState('auto'); // 'auto' | 'manual'
  const [manualColors, setManualColors] = useState(() => {
    // 預設先給一個順眼的色（可改）
    return {
      'L-Shoulder': '#22c55e', 'R-Shoulder': '#22c55e',
      'L-Elbow': '#22c55e',    'R-Elbow': '#22c55e',
      'L-Wrist': '#22c55e',    'R-Wrist': '#22c55e',
      'L-Hip': '#22c55e',      'R-Hip': '#22c55e',
      'L-Knee': '#22c55e',     'R-Knee': '#22c55e',
      'L-Ankle': '#22c55e',    'R-Ankle': '#22c55e',
    };
  });
  // NEW ▲

  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);

  const { t } = useTranslation();

  // 分級顏色（可在 CSS 設定 --rom-red / --rom-dorange / --rom-orange / --rom-lime / --rom-green）
  const romColors = useMemo(() => ({
    red:     typeof window === 'undefined' ? 'red'        : readCssVar('--rom-red',    '#ef4444'),
    dOrange: typeof window === 'undefined' ? 'darkorange' : readCssVar('--rom-dorange','#f59e0b'),
    orange:  typeof window === 'undefined' ? 'orange'     : readCssVar('--rom-orange', '#fb923c'),
    lime:    typeof window === 'undefined' ? 'limegreen'  : readCssVar('--rom-lime',   '#84cc16'),
    green:   typeof window === 'undefined' ? 'green'      : readCssVar('--rom-green',  '#22c55e'),
  }), []);

  const thresholds = [30, 60, 90, 120, 150];
  const colorByAngle = (a) => {
    if (a >= thresholds[4]) return romColors.green;
    if (a >= thresholds[3]) return romColors.lime;
    if (a >= thresholds[2]) return romColors.orange;
    if (a >= thresholds[1]) return romColors.dOrange;
    return romColors.red;
  };

  // NEW ▼ 手動/自動顏色的取色統一入口
  const getSegmentColor = (key, ang) => {
    if (lineColorMode === 'manual' && manualColors[key]) return manualColors[key];
    return colorByAngle(ang);
  };
  // NEW ▲

  // 錄影格式自動偵測
  const supportedMime = useMemo(() => {
    const c = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
    for (const m of c) {
      if (window.MediaRecorder?.isTypeSupported?.(m)) return m;
    }
    return '';
  }, []);

  // 清理舊的下載 URL
  useEffect(() => {
    return () => { if (downloadUrl) URL.revokeObjectURL(downloadUrl); };
  }, [downloadUrl]);

  useEffect(() => {
    let lastProcessed = 0;
    const pose = new Pose({ locateFile: f => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${f}` });
    pose.setOptions({
      modelComplexity: 1,
      smoothLandmarks: true,
      enableSegmentation: false,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.5,
      selfieMode: SCREEN_MIRRORED,
    });

    pose.onResults((res) => {
      const now = Date.now();
      if (now - lastProcessed < 80) return; // 節流
      lastProcessed = now;

      const canvas = canvasRef.current;
      if (!canvas || !res?.image) return;
      const ctx = canvas.getContext('2d');
      ctx.save();
      ctx.clearRect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);
      ctx.drawImage(res.image, 0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);

      const lm = res.poseLandmarks;
      if (lm?.length) {
        // 1) 底線
        for (const [i, j] of SKELETON) {
          const A = lm[i], B = lm[j];
          if (isVisible(A) && isVisible(B)) drawSegment(ctx, A, B, 'rgba(255,255,255,0.35)', 2);
        }
        // 2) 點
        for (let i = 11; i < lm.length; i++) {
          const P = lm[i];
          if (isVisible(P)) drawPoint(ctx, P, 3.5, '#ff6aa0');
        }
        // 3) 角度 + 著色
        const nextMap = {};
        for (const spec of ANGLE_SPECS) {
          const [a, b, c] = spec.pts;
          const A = lm[a], B = lm[b], C = lm[c];
          if (!(isVisible(A) && isVisible(B) && isVisible(C))) continue;

          const ang = Math.round(angleAtB(A, B, C));
          nextMap[spec.key] = ang;

          // NEW ▼：用 getSegmentColor 取線色（支援手動模式）
          const col = getSegmentColor(spec.key, ang);
          // NEW ▲

          drawLabel(ctx, `${spec.key}: ${ang}°`, B.x * VIDEO_WIDTH + 6, B.y * VIDEO_HEIGHT - 6, col);

          const segs = ANGLE_TO_SEGMENTS[spec.key] || [];
          for (const [i1, i2] of segs) {
            const P1 = lm[i1], P2 = lm[i2];
            if (isVisible(P1) && isVisible(P2)) drawSegment(ctx, P1, P2, col, 6);
          }
          drawPoint(ctx, B, 5.5, col);
        }
        setAngleMap(nextMap);
        setPoseLandmarks(lm);
      } else {
        setPoseLandmarks(null);
      }
      ctx.restore();
    });

    poseRef.current = pose;

    const init = () => {
      if (!videoRef.current) {
        rafRef.current = requestAnimationFrame(init);
        return;
      }
      const camera = new cam.Camera(videoRef.current, {
        width: VIDEO_WIDTH,
        height: VIDEO_HEIGHT,
        onFrame: async () => { await pose.send({ image: videoRef.current }); },
      });
      cameraRef.current = camera;
      camera.start();
    };
    rafRef.current = requestAnimationFrame(init);
    return () => {
  if (rafRef.current) cancelAnimationFrame(rafRef.current);

  try {
    cameraRef.current?.stop();
  } catch (err) {
    console.debug('[cleanup] camera.stop() failed (already stopped?)', err);
  }

  try {
    poseRef.current?.close();
  } catch (err) {
    console.debug('[cleanup] pose.close() failed (already closed?)', err);
  }
};
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startRecording = () => {
  if (!canvasRef.current || isRecording) return;
  try {
    const stream = canvasRef.current.captureStream(30);
    const rec = new MediaRecorder(stream, supportedMime ? { mimeType: supportedMime } : undefined);
    mediaRecorderRef.current = rec;
    chunksRef.current = [];

    rec.ondataavailable = (e) => { if (e.data?.size) chunksRef.current.push(e.data); };
    rec.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: supportedMime || 'video/webm' });
      if (downloadUrl) URL.revokeObjectURL(downloadUrl);
      setDownloadUrl(URL.createObjectURL(blob));
      setIsRecording(false);
    };

    rec.start();
    setIsRecording(true);

    let s = 8;
    setTimer(`${s}s`);
    const id = setInterval(() => {
      s -= 1;
      setTimer(s > 0 ? `${s}s` : t('recording_finished', { defaultValue: '錄影完成' }));
      if (s <= 0) {
        clearInterval(id);
        // ✅ 修正：避免空 catch，並只在還在錄製時才 stop
        try {
          if (rec.state !== 'inactive') rec.stop();
        } catch (err) {
          console.debug('[MediaRecorder] stop() failed:', err);
        }
      }
    }, 1000);
  } catch (err) {
    console.error(err);
    alert(t('recording_not_supported', { defaultValue: '此瀏覽器不支援畫面錄影。' }));
  }
};


  // ——— 顯示工具（避免出現 --°） ———
  const fmt = (k) => (typeof angleMap[k] === 'number' ? `${angleMap[k]}°` : '—');
  const col = (k) => (typeof angleMap[k] === 'number'
    ? (lineColorMode === 'manual' ? manualColors[k] : colorByAngle(angleMap[k]))
    : undefined
  );

  // 依鏡像設定，決定表格左右（觀眾視角）
  const RIGHT_KEYS = SCREEN_MIRRORED
    ? ['L-Shoulder','L-Elbow','L-Wrist','L-Hip','L-Knee','L-Ankle']
    : ['R-Shoulder','R-Elbow','R-Wrist','R-Hip','R-Knee','R-Ankle'];
  const LEFT_KEYS = SCREEN_MIRRORED
    ? ['R-Shoulder','R-Elbow','R-Wrist','R-Hip','R-Knee','R-Ankle']
    : ['L-Shoulder','L-Elbow','L-Wrist','L-Hip','L-Knee','L-Ankle'];

  // NEW ▼ 一鍵套用工具
  const applySideColor = (side, color) => {
    const keys = side === 'left'
      ? ['L-Shoulder','L-Elbow','L-Wrist','L-Hip','L-Knee','L-Ankle']
      : ['R-Shoulder','R-Elbow','R-Wrist','R-Hip','R-Knee','R-Ankle'];
    setManualColors(prev => {
      const next = { ...prev };
      keys.forEach(k => { next[k] = color; });
      return next;
    });
  };
  const resetManualColors = () => {
    setManualColors({
      'L-Shoulder': '#22c55e', 'R-Shoulder': '#22c55e',
      'L-Elbow': '#22c55e',    'R-Elbow': '#22c55e',
      'L-Wrist': '#22c55e',    'R-Wrist': '#22c55e',
      'L-Hip': '#22c55e',      'R-Hip': '#22c55e',
      'L-Knee': '#22c55e',     'R-Knee': '#22c55e',
      'L-Ankle': '#22c55e',    'R-Ankle': '#22c55e',
    });
  };
  // NEW ▲

  return (
    <div className="container py-4 text-center">
      <h2 className="mb-3">{t('body_pose_title', { defaultValue: '全身關節角度偵測' })}</h2>

      {/* 隱藏 video：僅供 Pose 讀取 */}
      <video ref={videoRef} playsInline muted style={{ display: 'none' }} />

      {/* 畫面輸出（可套 guest-card 樣式） */}
      <div className="guest-card d-inline-block p-2">
        <canvas
          ref={canvasRef}
          width={VIDEO_WIDTH}
          height={VIDEO_HEIGHT}
          className="rounded"
          style={{ border: '1px solid rgba(255,255,255,0.2)' }}
        />
      </div>

      <div className="mt-3">
        <p className="mb-0">{t('countdown', { defaultValue: '倒數' })}: {timer || '--'}</p>
        <div className="d-flex flex-wrap gap-2 justify-content-center mt-2">
          <button
            className={`btn ${isRecording ? 'btn-secondary' : 'btn-accent btn-primary'}`}
            onClick={startRecording}
            disabled={isRecording}
          >
            {isRecording
              ? t('recording...', { defaultValue: '錄影中…' })
              : t('start_recording', { defaultValue: '開始施測' })}
          </button>

          {downloadUrl && (
            <a className="btn btn-success" href={downloadUrl} download="body_pose.webm">
              {t('download_recording', { defaultValue: '下載錄影' })}
            </a>
          )}

          {/* NEW ▼ 開關手臂上舉測試面板 */}
          <button
            className="btn btn-outline-primary"
            onClick={() => setShowArmTest(v => !v)}
          >
            {showArmTest
              ? t('arm_raise_hide_panel', { defaultValue: '隱藏手臂上舉測試' })
              : t('arm_raise_show_panel', { defaultValue: '手臂上舉測試' })}
          </button>

          {/* NEW ▼ 顏色編輯面板開關 */}
          <button
            className="btn btn-outline-secondary"
            onClick={() => setColorEditOpen(v => !v)}
          >
            {colorEditOpen
              ? t('hide_color_controls', { defaultValue: '隱藏顏色控制' })
              : t('show_color_controls', { defaultValue: '顏色控制' })}
          </button>
        </div>
      </div>

      {/* NEW ▼ 顏色控制面板 */}
      {colorEditOpen && (
        <div className="card mt-3 mx-auto" style={{ maxWidth: 820, textAlign: 'left' }}>
          <div className="card-body">
            <div className="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
              <strong>{t('line_color_mode', { defaultValue: '連線配色模式' })}:</strong>
              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  id="modeAuto"
                  name="lineMode"
                  checked={lineColorMode === 'auto'}
                  onChange={() => setLineColorMode('auto')}
                />
                <label className="form-check-label" htmlFor="modeAuto">
                  {t('auto_by_angle', { defaultValue: '自動（依角度分級）' })}
                </label>
              </div>
              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  id="modeManual"
                  name="lineMode"
                  checked={lineColorMode === 'manual'}
                  onChange={() => setLineColorMode('manual')}
                />
                <label className="form-check-label" htmlFor="modeManual">
                  {t('manual_fixed', { defaultValue: '手動（固定顏色）' })}
                </label>
              </div>

              <div className="ms-auto d-flex gap-2">
                <div className="input-group input-group-sm" style={{ width: 190 }}>
                  <span className="input-group-text">{t('apply_left', { defaultValue: '左側套色' })}</span>
                  <input type="color" className="form-control form-control-color"
                    onChange={(e) => applySideColor('left', e.target.value)} />
                </div>
                <div className="input-group input-group-sm" style={{ width: 190 }}>
                  <span className="input-group-text">{t('apply_right', { defaultValue: '右側套色' })}</span>
                  <input type="color" className="form-control form-control-color"
                    onChange={(e) => applySideColor('right', e.target.value)} />
                </div>
                <button className="btn btn-sm btn-outline-danger" onClick={resetManualColors}>
                  {t('reset_colors', { defaultValue: '重置顏色' })}
                </button>
              </div>
            </div>

            {lineColorMode === 'manual' && (
              <div className="table-responsive">
                <table className="table table-sm align-middle mb-0">
                  <thead>
                    <tr>
                      <th style={{width: 140}}>{t('joint', { defaultValue: '關節' })}</th>
                      <th>{t('left', { defaultValue: '左' })}</th>
                      <th>{t('right', { defaultValue: '右' })}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {['Shoulder','Elbow','Wrist','Hip','Knee','Ankle'].map((label) => {
                      const L = `L-${label}`, R = `R-${label}`;
                      return (
                        <tr key={label}>
                          <th>{label}</th>
                          <td>
                            <input
                              type="color"
                              value={manualColors[L]}
                              onChange={(e) => setManualColors(prev => ({ ...prev, [L]: e.target.value }))}
                            />
                            <span className="ms-2 small">{manualColors[L]}</span>
                          </td>
                          <td>
                            <input
                              type="color"
                              value={manualColors[R]}
                              onChange={(e) => setManualColors(prev => ({ ...prev, [R]: e.target.value }))}
                            />
                            <span className="ms-2 small">{manualColors[R]}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            {lineColorMode === 'auto' && (
              <div className="mt-2 small text-muted">
                {t('auto_hint', { defaultValue: '自動模式下，線色由角度分級（紅→綠）決定，無法手動調整。' })}
              </div>
            )}
          </div>
        </div>
      )}
      {/* NEW ▲ 顏色控制面板 */}

      {/* 角度表（依鏡像自動對應觀眾視角的 Left/Right） */}
      <div className="table-responsive mt-4" style={{ maxWidth: 720, margin: '0 auto' }}>
        <table className="table table-sm table-bordered align-middle">
          <thead>
            <tr>
              <th></th>
              <th>Shoulder</th>
              <th>Elbow</th>
              <th>Wrist</th>
              <th>Hip</th>
              <th>Knee</th>
              <th>Ankle</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Right</th>
              <td style={{ color: col(RIGHT_KEYS[0]) }}>{fmt(RIGHT_KEYS[0])}</td>
              <td style={{ color: col(RIGHT_KEYS[1]) }}>{fmt(RIGHT_KEYS[1])}</td>
              <td style={{ color: col(RIGHT_KEYS[2]) }}>{fmt(RIGHT_KEYS[2])}</td>
              <td style={{ color: col(RIGHT_KEYS[3]) }}>{fmt(RIGHT_KEYS[3])}</td>
              <td style={{ color: col(RIGHT_KEYS[4]) }}>{fmt(RIGHT_KEYS[4])}</td>
              <td style={{ color: col(RIGHT_KEYS[5]) }}>{fmt(RIGHT_KEYS[5])}</td>
            </tr>
            <tr>
              <th scope="row">Left</th>
              <td style={{ color: col(LEFT_KEYS[0]) }}>{fmt(LEFT_KEYS[0])}</td>
              <td style={{ color: col(LEFT_KEYS[1]) }}>{fmt(LEFT_KEYS[1])}</td>
              <td style={{ color: col(LEFT_KEYS[2]) }}>{fmt(LEFT_KEYS[2])}</td>
              <td style={{ color: col(LEFT_KEYS[3]) }}>{fmt(LEFT_KEYS[3])}</td>
              <td style={{ color: col(LEFT_KEYS[4]) }}>{fmt(LEFT_KEYS[4])}</td>
              <td style={{ color: col(LEFT_KEYS[5]) }}>{fmt(LEFT_KEYS[5])}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* 手臂上舉測試面板 */}
      {showArmTest && (
        <ArmRaiseTest
          poseLandmarks={poseLandmarks}
          screenMirrored={SCREEN_MIRRORED}
          defaultSide="right"
          defaultSeconds={8}
          onClose={() => setShowArmTest(false)}
        />
      )}

      {/* 傳給你的身體 ROM 面板 */}
      <BodyROMPanel poseLandmarks={poseLandmarks} screenMirrored={SCREEN_MIRRORED} />
    </div>
  );
}
