// handRomFiltersUtils.js
export const FINGERS = ['thumb', 'index', 'middle', 'ring', 'pinky'];
export const JOINTS  = ['MCP', 'PIP', 'DIP', 'IP'];

/**
 * 過濾資料序列 key，僅保留有被勾選的手指 & 關節
 * @param {string[]} allKeys  例如 ['thumb_MCP','index_PIP', ...]
 * @param {Record<string, boolean>} fingers  例如 { thumb: true, index: false, ... }
 * @param {Record<string, boolean>} joints   例如 { MCP: true, PIP: false, ... }
 */
export function filterFingerSeriesKeys(allKeys, fingers, joints) {
  return allKeys.filter(k => {
    const [f, j] = k.split('_');
    return !!fingers[f] && !!joints[j];
  });
}
