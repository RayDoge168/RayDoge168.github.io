// BodyROMPanel.jsx — Body ROM with i18n labels + group filters + CSV-sync
import React, { useEffect, useRef, useState } from 'react';
import BodyRomAngleChart from './BodyRomAngleChart';
import BodyRomDock from './BodyRomDock';
import BodyRomCsvDownload from './BodyRomCsvDownload';
import BodyRomLegend from './BodyRomLegend';
import BodyRomFilters, { filterSeriesKeys } from './BodyRomFilters';
import { useTranslation } from 'react-i18next';

// BlazePose indices (略，同你原本的)
const IDX = {
  lShoulder: 11, rShoulder: 12,
  lElbow: 13,    rElbow: 14,
  lWrist: 15,    rWrist: 16,
  lHip: 23,      rHip: 24,
  lKnee: 25,     rKnee: 26,
  lAnkle: 27,    rAnkle: 28,
  lIndex: 19,    rIndex: 20,
  lFootIndex: 31, rFootIndex: 32,
};

// A-B-C 取 B 的角
const ANGLE_SPECS = [
  { key: 'L-Shoulder', pts: [IDX.lElbow, IDX.lShoulder, IDX.lHip] },
  { key: 'R-Shoulder', pts: [IDX.rElbow, IDX.rShoulder, IDX.rHip] },
  { key: 'L-Elbow',    pts: [IDX.lShoulder, IDX.lElbow, IDX.lWrist] },
  { key: 'R-Elbow',    pts: [IDX.rShoulder, IDX.rElbow, IDX.rWrist] },
  { key: 'L-Wrist',    pts: [IDX.lElbow, IDX.lWrist, IDX.lIndex] },
  { key: 'R-Wrist',    pts: [IDX.rElbow, IDX.rWrist, IDX.rIndex] },
  { key: 'L-Hip',      pts: [IDX.lShoulder, IDX.lHip, IDX.lKnee] },
  { key: 'R-Hip',      pts: [IDX.rShoulder, IDX.rHip, IDX.rKnee] },
  { key: 'L-Knee',     pts: [IDX.lHip, IDX.lKnee, IDX.lAnkle] },
  { key: 'R-Knee',     pts: [IDX.rHip, IDX.rKnee, IDX.rAnkle] },
  { key: 'L-Ankle',    pts: [IDX.lKnee, IDX.lAnkle, IDX.lFootIndex] },
  { key: 'R-Ankle',    pts: [IDX.rKnee, IDX.rAnkle, IDX.rFootIndex] },
];

// 預設順序（R 再 L）
const SERIES_KEYS_ALL = [
  'R-Shoulder','R-Elbow','R-Wrist','R-Hip','R-Knee','R-Ankle',
  'L-Shoulder','L-Elbow','L-Wrist','L-Hip','L-Knee','L-Ankle',
];

const isVisible = (pt, th = 0.4) => pt && (pt.visibility == null || pt.visibility >= th);

function angleAtB(pA, pB, pC) {
  const v1 = [pA.x - pB.x, pA.y - pB.y];
  const v2 = [pC.x - pB.x, pC.y - pB.y];
  const dot = v1[0] * v2[0] + v1[1] * v2[1];
  const mag1 = Math.hypot(v1[0], v1[1]);
  const mag2 = Math.hypot(v2[0], v2[1]);
  if (!mag1 || !mag2) return undefined;
  let cos = dot / (mag1 * mag2);
  cos = Math.min(Math.max(cos, -1), 1);
  return (Math.acos(cos) * 180) / Math.PI;
}

export default function BodyROMPanel({ poseLandmarks, screenMirrored }) {
  const { t } = useTranslation();

  // 即時資料/歷史
  const [currentAngles, setCurrentAngles] = useState({});
  const [liveHistory, setLiveHistory] = useState([]);
  const [history, setHistory] = useState([]);

  // 視窗/取樣
  const [avgDtMs, setAvgDtMs] = useState(100);
  const [liveSeconds, setLiveSeconds] = useState(8);
  const [testSeconds, setTestSeconds] = useState(8);

  // 測試控制
  const [testing, setTesting] = useState(false);
  const [countdown, setCountdown] = useState(null);
  const timerRef = useRef(null);
  const testStartAtRef = useRef(null);
  const lastTickRef = useRef(null);

  // Dock 與 CSV 重新建置訊號
  const [showDock, setShowDock] = useState(true);
  const [csvRebuildSignal, setCsvRebuildSignal] = useState(0);

  // —— 過濾狀態（左右側、群組） ——
  const [sides, setSides] = useState({ R: true, L: true });
  const [parts, setParts] = useState({ Shoulder:true, Elbow:true, Wrist:true, Hip:true, Knee:true, Ankle:true });
  const seriesKeys = filterSeriesKeys(SERIES_KEYS_ALL, parts, sides);

  // i18n 的標籤：資料集/圖例/表格皆可共用
  const labelForKey = (k) => {
    const side = k.startsWith('R') ? t('right_hand', { defaultValue: 'Right' }) : t('left_hand', { defaultValue: 'Left' });
    const part = k.split('-')[1];
    const partLabel = t(`joint_${part}`, { defaultValue: part });
    return `${side} - ${partLabel}`;
  };

  // 當下快照 CSV（僅當前角度）
  const exportSnapshotCsv = () => {
    const cols = ['Joint', 'Angle(deg)'];
    const rows = [cols, ...seriesKeys.map(k => [k, typeof currentAngles[k] === 'number' ? Math.round(currentAngles[k]) : ''])];
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'BodyROM_Snapshot.csv';
    a.click();
  };

  // 更新流程：依 landmarks 推進
  useEffect(() => {
    const lm = poseLandmarks;
    const now = Date.now();

    if (lastTickRef.current) {
      const dt = now - lastTickRef.current;
      setAvgDtMs(prev => {
        const ema = prev ? prev * 0.9 + dt * 0.1 : dt;
        return Math.max(30, Math.min(300, Math.round(ema)));
      });
    }
    lastTickRef.current = now;

    if (!lm || lm.length < 33) return;

    const next = {};
    for (const spec of ANGLE_SPECS) {
      const [a, b, c] = spec.pts;
      const A = lm[a], B = lm[b], C = lm[c];
      if (!(isVisible(A) && isVisible(B) && isVisible(C))) continue;
      const ang = angleAtB(A, B, C);
      if (typeof ang === 'number') next[spec.key] = Math.round(ang);
    }
    setCurrentAngles(next);

    if (testing) {
      setHistory(prev => [...prev.slice(-999), { timestamp: now, angles: next }]);
    }

    const liveWindow = Math.max(10, Math.round((liveSeconds * 1000) / Math.max(1, avgDtMs)));
    setLiveHistory(prev => {
      const nxt = [...prev, { timestamp: now, angles: next }];
      return nxt.length > liveWindow ? nxt.slice(nxt.length - liveWindow) : nxt;
    });
  }, [poseLandmarks, testing, liveSeconds, avgDtMs]);

  // 施測控制
  const startTesting = () => {
    if (testing) return;
    setTesting(true);
    setHistory([]);
    testStartAtRef.current = Date.now();

    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    let tsec = Math.max(3, Math.min(30, Math.round(testSeconds)));
    setCountdown(tsec);
    timerRef.current = setInterval(() => {
      tsec -= 1;
      setCountdown(tsec);
      if (tsec <= 0) {
        clearInterval(timerRef.current);
        timerRef.current = null;
        setTesting(false);
        setCountdown(null);
      }
    }, 1000);
  };
  const stopTesting = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    setTesting(false);
    setCountdown(null);
  };
  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  // 觀眾視角表格（依鏡像對調）
  const RIGHT = screenMirrored
    ? ['L-Shoulder','L-Elbow','L-Wrist','L-Hip','L-Knee','L-Ankle']
    : ['R-Shoulder','R-Elbow','R-Wrist','R-Hip','R-Knee','R-Ankle'];
  const LEFT = screenMirrored
    ? ['R-Shoulder','R-Elbow','R-Wrist','R-Hip','R-Knee','R-Ankle']
    : ['L-Shoulder','L-Elbow','L-Wrist','L-Hip','L-Knee','L-Ankle'];
  const fmt = (k) => (typeof currentAngles[k] === 'number' ? `${currentAngles[k]}°` : '—');

  const fps = Math.round(1000 / Math.max(1, avgDtMs));

  return (
    <>
      <div className="bg-white border p-3 rounded mt-3">
        <h5 className="text-center mb-3">🧠 {t('body_rom_title', { defaultValue: '身體 ROM 評估' })}</h5>

        {/* 過濾器（左右側 + 關節群組） */}
        <BodyRomFilters
          parts={parts} setParts={setParts}
          sides={sides} setSides={setSides}
          onReset={() => { setSides({R:true,L:true}); setParts({Shoulder:true,Elbow:true,Wrist:true,Hip:true,Knee:true,Ankle:true}); }}
        />

        {/* 視窗/效能顯示 */}
        <div className="d-flex flex-wrap gap-3 justify-content-center align-items-center mb-2">
          <label className="small d-flex align-items-center gap-2">
            {t('rom_live_seconds', { defaultValue: '即時圖顯示秒數' })}：
            <input type="range" min="3" max="60" value={liveSeconds}
              onChange={e => setLiveSeconds(parseInt(e.target.value, 10))} />
            <strong>{liveSeconds}s</strong>
          </label>
          <label className="small d-flex align-items-center gap-2">
            {t('rom_test_seconds', { defaultValue: '施測秒數' })}：
            <input type="range" min="3" max="30" value={testSeconds}
              onChange={e => setTestSeconds(parseInt(e.target.value, 10))} />
            <strong>{testSeconds}s</strong>
          </label>
          <span className="small text-muted">
            {t('rom_est_fps', { defaultValue: '估計 FPS' })}: {fps} ({avgDtMs}ms)
          </span>
          <span className="small text-muted">
            {t('visible_series', { defaultValue: 'Visible Series' })}: {seriesKeys.length}
          </span>
        </div>

        {/* 當下角度表（顯示不受過濾影響，若你希望也跟著過濾，可用 seriesKeys 來決定欄） */}
        <div className="table-responsive" style={{ maxWidth: 720, margin: '0 auto' }}>
          <table className="table table-sm table-bordered align-middle">
            <thead>
              <tr>
                <th></th>
                <th>{t('joint_Shoulder', { defaultValue: 'Shoulder' })}</th>
                <th>{t('joint_Elbow',    { defaultValue: 'Elbow' })}</th>
                <th>{t('joint_Wrist',    { defaultValue: 'Wrist' })}</th>
                <th>{t('joint_Hip',      { defaultValue: 'Hip' })}</th>
                <th>{t('joint_Knee',     { defaultValue: 'Knee' })}</th>
                <th>{t('joint_Ankle',    { defaultValue: 'Ankle' })}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">{t('right_hand', { defaultValue: 'Right' })}</th>
                {RIGHT.map(k => <td key={k}>{fmt(k)}</td>)}
              </tr>
              <tr>
                <th scope="row">{t('left_hand', { defaultValue: 'Left' })}</th>
                {LEFT.map(k => <td key={k}>{fmt(k)}</td>)}
              </tr>
            </tbody>
          </table>
        </div>

        {/* 分級圖例（i18n） */}
        <div className="text-center">
          <BodyRomLegend className="d-inline-block mt-2" />
        </div>

        {/* 快照 CSV */}
        <div className="text-center mb-2">
          <button className="btn btn-outline-secondary btn-sm" onClick={exportSnapshotCsv}>
            {t('rom_download_csv', { defaultValue: '下載快照 CSV' })}
          </button>
        </div>

        {/* 即時/歷史圖（使用過濾後 seriesKeys） */}
        {liveHistory.length >= 2 && (
          <div className="mt-3">
            <BodyRomAngleChart
              history={liveHistory}
              seriesKeys={seriesKeys}
              labelForKey={labelForKey}
              title={`${t('rom_live_chart_title', { defaultValue: '即時角度' })}（${liveSeconds}s）`}
              height={260}
              showLegend
              yRange={{ min: 0, max: 180 }}
              maintainAspectRatio={false}
              animations={false}
            />
          </div>
        )}

        {history.length >= 2 && (
          <div className="mt-3" onClick={() => setCsvRebuildSignal(s => s + 1)}>
            <BodyRomAngleChart
              history={history}
              seriesKeys={seriesKeys}
              labelForKey={labelForKey}
              title={`${t('rom_chart_title', { defaultValue: '角度趨勢圖' })}（${testSeconds}s）`}
              height={260}
              showLegend
              yRange={{ min: 0, max: 180 }}
              maintainAspectRatio={false}
              animations={false}
            />
          </div>
        )}

        {/* 施測控制 */}
        <div className="text-center mt-3">
          {!testing ? (
            <button className="btn btn-primary btn-sm" onClick={startTesting}>
              {t('rom_start', { defaultValue: '開始施測' })} ({testSeconds}s)
            </button>
          ) : (
            <button className="btn btn-danger btn-sm" onClick={stopTesting}>
              {t('rom_stop', { defaultValue: '停止施測' })}
            </button>
          )}
          {countdown !== null && (
            <p className="mt-2">{t('rom_countdown', { defaultValue: '倒數' })}：{countdown}s</p>
          )}
        </div>
      </div>

      {/* 底部 Dock（用過濾後的 seriesKeys。Dock 內 CSV 也會跟著過濾結果） */}
      <BodyRomDock
        show={showDock && (liveHistory.length >= 2 || history.length >= 2)}
        onClose={() => setShowDock(false)}
        liveHistory={liveHistory}
        history={history}
        liveSeconds={liveSeconds}
        testSeconds={testSeconds}
        testing={testing}
        onStartTesting={startTesting}
        onStopTesting={stopTesting}
        fps={fps}
        seriesKeys={seriesKeys}
        testStartAtMs={testStartAtRef.current}
        csvRebuildSignal={csvRebuildSignal}
        onRequestCsvRebuild={() => setCsvRebuildSignal(s => s + 1)}
        t={t}
      />

      {!showDock && (liveHistory.length >= 2 || history.length >= 2) && (
        <button className="rom-dock-fab btn btn-primary btn-sm" onClick={() => setShowDock(true)}>
          ROM
        </button>
      )}
    </>
  );
}
