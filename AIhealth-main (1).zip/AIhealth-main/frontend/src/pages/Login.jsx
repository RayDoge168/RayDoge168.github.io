import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import { login, getUserProfile } from '../api'

export default function Login({ handleLogin }) {
  const { t } = useTranslation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)

const handleSubmit = async (e) => {
  e.preventDefault();
  setError(null);
  setLoading(true);
  try {
    const res = await login(email, password); // 從 api.js 返回 res.data.user
    handleLogin(res); // 直接用 user
  } catch (err) {
    setError(err.data?.detail || '登入失敗，請確認帳號與密碼');
  } finally {
    setLoading(false);
  }
};


  return (
    <div className="container py-5" style={{ maxWidth: 400 }}>
      <h2 className="text-center mb-4">{t('login')}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <input
            type="email"
            className="form-control"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="password"
            className="form-control"
            placeholder="密碼"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button
          type="submit"
          className="btn btn-primary w-100 rounded-pill shadow-sm mb-2"
          disabled={loading}
        >
          {loading ? '登入中...' : '登入'}
        </button>
      </form>

      {error && (
        <div className="alert alert-danger small text-center">{error}</div>
      )}

      <div className="text-center">
        <Link to="/register" className="d-block mb-1">沒有帳號？註冊</Link>
        <Link to="/forgot" className="text-decoration-none small">忘記密碼？</Link>
      </div>
    </div>
  )
}
