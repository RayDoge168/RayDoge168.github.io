import { 
  BrowserRouter,
  Routes,
  Route,
  useNavigate,
  useLocation,
  Navigate,             // ⬅️ 新增
} from 'react-router-dom'
import { useEffect, useState, lazy, Suspense } from 'react'
import GuestOnlyRoute from './components/GuestOnlyRoute'
import ProtectedRoute from './components/ProtectedRoute'
import useScrollSpy from './hooks/useScrollSpy'
import * as bootstrap from 'bootstrap'
import { useTranslation } from 'react-i18next'

// 站台共用 BAR / Footer
import NavBar from './components/NavBar'
import MobileNavModal from './components/MobileNavModal'
import Footer from './components/Footer'

// 頁面（lazy）
const Home = lazy(() => import('./pages/Home'))
const Login = lazy(() => import('./pages/Login'))
const Register = lazy(() => import('./pages/Register'))
const User = lazy(() => import('./pages/User'))
const Interaction = lazy(() => import('./pages/Interaction'))
const Therapist = lazy(() => import('./pages/Therapist'))
const Forgot = lazy(() => import('./pages/Forgot'))
const About = lazy(() => import('./pages/About'))
const Product = lazy(() => import('./pages/Product'))
const ESG = lazy(() => import('./pages/ESG'))
const Contact = lazy(() => import('./pages/Contact'))
const VoiceAssistant = lazy(() => import('./pages/VoiceAssistant'))
const UserHistory = lazy(() => import('./pages/UserHistory'))

// ✅ Guest 系列
const GuestPage = lazy(() => import('./pages/GuestPage'))
const GuestMyHealth = lazy(() => import('./pages/GuestMyHealth'))

function AppLayout() {
  const navigate = useNavigate()
  const location = useLocation()
  const { t, i18n } = useTranslation()

  // ✅ /guest 與 /my-health 視為 Guest UI
  const isGuestUI = /^\/(guest|my-health)(\/|$)/.test(location.pathname)

  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('user')
    return saved ? JSON.parse(saved) : null
  })

  const [darkMode, setDarkMode] = useState(false)
  const [manualActiveSection, setManualActiveSection] = useState(null)

  const scrollSpySection = useScrollSpy([
    'about-section',
    'feature-section',
    'esg-section',
    'contact-section',
  ])
  const activeSection = manualActiveSection || scrollSpySection

  useEffect(() => {
    const modalEl = document.getElementById('navModal')
    if (modalEl) {
      window.bsNavModal = bootstrap.Modal.getOrCreateInstance(modalEl)
    }
  }, [])

  useEffect(() => {
    const savedDarkMode = localStorage.getItem('darkMode')
    if (savedDarkMode !== null) setDarkMode(JSON.parse(savedDarkMode))
  }, [])

  useEffect(() => {
    document.body.classList.toggle('dark-mode', darkMode)
    localStorage.setItem('darkMode', JSON.stringify(darkMode))
  }, [darkMode])

  const closeModal = () => {
    const modalEl = document.getElementById('navModal')
    const backdrop = document.querySelector('.modal-backdrop')
    if (modalEl) bootstrap.Modal.getInstance(modalEl)?.hide()
    if (backdrop) backdrop.remove()
    document.body.classList.remove('modal-open')
    document.body.style = ''
  }

  const handleNavigate = (path) => {
    closeModal()
    navigate(path)
  }

  const handleLogin = () => {
    const guest = { name: t('menu_guest'), email: 'guest@example.com' }
    setUser(guest)
    localStorage.setItem('user', JSON.stringify(guest))
    navigate('/user')
  }

  const handleLogout = () => {
    setUser(null)
    localStorage.removeItem('user')
    navigate('/')
  }

  // ✅ 來自 /guest 的 hash（#exercises/#progress）做平滑捲動
  useEffect(() => {
    if (!isGuestUI) return
    if (!location.hash) return
    // 等子頁 render 完再捲動
    const id = location.hash.slice(1)
    const timer = setTimeout(() => {
      const el = document.getElementById(id)
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 0)
    return () => clearTimeout(timer)
  }, [isGuestUI, location.pathname, location.hash])

  return (
    <>
      {/* 一般站台顯示主 Nav；Guest 系列由各頁面自行顯示 GuestTopBar */}
      {!isGuestUI && (
        <>
          <NavBar
            user={user}
            handleNavigate={handleNavigate}
            activeSection={activeSection}
            setManualActiveSection={setManualActiveSection}
          />
          <MobileNavModal
            user={user}
            handleNavigate={handleNavigate}
            handleLogout={handleLogout}
            i18n={i18n}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
          />
        </>
      )}

      <Suspense fallback={<div className="text-center p-5">Loading...</div>}>
        <Routes>
          {/* 一般站台頁面 */}
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/product" element={<Product />} />
          <Route path="/esg" element={<ESG />} />
          <Route path="/contact" element={<Contact />} />
          <Route
            path="/login"
            element={
              <GuestOnlyRoute user={user} redirectTo="/user">
                <Login handleLogin={handleLogin} />
              </GuestOnlyRoute>
            }
          />
          <Route
            path="/register"
            element={
              <GuestOnlyRoute user={user} redirectTo="/user">
                <Register />
              </GuestOnlyRoute>
            }
          />
          <Route
            path="/user"
            element={
              <ProtectedRoute user={user}>
                <User />
              </ProtectedRoute>
            }
          />
          <Route
            path="/interaction"
            element={
              <ProtectedRoute user={user}>
                <Interaction />
              </ProtectedRoute>
            }
          />
          <Route
            path="/therapist"
            element={
              <ProtectedRoute user={user}>
                <Therapist />
              </ProtectedRoute>
            }
          />
          <Route
            path="/voice"
            element={
              <ProtectedRoute user={user}>
                <VoiceAssistant />
              </ProtectedRoute>
            }
          />
          <Route path="/forgot" element={<Forgot />} />
          <Route
            path="/userhistory"
            element={
              <ProtectedRoute user={user}>
                <UserHistory />
              </ProtectedRoute>
            }
          />

          {/* ✅ Guest 系列（各自頁面內 render GuestTopBar） */}
          <Route path="/guest" element={<GuestPage />} />
          <Route path="/my-health" element={<GuestMyHealth />} />

          {/* ✅ 舊連結/拼字錯誤 → 一律導回 /guest，避免白畫面 */}
          <Route path="/rehabilitation" element={<Navigate to="/guest" replace />} />
          <Route path="/rehabilation"  element={<Navigate to="/guest" replace />} />

          {/* （可選）未知路由 → 回首頁 */}
          {/* <Route path="*" element={<Navigate to="/" replace />} /> */}
        </Routes>
      </Suspense>

      {/* ✅ Guest 頁面不顯示站台 Footer，避免雙層 UI 衝突 */}
      {!isGuestUI && <Footer />}
    </>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppLayout />
    </BrowserRouter>
  )
}
