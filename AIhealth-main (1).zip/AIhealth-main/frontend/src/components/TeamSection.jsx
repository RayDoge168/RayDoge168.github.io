import React from "react";
import { useTranslation } from "react-i18next";
import "./TeamSection.css";

export default function TeamSection() {
  const { t } = useTranslation();

  // ✅ 直接合併成一個陣列（並排）
  const members = [
    { key: "shih",      img: "/public/uploads/member1.jpg"  },
    { key: "seacheuk",  img: "/public/uploads/member6.jpg"  },
    { key: "peterfung", img: "/public/uploads/member7.jpg"  },
  ];

  // 共用的卡片渲染函式
  const renderMembers = (list) =>
    list.map(({ key, img }) => (
      <div key={key} className="col-12 col-sm-6 col-md-4 mb-4 d-flex">
        <div className="card team-card shadow-sm border-0 w-100 h-120">
          <div className="team-img-wrapper">
            <img
              src={img}
              alt={t(`team.members.${key}.name`)}
              className="team-img"
              loading="lazy"
            />
          </div>
          <div className="card-body text-center">
            <h5 className="card-title fw-semibold mb-1">
              {t(`team.members.${key}.name`)}
            </h5>
            <p className="text-primary small mb-2">
              {t(`team.members.${key}.role`)}
            </p>
            <p className="text-muted small mb-0">
              {t(`team.members.${key}.bio`)}
            </p>
          </div>
        </div>
      </div>
    ));

  return (
    <section id="team-section" className="py-5 bg-light border-top fade-up-section">
      <div className="container">
        <h2 className="fw-bold text-center mb-4">
          <i className="bi bi-people-fill me-2" />
          {t("team.title")}
        </h2>

        {/* ✅ 單一 row，三人並排 */}
        <div className="row justify-content-center g-4">
          {renderMembers(members)}
        </div>
      </div>
    </section>
  );
}
