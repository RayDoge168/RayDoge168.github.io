# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript and enable type-aware lint rules. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.

請在TERMINAL 輸入:

npm run dev

然後

npx vite --host localhost
就可以顯示 及時網頁

OPENAI_API_KEY=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

<div className="d-grid gap-2 d-sm-flex justify-content-center">
          <Link
            to="/login"
            className="btn btn-teal btn-lg rounded-pill px-4 shadow-sm"
          >
            <i className="bi bi-box-arrow-in-right me-2"></i>
            {t('hero_login')}
          </Link>
          
          <Link
  to="/guest"
  className="btn btn-outline-secondary btn-lg rounded-pill px-4 shadow-sm"
>
  {t('hero_guest')}
</Link>

        </div>


        src="\public\uploads\NOVA2.jpg"